import { ArrowLeft, ChevronDown, ChevronUp, Info } from 'lucide-react';
import React, { useState } from 'react';
import { useIsMobile } from '../hooks/useIsMobile';
import { useLanguage } from '../contexts/LanguageContext';
import { INDICES_VALUES } from '../data/indices-data';

const getRiskData = (language: 'en' | 'es') => ({
  location: language === 'en' ? 'Cochamó Reserve - Chilean Patagonia' : 'Reserva Cochamó - Patagonia Chilena',
  ecorregion: language === 'en' ? 'Valdivian Temperate Forest Ecoregion' : 'Ecorregión Bosque Templado Valdiviano',
  area: {
    aoi: 919.0,
    zonaHumeda: 485.2
  },
  indice: {
    valor: INDICES_VALUES.risk.valor,
    categoria: INDICES_VALUES.risk.categoriaCorta[language],
    codigo: 'IR',
    tendencia: language === 'en' ? 'Stable' : 'Estable'
  },
  labels: {
    indiceRiesgo: language === 'en' ? 'Integrated Risk Index' : 'Índice de Riesgo Integrado',
    superficie: language === 'en' ? 'Surface' : 'Superficie',
    zonaHumeda: language === 'en' ? 'Wetland Zone' : 'Zona Húmeda',
    nivelRiesgo: language === 'en' ? 'Risk Level' : 'Nivel de Riesgo',
    verDatos: language === 'en' ? 'View Complete Data' : 'Ver Datos Completos',
    ocultarTabla: language === 'en' ? 'Hide table' : 'Ocultar tabla',
    descripcionDatos: language === 'en' ? 'Sub-indices and system data' : 'Subíndices y datos del sistema',
    subindices: language === 'en' ? 'Sub-indices (0-100)' : 'Subíndices (0–100)',
    riesgosDominantes: language === 'en' ? 'Dominant Risks' : 'Riesgos Dominantes',
    riesgosMinimos: language === 'en' ? 'Minimal Risks' : 'Riesgos Mínimos',
    dataSistema: language === 'en' ? 'System Data' : 'Data del Sistema',
    total: language === 'en' ? 'Total' : 'Total',
    confianzaFinal: language === 'en' ? 'Final Confidence (QA)' : 'Confianza Final (QA)',
    fuentesActivas: language === 'en' ? 'Active Sources' : 'Fuentes activas',
    ci95: language === 'en' ? 'Confidence Interval (CI95)' : 'Intervalo de Confianza (IC95)',
    fuentes: language === 'en' ? 'Sources' : 'Fuentes',
    serieTemporal: language === 'en' ? 'Time Series' : 'Serie Temporal',
    valoresIntegrados: language === 'en' ? '*Integrated multi-scale values' : '*Valores integrados multiescala',
    metodologiaIntegracion: language === 'en' ? 'Integration Methodology' : 'Metodología de Integración',
    tooltipMetodologia: language === 'en' 
      ? 'Values integrate optical, climatic, topographic, and territorial data at different native resolutions (10m–5km), aggregated at pixel scale within the analysis area.'
      : 'Los valores integran datos ópticos, climáticos, topográficos y territoriales a diferentes resoluciones nativas (10m–5km), agregados a escala píxel dentro del área de análisis.',
    erosionClima: language === 'en' ? 'Erosion / Climate' : 'Erosión / Clima',
    presionFragmentacion: language === 'en' ? 'Anthropogenic Pressure / Fragmentation' : 'Presión Antrópica / Fragmentación'
  },
  subindices: [
    {
      codigo: 'CS',
      nombre: language === 'en' ? 'Climate Stress' : 'Estrés Climático',
      valor: 44.75,
      color: '#eab308'
    },
    {
      codigo: 'RHm',
      nombre: language === 'en' ? 'Regional Hydrology' : 'Hidrología Regional',
      valor: 54.29,
      color: '#06b6d4'
    },
    {
      codigo: 'GE',
      nombre: language === 'en' ? 'Geomorphological Exposure' : 'Exposición Geomorfológica',
      valor: 66.31,
      color: '#dc8585'
    },
    {
      codigo: 'RF',
      nombre: language === 'en' ? 'Fragmentation Risk' : 'Riesgo de Fragmentación',
      valor: 3.00,
      color: '#22c55e'
    },
    {
      codigo: 'LP',
      nombre: language === 'en' ? 'Land Pressure' : 'Presión del Territorio',
      valor: 1.61,
      color: '#10b981'
    }
  ],
  confianza: {
    valor: INDICES_VALUES.risk.confianza, // 0.78
    fuentesActivas: 8,
    ci95: '±3.9'
  }
});

interface RiskDataConsolidadoProps {
  onNavigate: (view: 'portada' | 'risk-interpretation' | 'hydro-mapbox-test') => void;
  hideNavigationButton?: boolean;
  inStack?: boolean;
  backTo?: 'hydro-mapbox-test' | 'digital-asset-card';
}

export default function RiskDataConsolidado({ onNavigate, hideNavigationButton = false, inStack = false, backTo = 'hydro-mapbox-test' }: RiskDataConsolidadoProps) {
  const isMobile = useIsMobile();
  const [isDataOpen, setIsDataOpen] = useState(false);
  const [showTooltip, setShowTooltip] = useState(false);
  const { language } = useLanguage();

  const riskData = getRiskData(language);

  // Debug: Log para verificar el idioma
  console.log('🌐 RiskDataConsolidado - Current language:', language);
  console.log('📊 RiskDataConsolidado - Location:', riskData.location);

  return (
    <div className="relative w-full bg-[#0f1220]" style={{ minHeight: inStack ? 'fit-content' : '100vh', overflow: inStack ? 'visible' : 'auto' }}>
      
      <button
        onClick={() => {
          if (backTo === 'digital-asset-card') {
            onNavigate('hydro-mapbox-test-with-asset-card' as any);
          } else {
            onNavigate('hydro-mapbox-test');
          }
        }}
        className="fixed bg-[#171f33] border border-[#243253] rounded-lg hover:bg-[#1a2540] transition-all group flex items-center gap-2"
        style={isMobile ? {
          top: '16px',
          left: '16px',
          padding: '10px 16px',
          boxShadow: '0 4px 16px rgba(0, 0, 0, 0.4)',
          zIndex: 999
        } : {
          top: 'clamp(14px, 2vh, 32px)',
          left: 'clamp(14px, 2vw, 32px)',
          padding: 'clamp(8px, 1vh, 12px)',
          boxShadow: '0 4px 12px rgba(0, 0, 0, 0.2)',
          zIndex: 50
        }}
        title="Volver a TEST MAPBOX"
      >
        <ArrowLeft 
          className="text-[#c47a7a] group-hover:text-[#dc8585] transition-colors" 
          style={{ 
            width: isMobile ? '20px' : 'clamp(18px, 1.5vw, 22px)', 
            height: isMobile ? '20px' : 'clamp(18px, 1.5vw, 22px)' 
          }} 
        />
        {isMobile && (
          <span className="text-[#c47a7a] group-hover:text-[#dc8585] transition-colors" style={{ fontSize: '14px', fontWeight: 500 }}>
            TEST MAPBOX
          </span>
        )}
      </button>

      <div 
        className="relative z-10 w-full"
        style={isMobile ? {
          display: 'flex',
          flexDirection: 'column',
          gap: 'clamp(12px, 1.5vh, 18px)',
          padding: 'clamp(12px, 1.5vh, 18px)',
          paddingTop: inStack ? '12px' : '70px',
          paddingBottom: 'clamp(120px, 18vh, 200px)',
          maxWidth: '100%',
          minHeight: inStack ? 'auto' : '100vh',
          boxSizing: 'border-box'
        } : {
          display: 'grid',
          gridTemplateColumns: 'clamp(220px, 22vw, 320px) 1fr',
          gap: 'clamp(12px, 1.4vw, 18px)',
          padding: 'clamp(10px, 1.2vh, 14px)',
          paddingLeft: 'clamp(30px, 4vw, 60px)',
          paddingRight: 'clamp(30px, 4vw, 60px)',
          paddingTop: 'clamp(70px, 9vh, 90px)',
          paddingBottom: 'clamp(120px, 18vh, 200px)',
          maxWidth: '1500px',
          margin: '0 auto',
          minHeight: 'auto',
          boxSizing: 'border-box'
        }}
      >
        
        {/* Panel izquierdo: Metadata */}
        <div 
          className="flex flex-col rounded-xl border border-[#222a42]"
          style={{ 
            background: 'linear-gradient(180deg, #141a2a, #1b2235)',
            padding: 'clamp(14px, 1.8vh, 20px)',
            gap: 'clamp(10px, 1.2vh, 14px)',
            height: '100%'
          }}
        >
          
          <div>
            <p 
              className="text-[#e9eef9] m-0"
              style={{ 
                fontSize: 'clamp(0.85rem, 0.8rem + 0.3vw, 1rem)',
                fontWeight: 600,
                marginBottom: 'clamp(2px, 0.3vh, 4px)',
                textTransform: 'uppercase',
                letterSpacing: '1px'
              }}
            >
              Metadata
            </p>
            <p 
              className="text-[#e9eef9] m-0"
              style={{ 
                fontSize: 'clamp(1rem, 0.95rem + 0.4vw, 1.2rem)',
                fontWeight: 700,
                marginBottom: 'clamp(4px, 0.6vh, 8px)'
              }}
              translate="no"
            >
              RISK INDEX®
            </p>
          </div>

          <div>
            <h2 
              className="text-[#e9eef9] m-0"
              style={{ 
                fontSize: 'clamp(1.1rem, 1.4vw, 1.45rem)',
                letterSpacing: '0.2px'
              }}
            >
              {riskData.location}
            </h2>
            <p 
              className="text-[#a8b0c6] m-0"
              style={{ fontSize: 'clamp(0.9rem, 1.1vw, 1.15rem)' }}
            >
              {riskData.ecorregion}
            </p>
          </div>

          <div 
            className="rounded-xl border border-[#222a42]"
            style={{ 
              background: 'linear-gradient(180deg, #141a2a, #1b2235)',
              padding: 'clamp(14px, 1.8vh, 20px)'
            }}
          >
            <div className="flex flex-col items-center gap-[1.2vh]">
              <div
                className="group"
                style={{
                  width: 'clamp(100px, 11vw, 120px)',
                  height: 'clamp(100px, 11vw, 120px)',
                  borderRadius: '50%',
                  background: `conic-gradient(#c47a7a ${riskData.indice.valor}%, #253053 0), radial-gradient(farthest-side, #0f1220 65%, transparent 66%)`,
                  display: 'grid',
                  placeItems: 'center',
                  border: '1px solid #202845',
                  boxShadow: 'inset 0 0 18px rgba(180, 88, 88, 0.15)',
                  position: 'relative',
                  userSelect: 'none'
                }}
              >
                <div style={{ fontSize: '24px', fontWeight: 700, color: '#e9eef9', userSelect: 'none' }}>
                  {riskData.indice.valor}
                </div>
              </div>

              <p 
                className="text-[#c47a7a] m-0 text-center"
                style={{ 
                  fontSize: 'clamp(0.85rem, 1vw, 1.1rem)',
                  fontWeight: 600,
                  letterSpacing: '0.3px',
                  marginBottom: 'clamp(14px, 1.8vh, 18px)'
                }}
              >
                {riskData.labels.indiceRiesgo}
              </p>

              <div className="w-full flex flex-col" style={{ gap: 'clamp(12px, 1.5vh, 16px)' }}>
                <div className="grid grid-cols-2" style={{ gap: 'clamp(6px, 0.8vw, 10px)' }}>
                  <div>
                    <div 
                      className="text-[#c4cfe0] mb-[0.4vh]"
                      style={{ fontSize: 'clamp(0.9rem, 1.05vw, 1.15rem)' }}
                    >
                      {riskData.labels.superficie}
                    </div>
                    <div 
                      className="text-[#5fa66c]"
                      style={{ fontSize: 'clamp(1.2rem, 1.5vw, 1.65rem)', fontWeight: 600 }}
                    >
                      {riskData.area.aoi.toFixed(0)} ha
                    </div>
                  </div>
                  <div>
                    <div 
                      className="text-[#c4cfe0] mb-[0.4vh]"
                      style={{ fontSize: 'clamp(0.9rem, 1.05vw, 1.15rem)' }}
                    >
                      {riskData.labels.zonaHumeda}
                    </div>
                    <div 
                      className="text-[#5fa66c]"
                      style={{ fontSize: 'clamp(1.2rem, 1.5vw, 1.65rem)', fontWeight: 600 }}
                    >
                      {riskData.area.zonaHumeda.toFixed(1)} ha
                    </div>
                  </div>
                </div>
                <div className="text-center rounded-lg border border-[#c47a7a]/30" style={{ 
                  padding: 'clamp(6px, 0.8vh, 10px)',
                  background: 'rgba(196, 122, 122, 0.1)'
                }}>
                  <div 
                    className="text-[#e9eef9]"
                    style={{ fontSize: 'clamp(0.85rem, 1vw, 1.1rem)', letterSpacing: '0.5px' }}
                  >
                    {riskData.labels.nivelRiesgo} {riskData.indice.categoria}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {isMobile && (
          <button
            onClick={() => setIsDataOpen(!isDataOpen)}
            className="flex items-center justify-between w-full rounded-xl border border-[#c47a7a]/40 hover:border-[#c47a7a]/70 transition-all"
            style={{
              background: 'linear-gradient(to right, rgba(196, 122, 122, 0.15), rgba(220, 133, 133, 0.1))',
              padding: '16px 20px'
            }}
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-[#c47a7a]/30 flex items-center justify-center">
                <span className="text-2xl">⚠️</span>
              </div>
              <div className="text-left">
                <p className="text-[#e9eef9] m-0" style={{ fontSize: '1.05rem', fontWeight: 600 }}>
                  {riskData.labels.verDatos}
                </p>
                <p className="text-[#a8b0c6] m-0" style={{ fontSize: '0.85rem' }}>
                  {isDataOpen ? riskData.labels.ocultarTabla : riskData.labels.descripcionDatos}
                </p>
              </div>
            </div>
            {isDataOpen ? (
              <ChevronUp className="text-[#c47a7a]" style={{ width: '24px', height: '24px' }} />
            ) : (
              <ChevronDown className="text-[#c47a7a]" style={{ width: '24px', height: '24px' }} />
            )}
          </button>
        )}

        {/* Panel derecho: Datos Risk */}
        <div 
          className="rounded-xl border border-[#222a42] shadow-2xl"
          style={{
            background: 'linear-gradient(180deg, #141a2a, #1b2235)',
            padding: 'clamp(4px, 0.5vh, 5px)',
            ...(isMobile ? {
              width: '100%',
              maxHeight: isDataOpen ? '3000px' : '0px',
              overflow: 'hidden',
              opacity: isDataOpen ? 1 : 0,
              transition: 'max-height 0.5s ease, opacity 0.5s ease'
            } : {
              height: '100%',
              display: 'flex',
              flexDirection: 'column'
            })
          }}
        >
          <div style={{ 
            display: 'grid', 
            gridTemplateColumns: '1fr', 
            gap: 'clamp(6px, 0.8vh, 10px)',
            ...(isMobile ? {} : { flex: 1 })
          }}>              
            {/* Cabecera Risk Index */}
            <div 
              className="rounded-lg border border-[#c47a7a]/40"
              style={{ 
                padding: 'clamp(3px, 0.35vh, 4px)',
                background: 'linear-gradient(to right, rgba(196, 122, 122, 0.15), rgba(220, 133, 133, 0.1))',
                gridColumn: 'auto'
              }}
            >
              <div className="flex items-center justify-between" style={{ gap: 'clamp(6px, 0.7vw, 8px)' }}>
                <p 
                  className="text-[#e9eef9] m-0"
                  style={{ 
                    fontSize: 'clamp(0.85rem, 1vw, 1.1rem)',
                    whiteSpace: 'nowrap'
                  }}
                >
                  Risk Index
                </p>
                <div className="text-center flex-1">
                  <p 
                    className="text-[#ef4444] m-0"
                    style={{ 
                      fontSize: 'clamp(1.5rem, 2vw, 2.2rem)',
                      fontWeight: 700,
                      lineHeight: '1'
                    }}
                  >
                    {riskData.indice.valor}
                  </p>
                </div>
                <p 
                  className="text-[#c4cfe0] m-0"
                  style={{ 
                    fontSize: 'clamp(0.8rem, 0.95vw, 1.05rem)',
                    fontWeight: 600,
                    lineHeight: '1.05',
                    textAlign: 'right',
                    whiteSpace: 'nowrap'
                  }}
                >
                  {riskData.labels.nivelRiesgo} {riskData.indice.categoria}
                </p>
              </div>
            </div>

            {/* Subíndices */}
            <div 
              className="rounded-lg border border-[#222a42]"
              style={{ 
                padding: 'clamp(3px, 0.35vh, 4px)',
                background: 'rgba(15, 18, 32, 0.4)'
              }}
            >
              <p 
                className="text-[#a8b0c6] m-0"
                style={{ 
                  fontSize: 'clamp(0.8rem, 0.95vw, 1.05rem)',
                  fontWeight: 600,
                  marginBottom: 'clamp(2px, 0.25vh, 3px)',
                  letterSpacing: '0.2px',
                  lineHeight: '1'
                }}
              >
                {riskData.labels.subindices}
              </p>
              
              <div style={{ display: 'grid', gridTemplateColumns: '1fr', gap: 'clamp(2px, 0.25vh, 3px)' }}>
                {riskData.subindices.map((sub, idx) => (
                  <div 
                    key={idx}
                    className="rounded border border-[#222a42]/50"
                    style={{ 
                      padding: 'clamp(2px, 0.25vh, 3px) clamp(3px, 0.35vh, 4px)',
                      background: 'rgba(15, 18, 32, 0.3)',
                      display: 'flex',
                      justifyContent: 'space-between',
                      alignItems: 'center',
                      gap: 'clamp(4px, 0.5vw, 6px)'
                    }}
                  >
                    <span 
                      className="text-[#a8b0c6]"
                      style={{ 
                        fontSize: 'clamp(0.7rem, 0.85vw, 0.9rem)',
                        lineHeight: '1'
                      }}
                    >
                      {sub.codigo} – {sub.nombre}
                    </span>
                    <span 
                      className="text-[#e9eef9]"
                      style={{ 
                        fontSize: 'clamp(0.95rem, 1.1vw, 1.2rem)',
                        fontWeight: 700,
                        lineHeight: '1',
                        whiteSpace: 'nowrap'
                      }}
                    >
                      {sub.valor}
                    </span>
                  </div>
                ))}
              </div>
              
              <div 
                style={{ 
                  borderTop: '1px solid rgba(168, 176, 198, 0.3)',
                  margin: 'clamp(2px, 0.25vh, 3px) 0'
                }}
              />
              
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <span 
                  className="text-[#ef4444]"
                  style={{ 
                    fontSize: 'clamp(0.8rem, 0.95vw, 1.05rem)',
                    fontWeight: 600,
                    lineHeight: '1'
                  }}
                >
                  {riskData.labels.total}
                </span>
                <span 
                  className="text-[#ef4444]"
                  style={{ 
                    fontSize: 'clamp(0.95rem, 1.1vw, 1.2rem)',
                    fontWeight: 700,
                    lineHeight: '1'
                  }}
                >
                  {riskData.indice.valor}
                </span>
              </div>
            </div>

            {/* Riesgos Dominantes y Mínimos */}
            <div 
              className="rounded-lg border border-[#222a42]"
              style={{ 
                padding: 'clamp(3px, 0.35vh, 4px)',
                background: 'rgba(15, 18, 32, 0.4)'
              }}
            >
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 'clamp(2px, 0.25vh, 3px)' }}>
                <div 
                  className="rounded border border-[#222a42]/50"
                  style={{ 
                    padding: 'clamp(2px, 0.25vh, 3px)',
                    background: 'rgba(15, 18, 32, 0.3)',
                    display: 'flex',
                    flexDirection: 'column',
                    gap: 'clamp(1px, 0.12vh, 2px)'
                  }}
                >
                  <span className="text-[#ef4444]" style={{ fontSize: 'clamp(0.65rem, 0.8vw, 0.85rem)', lineHeight: '1', fontWeight: 600 }}>
                    {riskData.labels.riesgosDominantes}
                  </span>
                  <span className="text-[#e9eef9]" style={{ fontSize: 'clamp(0.7rem, 0.85vw, 0.9rem)', lineHeight: '1.2' }}>
                    {riskData.labels.erosionClima}
                  </span>
                </div>
                
                <div 
                  className="rounded border border-[#222a42]/50"
                  style={{ 
                    padding: 'clamp(2px, 0.25vh, 3px)',
                    background: 'rgba(15, 18, 32, 0.3)',
                    display: 'flex',
                    flexDirection: 'column',
                    gap: 'clamp(1px, 0.12vh, 2px)'
                  }}
                >
                  <span className="text-[#22c55e]" style={{ fontSize: 'clamp(0.65rem, 0.8vw, 0.85rem)', lineHeight: '1', fontWeight: 600 }}>
                    {riskData.labels.riesgosMinimos}
                  </span>
                  <span className="text-[#e9eef9]" style={{ fontSize: 'clamp(0.7rem, 0.85vw, 0.9rem)', lineHeight: '1.2' }}>
                    {riskData.labels.presionFragmentacion}
                  </span>
                </div>
              </div>
            </div>

            {/* Data del Sistema */}
            <div 
              className="rounded-lg border border-[#222a42]"
              style={{ 
                padding: 'clamp(3px, 0.35vh, 4px)',
                background: 'rgba(15, 18, 32, 0.4)'
              }}
            >
              <p 
                className="text-[#a8b0c6] m-0"
                style={{ 
                  fontSize: 'clamp(0.8rem, 0.95vw, 1.05rem)',
                  fontWeight: 600,
                  marginBottom: 'clamp(2px, 0.25vh, 3px)',
                  letterSpacing: '0.2px',
                  lineHeight: '1'
                }}
              >
                {riskData.labels.dataSistema}
              </p>
              
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 'clamp(2px, 0.25vh, 3px)' }}>
                <div 
                  className="rounded border border-[#222a42]/50"
                  style={{ 
                    padding: 'clamp(2px, 0.25vh, 3px)',
                    background: 'rgba(15, 18, 32, 0.3)',
                    display: 'flex',
                    flexDirection: 'column',
                    gap: 'clamp(1px, 0.12vh, 2px)'
                  }}
                >
                  <span className="text-[#a8b0c6]" style={{ fontSize: 'clamp(0.65rem, 0.8vw, 0.85rem)', lineHeight: '1' }}>
                    {riskData.labels.confianzaFinal}
                  </span>
                  <span className="text-[#e9eef9]" style={{ fontSize: 'clamp(0.85rem, 1vw, 1.1rem)', fontWeight: 600, lineHeight: '1' }}>
                    {riskData.confianza.valor}
                  </span>
                </div>
                
                <div 
                  className="rounded border border-[#222a42]/50"
                  style={{ 
                    padding: 'clamp(2px, 0.25vh, 3px)',
                    background: 'rgba(15, 18, 32, 0.3)',
                    display: 'flex',
                    flexDirection: 'column',
                    gap: 'clamp(1px, 0.12vh, 2px)'
                  }}
                >
                  <span className="text-[#a8b0c6]" style={{ fontSize: 'clamp(0.65rem, 0.8vw, 0.85rem)', lineHeight: '1' }}>
                    {riskData.labels.fuentesActivas}
                  </span>
                  <span className="text-[#e9eef9]" style={{ fontSize: 'clamp(0.85rem, 1vw, 1.1rem)', fontWeight: 600, lineHeight: '1' }}>
                    {riskData.confianza.fuentesActivas}
                  </span>
                </div>
                
                <div 
                  className="rounded border border-[#222a42]/50"
                  style={{ 
                    padding: 'clamp(2px, 0.25vh, 3px)',
                    background: 'rgba(15, 18, 32, 0.3)',
                    display: 'flex',
                    flexDirection: 'column',
                    gap: 'clamp(1px, 0.12vh, 2px)'
                  }}
                >
                  <span className="text-[#a8b0c6]" style={{ fontSize: 'clamp(0.65rem, 0.8vw, 0.85rem)', lineHeight: '1' }}>
                    {riskData.labels.ci95}
                  </span>
                  <span className="text-[#e9eef9]" style={{ fontSize: 'clamp(0.85rem, 1vw, 1.1rem)', fontWeight: 600, lineHeight: '1' }}>
                    95% {riskData.confianza.ci95}
                  </span>
                </div>
              </div>
            </div>

            {/* Fuentes y Serie Temporal */}
            <div 
              className="rounded-lg border border-[#222a42]"
              style={{ 
                padding: 'clamp(3px, 0.35vh, 4px)',
                background: 'rgba(15, 18, 32, 0.4)',
                gridColumn: 'auto',
                position: 'relative'
              }}
            >
              <p 
                className="text-[#a8b0c6] text-center m-0"
                style={{ 
                  fontSize: 'clamp(0.75rem, 0.9vw, 1rem)',
                  lineHeight: '1.15',
                  marginBottom: 'clamp(1px, 0.12vh, 2px)'
                }}
              >
                <span className="text-[#e9eef9]">{riskData.labels.fuentes}:</span> Sentinel-2 (N=874), ERA5-Land, CHIRPS, Hansen GFC / <span className="text-[#e9eef9]">{riskData.labels.serieTemporal}:</span> 2014 - 2024 (10 {language === 'en' ? 'years' : 'años'})
              </p>
              
              {/* Separador con margen triple */}
              <div 
                style={{ 
                  borderTop: '1px solid rgba(168, 176, 198, 0.2)',
                  margin: 'clamp(6px, 0.75vh, 9px) 0 clamp(4px, 0.5vh, 6px) 0'
                }}
              />
              
              {/* *Valores integrados... en blanco destacado, más grande, con ícono info */}
              <div className="flex items-center justify-center gap-[6px] relative">
                <p 
                  className="text-[#e9eef9] text-center m-0"
                  style={{ 
                    fontSize: 'clamp(0.7rem, 0.85vw, 0.9rem)',
                    fontWeight: 600,
                    lineHeight: '1',
                    letterSpacing: '0.2px'
                  }}
                >
                  {riskData.labels.valoresIntegrados}
                </p>
                
                {/* Ícono de información con tooltip */}
                <div 
                  className="relative"
                  onMouseEnter={() => setShowTooltip(true)}
                  onMouseLeave={() => setShowTooltip(false)}
                >
                  <Info 
                    className="text-[#c47a7a] cursor-help" 
                    style={{ 
                      width: 'clamp(12px, 0.95vw, 14px)', 
                      height: 'clamp(12px, 0.95vw, 14px)',
                      flexShrink: 0
                    }} 
                  />
                  
                  {/* Tooltip */}
                  {showTooltip && (
                    <div 
                      className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 rounded-lg border border-[#c47a7a]/50 shadow-xl"
                      style={{
                        background: 'linear-gradient(180deg, #1a2540, #141a2a)',
                        padding: 'clamp(12px, 1.4vh, 16px)',
                        minWidth: '400px',
                        maxWidth: '480px',
                        zIndex: 100
                      }}
                    >
                      <p className="text-[#e9eef9] m-0" style={{ fontSize: 'clamp(0.95rem, 1.1vw, 1.15rem)', lineHeight: '1.4', marginBottom: '8px', fontWeight: 600 }}>
                        {riskData.labels.metodologiaIntegracion}
                      </p>
                      <p className="text-[#a8b0c6] m-0" style={{ fontSize: 'clamp(0.9rem, 1.05vw, 1.1rem)', lineHeight: '1.4' }}>
                        {riskData.labels.tooltipMetodologia}
                      </p>
                      {/* Flecha del tooltip */}
                      <div 
                        className="absolute top-full left-1/2 transform -translate-x-1/2"
                        style={{
                          width: 0,
                          height: 0,
                          borderLeft: '8px solid transparent',
                          borderRight: '8px solid transparent',
                          borderTop: '8px solid #1a2540'
                        }}
                      />
                    </div>
                  )}
                </div>
              </div>
            </div>

          </div>
        </div>
        
      </div>
    </div>
  );
}