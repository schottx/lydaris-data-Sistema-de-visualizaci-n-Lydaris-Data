import React, { useState, useEffect } from 'react';
import { X, FileText, Map, Video, BarChart3, QrCode } from 'lucide-react';
import { QRCodeSVG } from 'qrcode.react';

interface DigitalAssetCardProps {
  isOpen: boolean;
  onClose: () => void;
  language: 'en' | 'es';
  onNavigateToSummary: () => void;
  onNavigateToMaps: () => void;
  onNavigateToDataPanels: (index: 'hydro' | 'esi' | 'risk') => void;
  onNavigateToTour: () => void;
  onOpenLayersPanel: () => void;
  keepDataPanelMenuOpen?: boolean;
}

export function DigitalAssetCard({
  isOpen,
  onClose,
  language,
  onNavigateToSummary,
  onNavigateToMaps,
  onNavigateToDataPanels,
  onNavigateToTour,
  onOpenLayersPanel,
  keepDataPanelMenuOpen,
}: DigitalAssetCardProps) {
  const [showQR, setShowQR] = useState(false);
  const [showDataPanelMenu, setShowDataPanelMenu] = useState(false);

  // Sincronizar el estado del menú cuando cambie la prop
  useEffect(() => {
    if (keepDataPanelMenuOpen) {
      setShowDataPanelMenu(true);
    }
  }, [keepDataPanelMenuOpen]);

  if (!isOpen) return null;

  const handleClose = () => {
    setShowQR(false);
    setShowDataPanelMenu(false);
    onClose();
  };

  const t = {
    en: {
      title: 'Digital Environmental Asset Card',
      id: 'ID: LDI-RC-01-25',
      location: 'Cochamó Reserve – 917 ha',
      scale: 'Scale: Conservation · Custody · Research',
      category: 'Category: Climate Refuge',
      country: 'Country / Region: Chile – North Patagonia',
      assetType: 'Asset Type: Private Natural Area',
      ecosystemIntegrityLabel: 'Ecosystem Integrity:',
      ecosystemIntegrityValue: 'High',
      waterFunctionLabel: 'Water Functionality:',
      waterFunctionValue: 'High',
      anthropicPressureLabel: 'Anthropic Pressure:',
      anthropicPressureValue: 'Very Low',
      statusTitle: 'Status:',
      status: 'Available for acquisition and custody',
      destinationTitle: 'Potential:',
      destination: 'Conservation · Philanthropic Custody · Research · Restoration · Natural Credits',
      readinessTitle: 'Assessment Level:',
      readiness: 'Active Digital Card · Multi-Index Analysis · Risks Assessed',
      experienceTitle: 'Digital Experience:',
      experience: 'Interactive Viewer · Analytical Layers · 360° Geo-Analysis',
      signature: 'Environmental Digital Asset System – Lydaris Data Intelligence',
      summary: 'Executive Summary',
      maps: 'Interactive Maps',
      tour: '360° Tour',
      data: 'Data Panels',
      qr: 'QR',
      share: 'Share',
      hydroIndex: 'Hydro Index®',
      ecoStructuralIndex: 'Eco-Structural Index®',
      riskIndex: 'Risk Index®',
    },
    es: {
      title: 'Tarjeta Digital Activo Ambiental',
      id: 'ID: LDI-RC-01-25',
      location: 'Reserva Cochamó – 917 ha',
      scale: 'Escala: Conservación · Custodia · Investigación',
      category: 'Categoría: Refugio Climático',
      country: 'País / Región: Chile – Patagonia Norte',
      assetType: 'Tipo de Activo: Área Natural Privada',
      ecosystemIntegrityLabel: 'Integridad Ecosistémica:',
      ecosystemIntegrityValue: 'Alta',
      waterFunctionLabel: 'Funcionalidad Hídrica:',
      waterFunctionValue: 'Alta',
      anthropicPressureLabel: 'Presión Antrópica:',
      anthropicPressureValue: 'Muy Baja',
      statusTitle: 'Estatus:',
      status: 'Disponible para adquisición y custodia',
      destinationTitle: 'Potencial:',
      destination: 'Conservación · Custodia Filantrópica · Investigación · Restauración · Créditos Naturales',
      readinessTitle: 'Nivel de Evaluación:',
      readiness: 'Tarjeta Digital Activa · Análisis Multi-Índice · Riesgos Evaluados',
      experienceTitle: 'Experiencia Digital:',
      experience: 'Visor Interactivo · Capas Analíticas · Geoanálisis 360°',
      signature: 'Sistema de Activos Ambientales Digitales – Lydaris Data Intelligence',
      summary: 'Resumen Ejecutivo',
      maps: 'Mapas Interactivos',
      tour: 'Tour 360°',
      data: 'Paneles de Datos',
      qr: 'QR',
      share: 'Compartir',
      hydroIndex: 'Hydro Index®',
      ecoStructuralIndex: 'Eco-Structural Index®',
      riskIndex: 'Risk Index®',
    },
  };

  const content = t[language];
  const assetURL = `https://demo.lydarisdata.eu`;

  return (
    <>
      {/* Overlay */}
      <div
        onClick={handleClose}
        style={{
          position: 'fixed',
          inset: 0,
          background: 'rgba(0, 0, 0, 0.92)',
          zIndex: 10000,
          backdropFilter: 'blur(12px)',
        }}
      />

      {/* Card Principal */}
      <div
        style={{
          position: 'fixed',
          top: '50%',
          left: '50%',
          transform: 'translate(-50%, -50%)',
          width: '95%',
          maxWidth: '1200px',
          height: '94vh',
          background: 'linear-gradient(135deg, #0f1729 0%, #1a2540 50%, #0f1729 100%)',
          borderRadius: '16px',
          border: '2px solid rgba(6, 182, 212, 0.5)',
          boxShadow: '0 30px 90px rgba(6, 182, 212, 0.4)',
          zIndex: 10001,
          display: 'flex',
          flexDirection: 'column',
          overflow: 'hidden',
        }}
      >
        {/* QR Code de fondo */}
        <div
          style={{
            position: 'absolute',
            top: '50%',
            left: '50%',
            transform: 'translate(-50%, -50%)',
            width: '320px',
            height: '320px',
            opacity: 0.25,
            pointerEvents: 'none',
          }}
        >
          <svg width="320" height="320" viewBox="0 0 320 320" xmlns="http://www.w3.org/2000/svg">
            <circle cx="160" cy="160" r="50" fill="none" stroke="rgba(6, 182, 212, 0.6)" strokeWidth="2" strokeDasharray="4 4"/>
            <circle cx="160" cy="160" r="80" fill="none" stroke="rgba(6, 182, 212, 0.7)" strokeWidth="2" strokeDasharray="6 6"/>
            <circle cx="160" cy="160" r="110" fill="none" stroke="rgba(6, 182, 212, 0.8)" strokeWidth="2.5"/>
            <circle cx="160" cy="160" r="140" fill="none" stroke="rgba(6, 182, 212, 0.6)" strokeWidth="2" strokeDasharray="8 8"/>
            <g transform="translate(160, 160)">
              <rect x="-8" y="-8" width="16" height="16" fill="rgba(6, 182, 212, 1)" rx="2"/>
              <rect x="-20" y="-4" width="10" height="8" fill="rgba(16, 185, 129, 0.9)"/>
              <rect x="10" y="-4" width="10" height="8" fill="rgba(16, 185, 129, 0.9)"/>
              <line x1="0" y1="-8" x2="0" y2="-16" stroke="rgba(6, 182, 212, 1)" strokeWidth="2"/>
              <circle cx="0" cy="-16" r="2.5" fill="rgba(6, 182, 212, 1)"/>
            </g>
          </svg>
        </div>

        {/* Header con botón cerrar */}
        <div
          style={{
            padding: '20px 28px',
            background: 'linear-gradient(135deg, rgba(6, 182, 212, 0.15), rgba(16, 185, 129, 0.1))',
            borderBottom: '1px solid rgba(6, 182, 212, 0.3)',
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            position: 'relative',
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
            <h2
              style={{
                margin: 0,
                fontSize: '1.3rem',
                fontWeight: 700,
                color: '#ffffff',
                letterSpacing: '0.5px',
                textTransform: 'uppercase',
              }}
            >
              {content.title}
            </h2>
            
            <span style={{ fontSize: '1.3rem', color: 'rgba(255, 255, 255, 0.4)', fontWeight: 300 }}>|</span>
            
            <div style={{ fontSize: '1.05rem', color: '#06b6d4', fontWeight: 700, fontFamily: 'monospace' }}>
              {content.id}
            </div>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
            <div style={{ fontSize: '0.75rem', color: '#06b6d4', fontWeight: 500, fontStyle: 'italic' }}>
              Powered by Lydaris Data Intelligence
            </div>

            <button
              onClick={handleClose}
              style={{
                background: 'rgba(239, 68, 68, 0.15)',
                border: '1px solid rgba(239, 68, 68, 0.4)',
                borderRadius: '8px',
                width: '32px',
                height: '32px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                cursor: 'pointer',
                transition: 'all 0.2s',
              }}
              onMouseEnter={(e) => e.currentTarget.style.background = 'rgba(239, 68, 68, 0.3)'}
              onMouseLeave={(e) => e.currentTarget.style.background = 'rgba(239, 68, 68, 0.15)'}
            >
              <X size={16} color="#ef4444" />
            </button>
          </div>
        </div>

        {/* Contenido Principal - 2 Columnas */}
        <div style={{ display: 'flex', gap: '28px', padding: '18px 28px', flex: 1, overflow: 'hidden' }}>
          
          {/* Columna Izquierda - Información */}
          <div style={{ flex: '1.3', display: 'flex', flexDirection: 'column', gap: '20px' }}>
            
            {/* Información Básica */}
            <InfoSection>
              <InfoLine text={content.location} color="#10b981" bold large />
              <div style={{ height: '6px' }} />
              <InfoLine text={content.scale} color="#cbd5e1" large />
              <div style={{ height: '6px' }} />
              <InfoLine text={content.category} color="#06b6d4" bold large />
            </InfoSection>

            {/* Ubicación y Tipo */}
            <InfoSection>
              <InfoLine text={content.country} color="#e2e8f0" />
              <InfoLine text={content.assetType} color="#10b981" bold />
            </InfoSection>

            <div style={{ height: '20px' }} />

            {/* Estado, Destino, Preparación y Experiencia */}
            <InfoSection>
              <InfoLine text={content.statusTitle} color="#06b6d4" bold large />
              <InfoLine text={content.status} color="#ffffff" />
              <div style={{ height: '8px' }} />
              <InfoLine text={content.destinationTitle} color="#818cf8" bold />
              <InfoLine text={content.destination} color="#c7d2fe" small />
              <div style={{ height: '8px' }} />
              <InfoLine text={content.readinessTitle} color="#10b981" bold />
              <InfoLine text={content.readiness} color="#d1fae5" small />
              <div style={{ height: '8px' }} />
              <InfoLine text={content.experienceTitle} color="#06b6d4" bold />
              <InfoLine text={content.experience} color="#cffafe" small />
            </InfoSection>

          </div>

          {/* Columna Derecha - Acciones */}
          <div style={{ flex: '0.7', display: 'flex', flexDirection: 'column', gap: '10px', justifyContent: 'space-between' }}>
            
            {/* Grid 2x2 de acciones */}
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gridTemplateRows: 'repeat(2, 1fr)', gap: '10px', height: '360px' }}>
              <CompactActionCard
                icon={<FileText size={24} />}
                title={content.summary}
                color="#6366f1"
                onClick={() => {
                  onNavigateToSummary();
                  handleClose();
                }}
              />
              <CompactActionCard
                icon={<Map size={24} />}
                title={content.maps}
                color="#06b6d4"
                onClick={onOpenLayersPanel}
              />
              {!showDataPanelMenu ? (
                <CompactActionCard
                  icon={<BarChart3 size={24} />}
                  title={content.data}
                  color="#06b6d4"
                  onClick={() => setShowDataPanelMenu(true)}
                />
              ) : (
                <div
                  style={{
                    background: 'linear-gradient(135deg, #06b6d415, #06b6d408)',
                    border: '2px solid #06b6d440',
                    borderRadius: '10px',
                    padding: '8px',
                    display: 'flex',
                    flexDirection: 'column',
                    gap: '6px',
                    position: 'relative',
                  }}
                  onClick={(e) => e.stopPropagation()}
                >
                  <button
                    onClick={() => setShowDataPanelMenu(false)}
                    style={{
                      position: 'absolute',
                      top: '4px',
                      right: '4px',
                      background: 'rgba(239, 68, 68, 0.15)',
                      border: '1px solid rgba(239, 68, 68, 0.3)',
                      borderRadius: '4px',
                      width: '20px',
                      height: '20px',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      cursor: 'pointer',
                      transition: 'all 0.2s',
                      zIndex: 10,
                    }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.background = 'rgba(239, 68, 68, 0.3)';
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.background = 'rgba(239, 68, 68, 0.15)';
                    }}
                  >
                    <X size={10} color="#ef4444" />
                  </button>

                  <button
                    onClick={() => {
                      onNavigateToDataPanels('hydro');
                    }}
                    style={{
                      background: 'linear-gradient(135deg, rgba(6, 182, 212, 0.2), rgba(6, 182, 212, 0.1))',
                      border: '1px solid rgba(6, 182, 212, 0.5)',
                      borderRadius: '6px',
                      padding: '8px',
                      cursor: 'pointer',
                      transition: 'all 0.2s',
                      textAlign: 'center',
                      color: '#ffffff',
                      fontSize: '0.7rem',
                      fontWeight: 600,
                      lineHeight: '1.2',
                    }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.background = 'linear-gradient(135deg, rgba(6, 182, 212, 0.35), rgba(6, 182, 212, 0.2))';
                      e.currentTarget.style.borderColor = 'rgba(6, 182, 212, 0.7)';
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.background = 'linear-gradient(135deg, rgba(6, 182, 212, 0.2), rgba(6, 182, 212, 0.1))';
                      e.currentTarget.style.borderColor = 'rgba(6, 182, 212, 0.5)';
                    }}
                  >
                    {content.hydroIndex}
                  </button>

                  <button
                    onClick={() => {
                      onNavigateToDataPanels('esi');
                    }}
                    style={{
                      background: 'linear-gradient(135deg, rgba(16, 185, 129, 0.2), rgba(16, 185, 129, 0.1))',
                      border: '1px solid rgba(16, 185, 129, 0.5)',
                      borderRadius: '6px',
                      padding: '8px',
                      cursor: 'pointer',
                      transition: 'all 0.2s',
                      textAlign: 'center',
                      color: '#ffffff',
                      fontSize: '0.7rem',
                      fontWeight: 600,
                      lineHeight: '1.2',
                    }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.background = 'linear-gradient(135deg, rgba(16, 185, 129, 0.35), rgba(16, 185, 129, 0.2))';
                      e.currentTarget.style.borderColor = 'rgba(16, 185, 129, 0.7)';
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.background = 'linear-gradient(135deg, rgba(16, 185, 129, 0.2), rgba(16, 185, 129, 0.1))';
                      e.currentTarget.style.borderColor = 'rgba(16, 185, 129, 0.5)';
                    }}
                  >
                    {content.ecoStructuralIndex}
                  </button>

                  <button
                    onClick={() => {
                      onNavigateToDataPanels('risk');
                    }}
                    style={{
                      background: 'linear-gradient(135deg, rgba(239, 68, 68, 0.2), rgba(239, 68, 68, 0.1))',
                      border: '1px solid rgba(239, 68, 68, 0.5)',
                      borderRadius: '6px',
                      padding: '8px',
                      cursor: 'pointer',
                      transition: 'all 0.2s',
                      textAlign: 'center',
                      color: '#ffffff',
                      fontSize: '0.7rem',
                      fontWeight: 600,
                      lineHeight: '1.2',
                    }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.background = 'linear-gradient(135deg, rgba(239, 68, 68, 0.35), rgba(239, 68, 68, 0.2))';
                      e.currentTarget.style.borderColor = 'rgba(239, 68, 68, 0.7)';
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.background = 'linear-gradient(135deg, rgba(239, 68, 68, 0.2), rgba(239, 68, 68, 0.1))';
                      e.currentTarget.style.borderColor = 'rgba(239, 68, 68, 0.5)';
                    }}
                  >
                    {content.riskIndex}
                  </button>
                </div>
              )}
              <CompactActionCard
                icon={<Video size={24} />}
                title={content.tour}
                color="#10b981"
                onClick={() => {
                  onNavigateToTour();
                  handleClose();
                }}
              />
            </div>

            {/* Panel de Características del Activo */}
            <div style={{ 
              background: 'rgba(6, 182, 212, 0.08)', 
              border: '1px solid rgba(6, 182, 212, 0.25)',
              borderRadius: '8px',
              padding: '14px 16px',
              display: 'flex',
              flexDirection: 'column',
              gap: '8px'
            }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.82rem', color: '#ffffff', lineHeight: '1.4' }}>
                <span>{content.ecosystemIntegrityLabel}</span>
                <span style={{ fontWeight: 600 }}>{content.ecosystemIntegrityValue}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.82rem', color: '#ffffff', lineHeight: '1.4' }}>
                <span>{content.waterFunctionLabel}</span>
                <span style={{ fontWeight: 600 }}>{content.waterFunctionValue}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.82rem', color: '#ffffff', lineHeight: '1.4' }}>
                <span>{content.anthropicPressureLabel}</span>
                <span style={{ fontWeight: 600 }}>{content.anthropicPressureValue}</span>
              </div>
            </div>

            {/* Botón QR */}
            <div style={{ display: 'flex', gap: '10px' }}>
              <FooterButton
                icon={<QrCode size={16} />}
                label={content.qr}
                onClick={() => setShowQR(!showQR)}
              />
            </div>
          </div>
        </div>

        {/* Footer - Firma */}
        <div
          style={{
            padding: '12px 28px',
            borderTop: '1px solid rgba(6, 182, 212, 0.2)',
            background: 'rgba(6, 182, 212, 0.05)',
            textAlign: 'center',
          }}
        >
          <div style={{ fontSize: '0.85rem', color: '#94a3b8', fontWeight: 600 }}>
            {content.signature}
          </div>
        </div>

        {/* QR Code Popup */}
        {showQR && (
          <div
            style={{
              position: 'absolute',
              bottom: '90px',
              right: '28px',
              background: '#ffffff',
              padding: '20px',
              borderRadius: '12px',
              boxShadow: '0 12px 40px rgba(0, 0, 0, 0.5)',
              textAlign: 'center',
              zIndex: 10002,
            }}
            onClick={(e) => e.stopPropagation()}
          >
            <button
              onClick={() => setShowQR(false)}
              style={{
                position: 'absolute',
                top: '8px',
                right: '8px',
                background: 'rgba(239, 68, 68, 0.1)',
                border: '1px solid rgba(239, 68, 68, 0.3)',
                borderRadius: '6px',
                width: '28px',
                height: '28px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                cursor: 'pointer',
                transition: 'all 0.2s',
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.background = 'rgba(239, 68, 68, 0.2)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.background = 'rgba(239, 68, 68, 0.1)';
              }}
            >
              <X size={14} color="#ef4444" />
            </button>

            <QRCodeSVG
              value={assetURL}
              size={180}
              bgColor="#ffffff"
              fgColor="#000000"
              level="H"
              includeMargin={true}
            />
            <div style={{ fontSize: '0.75rem', color: '#334155', fontWeight: 600, marginTop: '12px' }}>
              LDI-RC-01-25
            </div>
            <div style={{ fontSize: '0.7rem', color: '#64748b', marginTop: '4px' }}>
              {assetURL}
            </div>
          </div>
        )}
      </div>
    </>
  );
}

// Componentes auxiliares
function InfoSection({ children }: { children: React.ReactNode }) {
  return <div style={{ display: 'flex', flexDirection: 'column', gap: '5px' }}>{children}</div>;
}

function InfoLine({ text, color, bold, small, large }: { text: string; color: string; bold?: boolean; small?: boolean; large?: boolean }) {
  return (
    <div
      style={{
        fontSize: large ? '1.05rem' : small ? '0.88rem' : '0.95rem',
        color,
        fontWeight: bold ? 600 : 400,
        lineHeight: '1.5',
      }}
    >
      {text}
    </div>
  );
}

function CompactActionCard({ icon, title, color, onClick }: {
  icon: React.ReactNode;
  title: string;
  color: string;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      style={{
        background: `linear-gradient(135deg, ${color}15, ${color}08)`,
        border: `2px solid ${color}40`,
        borderRadius: '10px',
        padding: '16px 12px',
        cursor: 'pointer',
        transition: 'all 0.3s ease',
        textAlign: 'center',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        gap: '8px',
      }}
      onMouseEnter={(e) => {
        e.currentTarget.style.background = `linear-gradient(135deg, ${color}25, ${color}15)`;
        e.currentTarget.style.borderColor = `${color}70`;
        e.currentTarget.style.transform = 'translateY(-3px)';
        e.currentTarget.style.boxShadow = `0 8px 24px ${color}40`;
      }}
      onMouseLeave={(e) => {
        e.currentTarget.style.background = `linear-gradient(135deg, ${color}15, ${color}08)`;
        e.currentTarget.style.borderColor = `${color}40`;
        e.currentTarget.style.transform = 'translateY(0)';
        e.currentTarget.style.boxShadow = 'none';
      }}
    >
      <div
        style={{
          width: '44px',
          height: '44px',
          background: `${color}20`,
          borderRadius: '8px',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          border: `1px solid ${color}50`,
        }}
      >
        <div style={{ color }}>{icon}</div>
      </div>
      <span
        style={{
          fontSize: '0.8rem',
          fontWeight: 700,
          color: '#ffffff',
          letterSpacing: '0.2px',
          lineHeight: '1.2',
        }}
      >
        {title}
      </span>
    </button>
  );
}

function FooterButton({ icon, label, onClick }: {
  icon: React.ReactNode;
  label: string;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      style={{
        flex: 1,
        background: 'rgba(6, 182, 212, 0.1)',
        border: '1px solid rgba(6, 182, 212, 0.3)',
        borderRadius: '8px',
        padding: '10px',
        cursor: 'pointer',
        transition: 'all 0.2s',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        gap: '6px',
        fontSize: '0.75rem',
        color: '#06b6d4',
        fontWeight: 600,
      }}
      onMouseEnter={(e) => {
        e.currentTarget.style.background = 'rgba(6, 182, 212, 0.2)';
        e.currentTarget.style.borderColor = 'rgba(6, 182, 212, 0.5)';
      }}
      onMouseLeave={(e) => {
        e.currentTarget.style.background = 'rgba(6, 182, 212, 0.1)';
        e.currentTarget.style.borderColor = 'rgba(6, 182, 212, 0.3)';
      }}
    >
      {icon}
      <span>{label}</span>
    </button>
  );
}