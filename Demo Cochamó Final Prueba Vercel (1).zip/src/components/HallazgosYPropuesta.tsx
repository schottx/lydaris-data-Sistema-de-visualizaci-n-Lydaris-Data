import { useState, useEffect } from 'react';
import { ArrowLeft, Download, Printer, Share2, Mail, Copy, Check } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import SimpleSystemDiagram from './SimpleSystemDiagram';

interface HallazgosYPropuestaProps {
  onNavigate: (view: string) => void;
  backTo?: 'hydro-mapbox-test' | 'digital-asset-card';
}

export default function HallazgosYPropuesta({ onNavigate, backTo = 'hydro-mapbox-test' }: HallazgosYPropuestaProps) {
  const { language, setLanguage } = useLanguage();
  const [isDownloading, setIsDownloading] = useState(false);
  const [showShareMenu, setShowShareMenu] = useState(false);
  const [copied, setCopied] = useState(false);

  // Debug: Log cuando cambia el idioma
  console.log('HallazgosYPropuesta - Current language:', language);

  // Debug: Detectar cambios de idioma
  useEffect(() => {
    console.log('✅ LANGUAGE CHANGED TO:', language);
  }, [language]);

  const content = {
    es: {
      title: 'RESUMEN EJECUTIVO',
      location: 'Reserva Cochamó – Patagonia Chilena – 919 hectáreas',
      subtitle: 'Activo Ambiental Digital LDI - RC - 01 - 25',
      
      section1: {
        title: '1. Contexto',
        content: [
          'Reserva Cochamó, es un activo de 917 hectáreas inserto en una prístina macro zona ecológica de 1.600.000 hectáreas binacionales de la Patagonia Chileno - Argentina destinadas a conservación bajo diferentes figuras de protección como Parques, Santuarios Naturales, Reservas de la Biósfera, Reservas Estrictas y más.',
          'Este análisis multifocal incorpora el capital y sistema hídrico, el estado funcional y la integridad estructural del ecosistema y el perfil de riesgo ambiental, mediante la integración de tres índices satelitales multifuente desarrollados por Lydaris Data Intelligence: Hydro Index®, Eco-Structural Index® y Risk Index®.',
          'El objetivo es caracterizar el activo desde una perspectiva físico–ecológica y decisional, orientada a conservación, resguardo patrimonial, investigación, proyección, modelamiento, evaluación de riesgo, planificación de monitoreo de largo plazo, etc.'
        ]
      },

      section2: {
        title: '2. Caracterización del activo',
        content: [
          'El activo corresponde a un sistema cordillerano húmedo de montaña, ubicado en la ecorregión de Bosque Templado Valdiviano, con una superficie de 917 ha. (919 ha % en óptico satelital).',
          'Se inserta en un paisaje de alta complejidad geomorfológica, con fuerte influencia pluvio-nival, gradientes altitudinales marcados y presencia de múltiples microambientes asociados a fondos de valle, laderas, quebradas y zonas de acumulación hídrica.',
          'El territorio presenta una presión antrópica prácticamente inexistente y forma parte de un continuo regional de alta naturalidad.'
        ]
      },

      section3: {
        title: '3. Hallazgos principales',
        subsections: [
          {
            title: '3.1 Hydro Index®',
            content: [
              'Hydro Index® entrega un score de 55.8, correspondiente a un sistema hídrico funcional medio–alto.',
              'El territorio presenta una zona húmeda funcional equivalente al 52.8 % del AOI (485 ha), integrando agua superficial y humedales, y una fracción de agua persistente del 28.3 %, distribuida entre permanente, estacional y humedales.',
              'Esta proporción de zona húmeda funcional y fracción de agua persistente representa un patrón de alta capacidad de regulación hídrica, poco frecuente en sistemas montañosos donde la escorrentía rápida suele dominar sobre el almacenamiento. El resultado evidencia un territorio con condiciones favorables para retención, infiltración y mantención de humedad, fortaleciendo su estabilidad ecohidrológica y su resiliencia frente a variabilidad climática.',
              'Los subíndices muestran:',
              '• Conectividad hídrica alta (CH 73.1), indicando continuidad espacial del sistema.',
              '• Capacidad de regulación y retención moderada–alta (RA 67.6), asociada a almacenamiento natural y liberación gradual.',
              '• Presencia y accesibilidad media (PA 42.7), coherente con morfología abrupta.',
              '• Capacidad de amortiguación climática baja–media (CBC 23.9), propia de ambientes de montaña expuestos.',
              'En conjunto, el territorio dispone de una red hídrica funcional, bien conectada, pero heterogénea, controlada principalmente por la topografía y sostenida por aportes pluvio-nivales no distribuidos.'
            ]
          },
          {
            title: '3.2 Eco-Structural Index®',
            subtitle: 'Integridad estructural del ecosistema',
            content: [
              'Eco Structural Index® alcanza un score de 81.81, clasificado como Alto.',
              'Los subíndices indican:',
              '• Continuidad ecológica casi máxima (CE 98.86)',
              '• Densidad de conectividad muy alta (DC 90.38)',
              '• Presión antrópica (PA inverso 90.10) extremadamente baja',
              '• Vigor ecosistémico estable (EV 77.14)',
              '• Fragmentación moderada (FC 69.36), atribuible a interfaces espaciales de cobertura - heterogeneidad natural',
              'Estos resultados describen un ecosistema altamente íntegro, continuo y funcional, con arquitectura espacial compleja, dominada por reguladores naturales y sin señales de degradación estructural interna. El Vigor ecosistémico es alto dentro de un máximo continuo ecológico.'
            ]
          },
          {
            title: '3.3 Risk Index®',
            content: [
              'Risk Index® presenta un score de 39.0, correspondiente a riesgo medio.',
              'Los subíndices muestran:',
              '• Exposición Geomorfológica (GE 66.3)',
              '• Stress climático moderado (CS 44.7)',
              '• Riesgo hídrico macro moderado (RHm 54.3)',
              '• Riesgo de fragmentación muy bajo (RF 3.0)',
              '• Presión del Territorio (LD 1.6)',
              'El riesgo está dominado por drivers físicos naturales, no por presión humana.'
            ]
          }
        ]
      },

      section4: {
        title: '4. Lectura integrada multíndice',
        content: [
          'La integración de la data entregada por tres de nuestros índices describe a Reserva Cochamó como un sistema ecológico altamente íntegro y funcional, cuyo comportamiento está gobernado por su arquitectura geomorfológica y climática.',
          'Hydro Index® confirma la existencia de una red hídrica funcional, permanente, conectada y operativa.',
          'Eco Structural Index® demuestra que esta red se inserta en un paisaje con continuidad ecológica casi total, alta conectividad y mínima intervención.',
          'Risk Index® indica que los principales riesgos podrían generarse por procesos naturales (erosión, clima), no por degradación antrópica y requieren la generación de eventos climáticos exacerbados, dado que el territorio presenta cuatro décadas sin registro de eventos y/o degradación significativa.',
          'En conjunto, el activo exhibe: alta integridad + funcionalidad hídrica operativa + eventual riesgo estructural dominado por factores físicos dependientes de factores físico - climáticos extremos.'
        ]
      },

      section5: {
        title: '5. Implicancias estratégicas',
        subsections: [
          {
            title: '5.1 Conservación / Manejo',
            content: [
              'El activo presenta condiciones que justifican una prioridad alta de conservación estricta, orientada a la mantención de su arquitectura ecosistémica y funcionamiento natural. La combinación de continuidad ecológica casi total, alta conectividad estructural y presión antrópica mínima indica que el sistema opera actualmente dentro de rangos funcionales propios de un paisaje de montaña no degradado.',
              'La estrategia de manejo recomendada es de intervención mínima, enfocada en:',
              '• Prevención de ingreso de infraestructura dura.',
              '• Control temprano de vectores de perturbación externa.',
              '• Protección legal y administrativa del estatus de conservación.',
              'Dado su estado, el territorio es particularmente apto para ser definido como área de referencia ecológica (reference site), útil para comparar dinámicas de ecosistemas intervenidos versus no intervenidos en la región.'
            ]
          },
          {
            title: '5.2 Inversión / Resguardo patrimonial',
            content: [
              'Desde una perspectiva de capital natural, el activo reúne atributos propios de un refugio climático de montaña: estabilidad estructural, regulación hídrica operativa, heterogeneidad funcional y ausencia de degradación interna.',
              'Esto se traduce en un bajo riesgo de obsolescencia ecológica, ya que el valor del activo no depende de un uso productivo extractivo, sino de su integridad.',
              'El perfil es especialmente atractivo para:',
              '• Conservación privada.',
              '• Fondos de impacto ambiental.',
              '• Fundaciones patrimoniales.',
              '• Vehículos de resguardo de capital natural de largo plazo.',
              'Adicionalmente, el activo es compatible con esquemas futuros de valorización asociados a servicios ecosistémicos (p. ej., créditos de conservación, bonos de biodiversidad, programas de resiliencia climática), siempre bajo un enfoque no extractivo.'
            ]
          },
          {
            title: '5.3 Investigación, laboratorio climático y monitoreo',
            content: [
              'La Reserva Cochamó presenta condiciones excepcionales para funcionar como laboratorio natural de montaña, debido a:',
              '• Gradientes altitudinales intactos.',
              '• Sistema hídrico funcional heterogéneo.',
              '• Baja interferencia humana.',
              '• Estabilidad estructural del paisaje.',
              'Esto habilita su uso como plataforma para:',
              '• Estudios de cambio climático.',
              '• Dinámicas ecohidrológicas.',
              '• Resiliencia de ecosistemas templados húmedos.',
              '• Monitoreo de procesos geomorfológicos y erosivos.',
              '• Investigación de biodiversidad y conectividad.'
            ]
          }
        ]
      },

      section6: {
        title: '6. Posicionamiento del activo',
        content: [
          'Activo de conservación cordillerano de alta integridad estructural, baja presión antrópica y riesgo dominado por procesos físicos naturales, con valor estratégico como refugio climático de montaña y laboratorio natural para investigación científica, orientado a conservación, monitoreo y resguardo de capital natural de largo plazo.'
        ]
      },

      section7: {
        title: '7. Recomendaciones',
        content: [
          'Se recomienda avanzar hacia una segunda etapa de profundización diagnóstica del activo, ejecutando diversos índices de acuerdo al enfoque de conservación - gestión a aplicar, que pueden ser desarrollados bajo demanda.'
        ]
      },

      section8: {
        title: '8. Base metodológica del sistema',
        content: [
          'El sistema se basa en la integración de múltiples fuentes satelitales ópticas, climáticas, hidrológicas y de clasificación del territorio, procesadas bajo ventanas multianuales y agregadas a nivel píxel mediante métricas espaciales avanzadas.',
          'La metodología privilegia señales estructurales y funcionales relativamente estables, reduciendo la dependencia de estados puntuales o eventos transitorios, y permitiendo una caracterización objetiva, reproducible y no invasiva de los sistemas analizados.',
          'Este enfoque habilita la generación de métricas comparables entre territorios, consistentes en el tiempo y científicamente verificables, adecuadas tanto para evaluación aplicada como para investigación y validación independiente.'
        ]
      },

      // UI
      backButton: 'Volver',
      downloadPDF: 'Descargar PDF',
      print: 'Imprimir',
      share: 'Compartir',
      shareWhatsApp: 'WhatsApp',
      shareEmail: 'Correo',
      copyLink: 'Copiar enlace',
      linkCopiado: 'Enlace copiado',
      downloadError: 'Error al generar el PDF. Por favor, intente nuevamente.'
    },
    en: {
      title: 'EXECUTIVE SUMMARY',
      location: 'Cochamó Reserve – Chilean Patagonia – 919 hectares',
      subtitle: 'Digital Environmental Asset LDI - RC - 01 - 25',
      
      section1: {
        title: '1. Context',
        content: [
          'Cochamó Reserve, is an asset of 917 hectares located within a pristine macro-ecological zone of 1.6 million hectares spanning Chile and Argentina, dedicated to conservation under various protection figures such as Parks, Natural Sanctuaries, Biosphere Reserves, Strict Reserves, and more.',
          'This multi-focal analysis incorporates the water capital and system, the functional state and structural integrity of the ecosystem, and the environmental risk profile, through the integration of three multi-source satellite indices developed by Lydaris Data Intelligence: Hydro Index®, Eco-Structural Index® (ESI®), and Risk Index®.',
          'The objective is to characterize the asset from a physical-ecological and decision-making perspective, oriented toward conservation, heritage protection, research, projection, modeling, risk assessment, and long-term monitoring planning.'
        ]
      },

      section2: {
        title: '2. Asset characterization',
        content: [
          'The asset corresponds to a humid mountain cordilleran system, located in the Valdivian Temperate Forest ecoregion, with an approximate area of 917 ha. (919 ha % in satellite optical).',
          'It is inserted in a landscape of high geomorphological complexity, with strong pluvio-nival influence, marked altitudinal gradients, and the presence of multiple microenvironments associated with valley bottoms, slopes, ravines, and water accumulation zones.',
          'The territory presents practically non-existent anthropic pressure and is part of a regional continuum of high naturalness.'
        ]
      },

      section3: {
        title: '3. Main findings',
        subsections: [
          {
            title: '3.1 Hydro Index®',
            content: [
              'Hydro Index® delivers a score of 55.8, corresponding to a medium-high functional water system.',
              'The territory presents a functional wetland zone equivalent to 52.8% of the AOI (485 ha), integrating surface water and wetlands, and a persistent water fraction of 28.3%, distributed among permanent, seasonal, and wetlands.',
              'This proportion of functional wetland zone and persistent water fraction represents a pattern of high water regulation capacity, rarely found in mountain systems where rapid runoff typically dominates over storage. The result indicates a territory with favorable conditions for retention, infiltration, and moisture maintenance, strengthening its ecohydrological stability and resilience to climate variability.',
              'The sub-indices show:',
              '• High water connectivity (WC 73.1), indicating spatial continuity of the system.',
              '• Moderate-high regulation and retention capacity (RA 67.6), associated with natural storage and gradual release.',
              '• Medium presence and accessibility (PA 42.7), consistent with abrupt morphology.',
              '• Low-medium climate buffering capacity (CBC 23.9), characteristic of exposed mountain environments.',
              'Overall, the territory has a functional, well-connected water network, but heterogeneous and mainly controlled by topography and sustained by non-distributed pluvio-nival contributions.'
            ]
          },
          {
            title: '3.2 Eco-Structural Index®',
            subtitle: 'Structural integrity of the ecosystem',
            content: [
              'Eco Structural Index® achieves a score of 81.81, classified as High.',
              'The sub-indices indicate:',
              '• Near-maximum ecological continuity (EC 98.86)',
              '• Very high connectivity density (CD 90.38)',
              '• Extremely low anthropic pressure (Inverted PA 90.10)',
              '• Stable ecosystem vigor (EV 77.14)',
              '• Moderate fragmentation (CF 69.36), attributable to spatial coverage-heterogeneity interfaces',
              'These results describe a highly integrated, continuous, and functional ecosystem, with complex spatial architecture, dominated by natural regulators and without signs of internal structural degradation. The ecosystem vigor is high within a maximum ecological continuum.'
            ]
          },
          {
            title: '3.3 Risk Index®',
            content: [
              'Risk Index® presents a score of 39.0, corresponding to medium risk.',
              'The sub-indices show:',
              '• Geomorphological Exposure (GE 66.3)',
              '• Moderate climate stress (CS 44.7)',
              '• Moderate macro water risk (MWR 54.3)',
              '• Very low fragmentation risk (FR 3.0)',
              '• Territory Pressure (TP 1.6)',
              'The risk is dominated by natural physical drivers, not by human pressure.'
            ]
          }
        ]
      },

      section4: {
        title: '4. Integrated multi-index reading',
        content: [
          'The integration of the data provided by three of our indices describes Cochamó Reserve as a highly integrated and functional ecological system, whose behavior is governed by its geomorphological and climatic architecture.',
          'Hydro Index® confirms the existence of a functional, permanent, connected, and operational water network.',
          'Eco Structural Index® demonstrates that this network is inserted in a landscape with almost total ecological continuity, high connectivity, and minimal intervention.',
          'Risk Index® indicates that the main risks could be generated by natural processes (erosion, climate), not by anthropic degradation and require the generation of exacerbated climatic events, given that the territory has four decades without a record of events and/or significant degradation.',
          'Overall, the asset exhibits: high integrity + operational water functionality + eventual structural risk dominated by physical factors dependent on extreme physical-climatic factors.'
        ]
      },

      section5: {
        title: '5. Strategic implications',
        subsections: [
          {
            title: '5.1 Conservation / Management',
            content: [
              'The asset presents conditions that justify a high priority for strict conservation, oriented toward maintaining its ecosystem architecture and natural functioning. The combination of almost total ecological continuity, high structural connectivity, and minimal anthropic pressure indicates that the system currently operates within functional ranges typical of a non-degraded mountain landscape.',
              'The recommended management strategy is minimal intervention, focused on:',
              '• Prevention of hard infrastructure entry.',
              '• Early control of external disturbance vectors.',
              '• Legal and administrative protection of conservation status.',
              'Given its state, the territory is particularly suitable to be defined as an ecological reference area (reference site), useful for comparing dynamics of intervened versus non-intervened ecosystems in the region.'
            ]
          },
          {
            title: '5.2 Investment / Heritage protection',
            content: [
              'From a natural capital perspective, the asset brings together attributes typical of a mountain climate refuge: structural stability, operational water regulation, functional heterogeneity, and absence of internal degradation.',
              'This translates into a low risk of ecological obsolescence, since the value of the asset does not depend on extractive productive use, but on its integrity.',
              'The profile is especially attractive for:',
              '• Private conservation.',
              '• Environmental impact funds.',
              '• Heritage foundations.',
              '• Long-term natural capital protection vehicles.',
              'Additionally, the asset is compatible with future valuation schemes associated with ecosystem services (e.g., conservation credits, biodiversity bonds, climate resilience programs), always under a non-extractive approach.'
            ]
          },
          {
            title: '5.3 Research, climate laboratory, and monitoring',
            content: [
              'The Cochamó Reserve presents exceptional conditions to function as a natural mountain laboratory, due to:',
              '• Intact altitudinal gradients.',
              '• Heterogeneous functional water system.',
              '• Low human interference.',
              '• Structural stability of the landscape.',
              'This enables its use as a platform for:',
              '• Climate change studies.',
              '• Ecohydrological dynamics.',
              '• Resilience of humid temperate ecosystems.',
              '• Monitoring of geomorphological and erosive processes.',
              '• Biodiversity and connectivity research.'
            ]
          }
        ]
      },

      section6: {
        title: '6. Asset positioning',
        content: [
          'Cordilleran conservation asset of high structural integrity, low anthropic pressure, and risk dominated by natural physical processes, with strategic value as a mountain climate refuge and natural laboratory for scientific research, oriented toward conservation, monitoring, and long-term natural capital protection.'
        ]
      },

      section7: {
        title: '7. Recommendations',
        content: [
          'It is recommended to advance toward a second stage of diagnostic deepening of the asset, executing various indices according to the conservation - management approach to be applied, which can be developed on demand.'
        ]
      },

      section8: {
        title: '8. System Methodological Base',
        content: [
          'The system is based on the integration of multiple optical, climatic, hydrological, and territorial classification satellite sources, processed under multi-year windows and aggregated at the pixel level through advanced spatial metrics.',
          'The methodology prioritizes relatively stable structural and functional signals, reducing dependence on specific states or transitory events, and allowing objective, reproducible, and non-invasive characterization of the analyzed systems.',
          'This approach enables the generation of metrics that are comparable between territories, consistent over time, and scientifically verifiable, suitable for both applied assessment and research and independent validation.'
        ]
      },

      // UI
      backButton: 'Back',
      downloadPDF: 'Download PDF',
      print: 'Print',
      share: 'Share',
      shareWhatsApp: 'WhatsApp',
      shareEmail: 'Email',
      copyLink: 'Copy link',
      linkCopiado: 'Link copied',
      downloadError: 'Error generating PDF. Please try again.'
    }
  };

  const t = content[language];

  const shareURL = window.location.href;
  const shareTitle = t.title;
  const shareText = `${t.title} - ${t.location}`;

  const handleShare = (platform: string) => {
    switch (platform) {
      case 'whatsapp':
        window.open(`https://wa.me/?text=${encodeURIComponent(shareText + ' ' + shareURL)}`, '_blank');
        break;
      case 'email':
        window.location.href = `mailto:?subject=${encodeURIComponent(shareTitle)}&body=${encodeURIComponent(shareText + '\n\n' + shareURL)}`;
        break;
      case 'copy':
        navigator.clipboard.writeText(shareURL);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
        break;
    }
    setShowShareMenu(false);
  };

  const handlePrint = () => {
    window.print();
  };

  const downloadPDF = async () => {
    setIsDownloading(true);
    
    try {
      const { jsPDF } = await import('jspdf');
      
      const pdf = new jsPDF({
        orientation: 'p',
        unit: 'mm',
        format: 'a4'
      });

      const pageWidth = pdf.internal.pageSize.getWidth();
      const pageHeight = pdf.internal.pageSize.getHeight();
      const margin = 20;
      const contentWidth = pageWidth - (margin * 2);
      let yPosition = margin;

      const checkNewPage = (heightNeeded: number) => {
        if (yPosition + heightNeeded > pageHeight - margin) {
          pdf.addPage();
          yPosition = margin;
          return true;
        }
        return false;
      };

      const addText = (text: string, fontSize: number, color: number[], bold: boolean = false, indent: number = 0) => {
        pdf.setFontSize(fontSize);
        pdf.setTextColor(color[0], color[1], color[2]);
        const lines = pdf.splitTextToSize(text, contentWidth - indent);
        checkNewPage(lines.length * (fontSize * 0.4) + 5);
        pdf.text(lines, margin + indent, yPosition);
        yPosition += lines.length * (fontSize * 0.4) + 3;
      };

      // Header
      pdf.setFillColor(245, 247, 250);
      pdf.rect(0, 0, pageWidth, 60, 'F');
      
      // Logo L.D
      pdf.setTextColor(30, 30, 30);
      pdf.setFontSize(24);
      pdf.text('L.D', margin, 18);
      
      // Separator |
      pdf.setTextColor(100, 100, 100);
      pdf.setFontSize(22);
      pdf.text('|', margin + 18, 18);
      
      // Powered by Lydaris Data Intelligence
      pdf.setTextColor(80, 80, 80);
      pdf.setFontSize(10);
      pdf.text('Powered by', margin + 24, 16);
      
      pdf.setTextColor(6, 182, 212);
      pdf.setFontSize(11);
      pdf.text('Lydaris Data Intelligence', margin + 24, 21);
      
      // Title
      pdf.setTextColor(20, 20, 20);
      pdf.setFontSize(20);
      pdf.text(t.title, margin, 35);
      
      // Location
      pdf.setTextColor(60, 60, 60);
      pdf.setFontSize(13);
      pdf.text(t.location, margin, 44);
      
      // Subtitle
      pdf.setTextColor(80, 80, 80);
      pdf.setFontSize(12);
      pdf.text(t.subtitle, margin, 52);

      yPosition = 70;

      // Add all sections
      const sections = [
        t.section1,
        t.section2,
        t.section3,
        t.section4,
        t.section5,
        t.section6,
        t.section7,
        t.section8
      ];

      sections.forEach((section: any, sectionIndex: number) => {
        checkNewPage(20);
        
        // Section title
        addText(section.title, 14, [0, 50, 100], true);
        yPosition += 2;

        // Section content (first content for section 8)
        if (section.content) {
          section.content.forEach((paragraph: string) => {
            addText(paragraph, 11, [40, 40, 40], false, paragraph.startsWith('•') ? 5 : 0);
          });
          yPosition += 3;
        }

        // Intermediate title (for section 8)
        if (section.intermediateTitle) {
          checkNewPage(15);
          addText(section.intermediateTitle, 12, [0, 50, 100], true);
          yPosition += 3;
        }

        // Section intro (for section 8)
        if (section.intro) {
          section.intro.forEach((paragraph: string) => {
            addText(paragraph, 11, [40, 40, 40], false, 0);
          });
          yPosition += 3;
        }

        // Permits intro (for section 8)
        if (section.permitsIntro) {
          addText(section.permitsIntro, 11, [0, 50, 100], true);
          yPosition += 2;
        }

        // Subsections
        if (section.subsections) {
          section.subsections.forEach((subsection: any) => {
            checkNewPage(15);
            
            if (subsection.title) {
              addText(subsection.title, 11, [20, 70, 110], true, 3);
            }
            
            if (subsection.subtitle) {
              addText(subsection.subtitle, 11, [80, 80, 80], false, 3);
            }

            if (subsection.content) {
              subsection.content.forEach((paragraph: string) => {
                addText(paragraph, 11, [40, 40, 40], false, paragraph.startsWith('•') ? 8 : 3);
              });
            }
            
            yPosition += 3;
          });
        }

        yPosition += 5;
      });

      // Page numbers on all pages
      const totalPages = pdf.getNumberOfPages();
      for (let i = 1; i <= totalPages; i++) {
        pdf.setPage(i);
        
        // Footer line
        const footerY = pageHeight - 25;
        pdf.setDrawColor(180, 180, 180);
        pdf.setLineWidth(0.3);
        pdf.line(margin, footerY, pageWidth - margin, footerY);
        
        // Footer text
        pdf.setFontSize(12);
        pdf.setTextColor(60, 60, 60);
        pdf.text('Lydaris Data Intelligence © 2026', pageWidth / 2, footerY + 8, { align: 'center' });
        
        pdf.setTextColor(6, 182, 212);
        pdf.setFontSize(12);
        pdf.text('www.lydarisdata.eu', pageWidth / 2, footerY + 15, { align: 'center' });
        
        // Page number
        pdf.setFontSize(11);
        pdf.setTextColor(80, 80, 80);
        pdf.text(`${i} / ${totalPages}`, pageWidth - margin - 10, footerY + 12);
      }

      const fileName = `Lydaris_Executive_Summary_Cochamo_${new Date().toISOString().split('T')[0]}_${Date.now()}.pdf`;
      pdf.save(fileName);
      
    } catch (error) {
      console.error('Error generating PDF:', error);
      alert(t.downloadError);
    } finally {
      setIsDownloading(false);
    }
  };

  return (
    <div className="w-full h-screen bg-[#0f1220] text-white print:bg-white print:text-black overflow-y-auto print:overflow-visible print:h-auto" style={{ scrollBehavior: 'smooth' }}>
      {/* Action Bar - Fixed */}
      <div className="fixed top-0 left-0 right-0 bg-[#0f1220]/95 backdrop-blur-sm border-b border-[#1a2540] z-50 print:hidden">
        <div className="max-w-5xl mx-auto px-6 py-3 flex items-center justify-between">
          <button
            onClick={() => {
              if (backTo === 'digital-asset-card') {
                // Volver al dashboard y re-abrir la tarjeta digital
                onNavigate('hydro-mapbox-test-with-asset-card');
              } else {
                // Volver al dashboard normalmente
                onNavigate('hydro-mapbox-test');
              }
            }}
            className="flex items-center gap-2 px-3 py-2 bg-[#171f33] border border-[#243253] rounded-lg hover:bg-[#1a2540] transition-all"
          >
            <ArrowLeft className="w-4 h-4 text-[#a8b0c6]" />
            <span className="text-sm text-[#a8b0c6]">{t.backButton}</span>
          </button>

          {/* Center: Language Selector */}
          <div className="flex items-center gap-2 bg-[#171f33] border border-[#243253] rounded-lg p-1">
            <button
              onClick={() => setLanguage('es')}
              className={`px-3 py-1.5 text-sm rounded transition-all ${
                language === 'es'
                  ? 'bg-[#06b6d4] text-white font-medium'
                  : 'text-[#a8b0c6] hover:text-white'
              }`}
            >
              ES
            </button>
            <button
              onClick={() => setLanguage('en')}
              className={`px-3 py-1.5 text-sm rounded transition-all ${
                language === 'en'
                  ? 'bg-[#06b6d4] text-white font-medium'
                  : 'text-[#a8b0c6] hover:text-white'
              }`}
            >
              EN
            </button>
          </div>

          <button
            onClick={downloadPDF}
            disabled={isDownloading}
            className={`flex items-center gap-2 px-4 py-2 bg-[#06b6d4] border border-[#06b6d4] rounded-lg hover:bg-[#0891b2] transition-all ${
              isDownloading ? 'opacity-50 cursor-not-allowed' : ''
            }`}
            title={t.downloadPDF}
          >
            {isDownloading ? (
              <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
            ) : (
              <Download className="w-4 h-4 text-white" />
            )}
            <span className="text-sm text-white font-medium">{t.downloadPDF}</span>
          </button>
        </div>
      </div>

      {/* Document Content */}
      <div className="max-w-5xl mx-auto px-6 pt-24 pb-16 print:pt-0">
        {/* Header */}
        <div className="mb-8 print:mb-4">
          {/* Logo L.D | Powered by Lydaris Data Intelligence */}
          <div className="flex items-center gap-3 mb-4 print:mb-2">
            <div className="flex items-center gap-1" style={{
              fontSize: '1.2rem',
              fontWeight: 700,
              color: '#fff',
              letterSpacing: '-0.5px',
              textShadow: '0 2px 4px rgba(0, 0, 0, 0.3)'
            }}>
              <span>L</span>
              <span style={{ fontSize: '1.5rem', lineHeight: '1' }}>.</span>
              <span>D</span>
              <span style={{ 
                marginLeft: '4px',
                fontSize: '1.4rem',
                fontWeight: 300,
                opacity: 0.6
              }}>|</span>
            </div>
            <span style={{
              fontSize: '0.75rem',
              color: '#a8b0c6',
              letterSpacing: '0.3px',
              fontWeight: 400
            }}>
              Powered by{' '}
              <span style={{ color: '#06b6d4', fontWeight: 600 }} translate="no">
                Lydaris Data Intelligence
              </span>
            </span>
          </div>
          
          <h1 className="text-3xl font-bold text-[#e9eef9] mb-2 print:text-2xl print:text-black">{t.title}</h1>
          <div className="text-lg text-[#a8b0c6] mb-1 print:text-base print:text-gray-700">{t.location}</div>
          <button
            onClick={() => onNavigate('hydro-mapbox-test-with-asset-card')}
            className="text-base text-[#06b6d4] font-semibold italic hover:text-[#0ea5e9] transition-colors cursor-pointer underline decoration-dotted underline-offset-4 print:text-sm print:text-black print:no-underline print:cursor-default"
            title="Ver Tarjeta Digital del Activo"
          >
            {t.subtitle}
          </button>
          <div className="mt-4 pt-4 border-t border-[#1a2540] print:border-gray-300" />
        </div>

        {/* Sections */}
        <div className="space-y-8 print:space-y-4">
          {/* Section 1 */}
          <section>
            <h2 className="text-2xl font-semibold text-[#e9eef9] mb-3 print:text-xl print:text-black">{t.section1.title}</h2>
            <div className="space-y-3 text-[#c4cfe0] print:text-gray-800">
              {t.section1.content.map((paragraph, idx) => (
                <p key={idx} className="leading-relaxed text-base text-justify print:text-sm">{paragraph}</p>
              ))}
            </div>
          </section>

          {/* Section 2 */}
          <section>
            <h2 className="text-2xl font-semibold text-[#e9eef9] mb-3 print:text-xl print:text-black">{t.section2.title}</h2>
            <div className="space-y-3 text-[#c4cfe0] print:text-gray-800">
              {t.section2.content.map((paragraph, idx) => (
                <p key={idx} className="leading-relaxed text-base text-justify print:text-sm">{paragraph}</p>
              ))}
            </div>
          </section>

          {/* Section 3 - Main Findings */}
          <section>
            <h2 className="text-2xl font-semibold text-[#e9eef9] mb-4 print:text-xl print:text-black">{t.section3.title}</h2>
            <div className="space-y-5">
              {t.section3.subsections.map((subsection, idx) => (
                <div key={idx}>
                  <h3 className="text-xl font-medium text-[#e9eef9] mb-2 print:text-lg print:text-black">{subsection.title}</h3>
                  {subsection.subtitle && (
                    <p className="text-base text-[#a8b0c6] italic mb-2 print:text-sm print:text-gray-600">{subsection.subtitle}</p>
                  )}
                  <div className="space-y-2 text-[#c4cfe0] print:text-gray-800">
                    {subsection.content.map((paragraph, pIdx) => (
                      <p key={pIdx} className={`leading-relaxed text-base print:text-sm ${paragraph.startsWith('•') ? 'pl-4' : 'text-justify'}`}>
                        {paragraph}
                      </p>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </section>

          {/* Section 4 */}
          <section>
            <h2 className="text-2xl font-semibold text-[#e9eef9] mb-3 print:text-xl print:text-black">{t.section4.title}</h2>
            <div className="space-y-3 text-[#c4cfe0] print:text-gray-800">
              {t.section4.content.map((paragraph, idx) => (
                <p key={idx} className="leading-relaxed text-base text-justify print:text-sm">{paragraph}</p>
              ))}
            </div>
          </section>

          {/* Section 5 - Strategic Implications */}
          <section>
            <h2 className="text-2xl font-semibold text-[#e9eef9] mb-4 print:text-xl print:text-black">{t.section5.title}</h2>
            <div className="space-y-5">
              {t.section5.subsections.map((subsection, idx) => (
                <div key={idx}>
                  <h3 className="text-xl font-medium text-[#e9eef9] mb-2 print:text-lg print:text-black">{subsection.title}</h3>
                  <div className="space-y-2 text-[#c4cfe0] print:text-gray-800">
                    {subsection.content.map((paragraph, pIdx) => (
                      <p key={pIdx} className={`leading-relaxed text-base print:text-sm ${paragraph.startsWith('•') ? 'pl-4' : 'text-justify'}`}>
                        {paragraph}
                      </p>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </section>

          {/* Section 6 */}
          <section>
            <h2 className="text-2xl font-semibold text-[#e9eef9] mb-3 print:text-xl print:text-black">{t.section6.title}</h2>
            <div className="space-y-3 text-[#c4cfe0] print:text-gray-800">
              {t.section6.content.map((paragraph, idx) => (
                <p key={idx} className="leading-relaxed text-base text-justify print:text-sm">{paragraph}</p>
              ))}
            </div>
          </section>

          {/* Section 7 - Recommendations */}
          <section>
            <h2 className="text-2xl font-semibold text-[#e9eef9] mb-3 print:text-xl print:text-black">{t.section7.title}</h2>
            <div className="space-y-3 text-[#c4cfe0] mb-4 print:text-gray-800">
              {t.section7.content.map((paragraph, idx) => (
                <p key={idx} className="leading-relaxed text-base text-justify print:text-sm">{paragraph}</p>
              ))}
            </div>
          </section>

          {/* Section 8 */}
          <section>
            <h2 className="text-2xl font-semibold text-[#e9eef9] mb-3 print:text-xl print:text-black">{t.section8.title}</h2>
            <div className="space-y-3 text-[#c4cfe0] print:text-gray-800 mb-6">
              {t.section8.content.map((paragraph, idx) => (
                <p key={idx} className="leading-relaxed text-base text-justify print:text-sm">{paragraph}</p>
              ))}
            </div>
          </section>
        </div>

        {/* Footer */}
        <div className="mt-12 pt-6 border-t border-[#1a2540] text-center text-[#8a94a8] print:border-gray-300 print:text-gray-500">
          <p translate="no" className="text-sm mb-2">Lydaris Data Intelligence © {new Date().getFullYear()}</p>
          <a 
            href="https://www.lydarisdata.eu" 
            target="_blank" 
            rel="noopener noreferrer"
            className="text-sm text-[#06b6d4] hover:text-[#0ea5e9] transition-colors inline-block print:text-cyan-600"
            translate="no"
          >
            www.lydarisdata.eu
          </a>
        </div>
      </div>
    </div>
  );
}