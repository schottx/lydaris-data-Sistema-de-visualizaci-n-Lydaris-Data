import React, { useState, useRef, useEffect } from 'react';
import { X, GripVertical } from 'lucide-react';

type LayerType = 'water' | 'vegetation' | 'slopes' | 'risk';

interface LayerConfig {
  id: LayerType;
  nameEN: string;
  nameES: string;
  codeEN: string;
  codeES: string;
  color: string;
  enabled: boolean;
  opacity: number;
}

interface LayersControlPanelProps {
  isOpen: boolean;
  onClose: () => void;
  language: 'en' | 'es';
  onLayerToggle: (layerId: LayerType, enabled: boolean) => void;
  onOpacityChange: (layerId: LayerType, opacity: number) => void;
  onBackToCard: () => void;
  initialLayers?: {
    water?: boolean;
    vegetation?: boolean;
    slopes?: boolean;
    risk?: boolean;
  };
}

export function LayersControlPanel({
  isOpen,
  onClose,
  language,
  onLayerToggle,
  onOpacityChange,
  onBackToCard,
  initialLayers,
}: LayersControlPanelProps) {
  const [isDragging, setIsDragging] = useState(false);
  const [position, setPosition] = useState({ x: window.innerWidth - 340, y: 20 });
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });
  const panelRef = useRef<HTMLDivElement>(null);

  const [layers, setLayers] = useState<LayerConfig[]>([
    {
      id: 'water',
      nameEN: 'Water Classification',
      nameES: 'Clasificación de Agua',
      codeEN: 'WC',
      codeES: 'CA',
      color: '#06b6d4',
      enabled: initialLayers?.water || false,
      opacity: 0.8,
    },
    {
      id: 'vegetation',
      nameEN: 'Ecosystem Vigor',
      nameES: 'Vigor Ecosistémico',
      codeEN: 'EV',
      codeES: 'VE',
      color: '#10b981',
      enabled: initialLayers?.vegetation || false,
      opacity: 0.7,
    },
    {
      id: 'slopes',
      nameEN: 'Slope Analysis',
      nameES: 'Análisis de Pendientes',
      codeEN: 'SA',
      codeES: 'AP',
      color: '#8b5cf6',
      enabled: initialLayers?.slopes || false,
      opacity: 0.65,
    },
    {
      id: 'risk',
      nameEN: 'Risk Index',
      nameES: 'Índice de Riesgo',
      codeEN: 'RI',
      codeES: 'IR',
      color: '#ef4444',
      enabled: initialLayers?.risk || false,
      opacity: 0.75,
    },
  ]);

  const t = {
    en: {
      title: 'LAYERS',
      active: 'Active',
      inactive: 'Inactive',
      opacity: 'Opacity',
      back: '← Back',
    },
    es: {
      title: 'CAPAS',
      active: 'Activa',
      inactive: 'Inactiva',
      opacity: 'Opacidad',
      back: '← Volver',
    },
  };

  const content = t[language];

  // Actualizar posición cuando cambia el tamaño de la ventana
  useEffect(() => {
    const handleResize = () => {
      setPosition({ x: window.innerWidth - 340, y: 20 });
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Drag handlers
  const handleMouseDown = (e: React.MouseEvent) => {
    setIsDragging(true);
    setDragOffset({
      x: e.clientX - position.x,
      y: e.clientY - position.y,
    });
  };

  const handleMouseMove = (e: MouseEvent) => {
    if (!isDragging) return;
    const newX = Math.max(0, Math.min(window.innerWidth - 320, e.clientX - dragOffset.x));
    const newY = Math.max(0, Math.min(window.innerHeight - 400, e.clientY - dragOffset.y));
    setPosition({ x: newX, y: newY });
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  useEffect(() => {
    if (isDragging) {
      window.addEventListener('mousemove', handleMouseMove);
      window.addEventListener('mouseup', handleMouseUp);
      return () => {
        window.removeEventListener('mousemove', handleMouseMove);
        window.removeEventListener('mouseup', handleMouseUp);
      };
    }
  }, [isDragging, dragOffset]);

  const handleLayerToggle = (layerId: LayerType) => {
    const layer = layers.find(l => l.id === layerId);
    const newEnabledState = !layer?.enabled;
    
    // Desactivar todas las demás capas, activar solo esta
    setLayers(prev =>
      prev.map(l =>
        l.id === layerId 
          ? { ...l, enabled: newEnabledState } 
          : { ...l, enabled: false }
      )
    );
    
    // Notificar al padre para TODAS las capas
    layers.forEach(l => {
      if (l.id === layerId) {
        onLayerToggle(l.id, newEnabledState);
      } else {
        onLayerToggle(l.id, false);
      }
    });
  };

  const handleOpacityChange = (layerId: LayerType, opacity: number) => {
    setLayers(prev =>
      prev.map(layer =>
        layer.id === layerId ? { ...layer, opacity } : layer
      )
    );
    onOpacityChange(layerId, opacity);
  };

  const activeLayers = layers.filter(l => l.enabled);

  if (!isOpen) return null;

  return (
    <>
      {/* Panel flotante - esquina inferior derecha */}
      <div
        ref={panelRef}
        style={{
          position: 'fixed',
          right: '20px',
          bottom: '70px', // Subido para dejar espacio al logo de Mapbox
          width: '300px',
          background: 'rgba(15, 23, 41, 0.97)',
          borderRadius: '8px',
          border: '1px solid rgba(6, 182, 212, 0.4)',
          boxShadow: '0 8px 32px rgba(0, 0, 0, 0.7), 0 0 80px rgba(6, 182, 212, 0.15)',
          backdropFilter: 'blur(16px)',
          zIndex: 10002,
          overflow: 'hidden',
          transition: isDragging ? 'none' : 'all 0.2s ease',
          cursor: isDragging ? 'grabbing' : 'default',
          userSelect: 'none',
        }}
      >
        {/* Header compacto */}
        <div
          onMouseDown={handleMouseDown}
          style={{
            padding: '12px 14px',
            background: 'linear-gradient(135deg, rgba(6, 182, 212, 0.12), rgba(6, 182, 212, 0.06))',
            borderBottom: '1px solid rgba(6, 182, 212, 0.25)',
            cursor: 'grab',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <GripVertical size={14} color="#06b6d4" opacity={0.5} />
            <span
              style={{
                fontSize: '0.8rem',
                fontWeight: 700,
                color: '#ffffff',
                letterSpacing: '1px',
              }}
            >
              {content.title}
            </span>
            {activeLayers.length > 0 && (
              <span
                style={{
                  fontSize: '0.7rem',
                  color: '#ffffff',
                  background: 'rgba(16, 185, 129, 0.3)',
                  padding: '2px 7px',
                  borderRadius: '4px',
                  fontWeight: 700,
                  border: '1px solid rgba(16, 185, 129, 0.5)',
                }}
              >
                {activeLayers.length}
              </span>
            )}
          </div>

          <button
            onClick={onClose}
            style={{
              background: 'transparent',
              border: 'none',
              cursor: 'pointer',
              padding: '4px',
              display: 'flex',
              alignItems: 'center',
              opacity: 0.7,
              transition: 'opacity 0.2s',
            }}
            onMouseEnter={(e) => e.currentTarget.style.opacity = '1'}
            onMouseLeave={(e) => e.currentTarget.style.opacity = '0.7'}
          >
            <X size={16} color="#ef4444" />
          </button>
        </div>

        {/* Content */}
        <div style={{ padding: '14px' }}>
          {/* Layer list */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: '10px', marginBottom: '14px' }}>
            {layers.map((layer) => (
              <div
                key={layer.id}
                style={{
                  background: layer.enabled
                    ? `linear-gradient(90deg, ${layer.color}18, ${layer.color}08)`
                    : 'rgba(30, 41, 59, 0.4)',
                  border: `1px solid ${layer.enabled ? layer.color + '50' : 'rgba(71, 85, 105, 0.4)'}`,
                  borderRadius: '6px',
                  padding: '11px 13px',
                  transition: 'all 0.2s ease',
                }}
              >
                {/* Layer header */}
                <div
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    marginBottom: layer.enabled ? '11px' : '0',
                  }}
                >
                  <div style={{ display: 'flex', alignItems: 'center', gap: '11px', flex: 1 }}>
                    {/* Code badge */}
                    <div
                      style={{
                        width: '36px',
                        height: '36px',
                        borderRadius: '5px',
                        background: layer.enabled ? layer.color + '25' : 'rgba(51, 65, 85, 0.6)',
                        border: `1.5px solid ${layer.enabled ? layer.color + '70' : 'rgba(71, 85, 105, 0.6)'}`,
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        fontSize: '0.75rem',
                        fontWeight: 800,
                        color: layer.enabled ? '#ffffff' : '#94a3b8',
                        fontFamily: 'monospace',
                        letterSpacing: '-0.3px',
                      }}
                    >
                      {language === 'en' ? layer.codeEN : layer.codeES}
                    </div>

                    {/* Layer name */}
                    <div style={{ flex: 1 }}>
                      <div
                        style={{
                          fontSize: '0.85rem',
                          fontWeight: 600,
                          color: layer.enabled ? '#ffffff' : '#cbd5e1',
                          marginBottom: '3px',
                          lineHeight: '1.2',
                        }}
                      >
                        {language === 'en' ? layer.nameEN : layer.nameES}
                      </div>
                      <div
                        style={{
                          fontSize: '0.68rem',
                          color: layer.enabled ? layer.color : '#94a3b8',
                          fontFamily: 'monospace',
                          letterSpacing: '0.3px',
                          fontWeight: 600,
                        }}
                      >
                        {layer.enabled ? content.active : content.inactive}
                      </div>
                    </div>
                  </div>

                  {/* Toggle switch compacto */}
                  <button
                    onClick={() => handleLayerToggle(layer.id)}
                    style={{
                      width: '42px',
                      height: '22px',
                      borderRadius: '11px',
                      background: layer.enabled ? layer.color : '#475569',
                      border: 'none',
                      cursor: 'pointer',
                      position: 'relative',
                      transition: 'all 0.2s ease',
                      flexShrink: 0,
                      boxShadow: layer.enabled ? `0 0 12px ${layer.color}60` : 'none',
                    }}
                  >
                    <div
                      style={{
                        width: '18px',
                        height: '18px',
                        borderRadius: '50%',
                        background: '#ffffff',
                        position: 'absolute',
                        top: '2px',
                        left: layer.enabled ? '22px' : '2px',
                        transition: 'all 0.2s ease',
                        boxShadow: '0 2px 4px rgba(0,0,0,0.3)',
                      }}
                    />
                  </button>
                </div>

                {/* Opacity slider */}
                {layer.enabled && (
                  <div>
                    <div
                      style={{
                        display: 'flex',
                        justifyContent: 'space-between',
                        alignItems: 'center',
                        marginBottom: '7px',
                      }}
                    >
                      <span
                        style={{
                          fontSize: '0.68rem',
                          color: '#e2e8f0',
                          fontWeight: 600,
                          textTransform: 'uppercase',
                          letterSpacing: '0.5px',
                        }}
                      >
                        {content.opacity}
                      </span>
                      <span
                        style={{
                          fontSize: '0.75rem',
                          color: '#ffffff',
                          fontWeight: 700,
                          fontFamily: 'monospace',
                        }}
                      >
                        {Math.round(layer.opacity * 100)}%
                      </span>
                    </div>
                    <input
                      type="range"
                      min="0"
                      max="1"
                      step="0.05"
                      value={layer.opacity}
                      onChange={(e) =>
                        handleOpacityChange(layer.id, parseFloat(e.target.value))
                      }
                      style={{
                        width: '100%',
                        height: '5px',
                        borderRadius: '2.5px',
                        background: `linear-gradient(to right, ${layer.color} 0%, ${layer.color} ${layer.opacity * 100}%, #334155 ${layer.opacity * 100}%, #334155 100%)`,
                        outline: 'none',
                        cursor: 'pointer',
                        appearance: 'none',
                        WebkitAppearance: 'none',
                      }}
                    />
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* Back button */}
          <button
            onClick={onBackToCard}
            style={{
              width: '100%',
              padding: '11px',
              background: 'rgba(99, 102, 241, 0.15)',
              border: '1px solid rgba(99, 102, 241, 0.4)',
              borderRadius: '6px',
              color: '#c7d2fe',
              fontSize: '0.78rem',
              fontWeight: 700,
              cursor: 'pointer',
              transition: 'all 0.2s ease',
              textTransform: 'uppercase',
              letterSpacing: '0.8px',
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.background = 'rgba(99, 102, 241, 0.25)';
              e.currentTarget.style.borderColor = 'rgba(99, 102, 241, 0.6)';
              e.currentTarget.style.color = '#ffffff';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.background = 'rgba(99, 102, 241, 0.15)';
              e.currentTarget.style.borderColor = 'rgba(99, 102, 241, 0.4)';
              e.currentTarget.style.color = '#c7d2fe';
            }}
          >
            {content.back}
          </button>
        </div>
      </div>

      {/* Custom Slider Styles */}
      <style>{`
        input[type="range"]::-webkit-slider-thumb {
          appearance: none;
          width: 15px;
          height: 15px;
          border-radius: 50%;
          background: #ffffff;
          cursor: pointer;
          box-shadow: 0 2px 6px rgba(0, 0, 0, 0.4);
          transition: all 0.2s ease;
        }
        
        input[type="range"]::-webkit-slider-thumb:hover {
          transform: scale(1.2);
          box-shadow: 0 3px 8px rgba(0, 0, 0, 0.5);
        }
        
        input[type="range"]::-moz-range-thumb {
          width: 15px;
          height: 15px;
          border-radius: 50%;
          background: #ffffff;
          cursor: pointer;
          border: none;
          box-shadow: 0 2px 6px rgba(0, 0, 0, 0.4);
          transition: all 0.2s ease;
        }
        
        input[type="range"]::-moz-range-thumb:hover {
          transform: scale(1.2);
          box-shadow: 0 3px 8px rgba(0, 0, 0, 0.5);
        }
      `}</style>
    </>
  );
}