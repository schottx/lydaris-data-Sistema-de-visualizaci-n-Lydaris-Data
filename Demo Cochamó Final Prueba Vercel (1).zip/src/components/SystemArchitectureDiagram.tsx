import { useLanguage } from '../contexts/LanguageContext';

export default function SystemArchitectureDiagram() {
  const { language } = useLanguage();

  const content = {
    es: {
      title: 'Arquitectura del Sistema de Inteligencia Ambiental Satelital',
      coreIndicesLabel: 'ÍNDICES CORE',
      indices: [
        { name: 'Hydro Index®', desc: 'Capital y Sistema Hídrico' },
        { name: 'Eco-Structural Index®', desc: 'Estructura e Integridad Ecosistémica' },
        { name: 'Risk Index®', desc: 'Perfil de Riesgo del Activo' },
        { name: 'On Demand Index®', desc: 'Análisis personalizado' }
      ],
      platform: {
        name: 'Lydaris Data Intelligence',
        subtitle: 'Sistema de Inteligencia Ambiental Satelital'
      },
      assetsLabel: 'Activos Ambientales Digitales',
      capabilitiesLabel: 'CAPACIDADES DEL SISTEMA',
      capabilities: [
        { title: 'Monitoreo', desc: 'Actualización Satelital On Demand' },
        { title: 'Identidad Digital', desc: 'Trazabilidad - Auditoría - Certificación' },
        { title: 'Benchmarking regional', desc: 'Comparación Eco Regional' },
        { title: 'Capacidad predictiva', desc: 'Multi Foco y Multi Escenario' },
        { title: 'Dashboard decisional', desc: 'Analítica y Visualización de vanguardia' },
        { title: 'Verticales de Índices Especializados', desc: 'Hídricos – Riesgo – Resiliencia – Carbono – Biodiversidad – Climáticos - Potencial y +' }
      ]
    },
    en: {
      title: 'Satellite Environmental Intelligence System Architecture',
      coreIndicesLabel: 'CORE INDICES',
      indices: [
        { name: 'Hydro Index®', desc: 'Water Capital and System' },
        { name: 'Eco-Structural Index®', desc: 'Ecosystem Structure and Integrity' },
        { name: 'Risk Index®', desc: 'Asset Risk Profile' },
        { name: 'On Demand Index®', desc: 'Personalized Analysis' }
      ],
      platform: {
        name: 'Lydaris Data Intelligence',
        subtitle: 'Sistema de Inteligencia Ambiental Satelital'
      },
      assetsLabel: 'Digital Environmental Assets',
      capabilitiesLabel: 'SYSTEM CAPABILITIES',
      capabilities: [
        { title: 'Monitoring', desc: 'On Demand Satellite Update' },
        { title: 'Digital Identity', desc: 'Traceability - Audit - Certification' },
        { title: 'Regional benchmarking', desc: 'Eco Regional Comparison' },
        { title: 'Predictive capacity', desc: 'Multi Focus and Multi Scenario' },
        { title: 'Decision dashboard', desc: 'Cutting-edge Analytics and Visualization' },
        { title: 'Specialized Indices Verticals', desc: 'Water – Risk – Resilience – Carbon – Biodiversity – Climate - Potential and +' }
      ]
    }
  };

  const t = content[language];

  return (
    <div className="w-full bg-gradient-to-br from-[#0a0e1a] to-[#0f1729] rounded-xl p-6 border border-[#243253]">
      <h3 className="text-lg font-medium text-[#e9eef9] mb-6 text-center">
        {t.title}
      </h3>

      {/* Layer 1: Core Indices */}
      <div className="mb-4">
        <p className="text-xs font-medium text-[#8a94a8] mb-3 uppercase tracking-wide">{t.coreIndicesLabel}</p>
        <div className="grid grid-cols-2 gap-3 mb-6">
          {t.indices.map((idx, i) => (
            <div 
              key={i}
              className="bg-[#171f33] border border-[#243253] rounded-lg p-4 hover:border-[#06b6d4]/30 transition-colors"
            >
              <p className="text-sm font-medium text-[#e9eef9] mb-1 text-center" translate="no">{idx.name}</p>
              <p className="text-xs text-[#8a94a8] text-center leading-relaxed">{idx.desc}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Arrow */}
      <div className="flex justify-center mb-4">
        <div className="w-0.5 h-8 bg-gradient-to-b from-[#243253] to-[#06b6d4]"></div>
      </div>

      {/* Layer 2: Platform */}
      <div className="bg-gradient-to-r from-[#171f33] to-[#1a2540] border border-[#243253] rounded-lg p-5 mb-4">
        <p className="text-base font-semibold text-[#e9eef9] text-center mb-1" translate="no">
          {t.platform.name}
        </p>
        <p className="text-xs text-[#a8b0c6] text-center">{t.platform.subtitle}</p>
      </div>

      {/* Arrow */}
      <div className="flex justify-center mb-4">
        <div className="w-0.5 h-8 bg-gradient-to-b from-[#06b6d4] to-[#243253]"></div>
      </div>

      {/* Result: Digital Environmental Assets */}
      <div className="bg-[#06b6d4]/10 border-2 border-[#06b6d4]/40 rounded-lg p-4 mb-4">
        <p className="text-base font-semibold text-[#06b6d4] text-center">
          {t.assetsLabel}
        </p>
      </div>

      {/* Arrow */}
      <div className="flex justify-center mb-4">
        <div className="w-0.5 h-8 bg-gradient-to-b from-[#243253] to-[#06b6d4]"></div>
      </div>

      {/* Layer 3: Capabilities */}
      <div>
        <p className="text-xs font-medium text-[#8a94a8] mb-3 uppercase tracking-wide">{t.capabilitiesLabel}</p>
        <div className="grid grid-cols-2 gap-3">
          {t.capabilities.map((cap, i) => (
            <div 
              key={i}
              className="bg-[#171f33] border border-[#243253] rounded-lg p-3 hover:border-[#06b6d4]/30 transition-colors"
            >
              <p className="text-sm font-medium text-[#e9eef9] mb-1">{cap.title}</p>
              <p className="text-xs text-[#8a94a8] leading-relaxed">{cap.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}