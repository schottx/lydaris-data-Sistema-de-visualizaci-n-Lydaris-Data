/*
 * ==============================================
 * LYDARIS INTERACTIVE DASHBOARD
 * Sistema de índices con paneles laterales
 * ==============================================
 */

import React, { useRef, useEffect, useState } from 'react';
import mapboxgl from 'mapbox-gl';
import 'mapbox-gl/dist/mapbox-gl.css';
import { ChevronDown, ChevronRight, ZoomIn, ZoomOut, Maximize, Minimize, X, Repeat, Pause, Info, LocateFixed, Video, StopCircle, FileText, Search, GripVertical, Volume2, Layers, Camera, Satellite, Download, Database } from 'lucide-react';
import { riverGeoJSON } from '../data/river';
import { reservaCochamoCoordinates } from '../data/aoi_cochamo';
import { translations, type Language } from '../utils/translations';
import { useLanguage } from '../contexts/LanguageContext';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from './ui/tooltip';
import { Tour360 } from './Tour360';
import { DigitalAssetCard } from './DigitalAssetCard';
import { LayersControlPanel } from './LayersControlPanel';
import { DigitalAssetMapViewer } from './DigitalAssetMapViewer';

// ⭐ CONFIGURACIÓN CENTRALIZADA - Todas las URLs en un solo lugar
import { MAPBOX_CONFIG, VECTOR_SOURCES, TILE_SOURCES, DEFAULT_LOCATION } from '../config/data-sources';

// ⭐ DATOS CENTRALIZADOS DE ÍNDICES
import { INDICES_VALUES } from '../data/indices-data';

// ⭐ FALLBACK LOCAL DE AGUA (si el servidor falla)
import { waterClassificationGeoJSON } from '../data/water-classification';

// Token de Mapbox desde configuración centralizada
const MAPBOX_TOKEN = MAPBOX_CONFIG.token;

// ============================================
// CONFIGURACIÓN DE VISIBILIDAD DE FUNCIONES
// ============================================
const SHOW_CAMERA_RECORDING = false; // Cambiar a true para mostrar funciones de cámara/grabación

// ============================================
// CONFIGURACIÓN CAPAS DE AGUA
// ============================================
// ❌ RASTER (Tiles PNG) - DESACTIVADO
// ��� VECTORIAL (GeoJSON) - ACTIVO
// URL: https://data.lydarisdata.eu/vector/water-classification.geojson
// La capa vectorial se carga automáticamente al iniciar el mapa
// 3 CLASES: 1=Agua permanente (azul oscuro), 2=Agua estacional (celeste), 3=Humedal (verde)
// ============================================

// Suprimir warnings técnicos de Mapbox que no afectan la funcionalidad
const originalWarn = console.warn;
console.warn = (...args) => {
  const message = args[0];
  if (typeof message === 'string' && 
      (message.includes('featureNamespace') || 
       message.includes('place-labels') ||
       message.includes('selector is not associated'))) {
    return; // Suprimir este warning específico
  }
  originalWarn.apply(console, args);
};

// Suprimir errores de tiles faltantes (EV layer en desarrollo)
const originalError = console.error;
console.error = (...args) => {
  const message = args[0];
  if (typeof message === 'string' && 
      (message.includes('[Mapbox Error Crítico]: Failed to fetch') || 
       message.includes('tiles_EV_RGBA_2025') ||
       message.includes('ev-tiles'))) {
    // Suprimir errores de tiles EV faltantes - layer en desarrollo
    return;
  }
  originalError.apply(console, args);
};

// Función para calcular distancia entre dos puntos (Haversine)
function haversineDistance(coord1: number[], coord2: number[]): number {
  const R = 6371000; // Radio de la Tierra en metros
  const lat1 = coord1[1] * Math.PI / 180;
  const lat2 = coord2[1] * Math.PI / 180;
  const deltaLat = (coord2[1] - coord1[1]) * Math.PI / 180;
  const deltaLon = (coord2[0] - coord1[0]) * Math.PI / 180;

  const a = Math.sin(deltaLat / 2) * Math.sin(deltaLat / 2) +
    Math.cos(lat1) * Math.cos(lat2) *
    Math.sin(deltaLon / 2) * Math.sin(deltaLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

  return R * c; // Distancia en metros
}

// Función para calcular perímetro del polígono
function calculatePerimeter(coordinates: number[][]): number {
  let perimeter = 0;
  for (let i = 0; i < coordinates.length - 1; i++) {
    perimeter += haversineDistance(coordinates[i], coordinates[i + 1]);
  }
  // Cerrar el polígono (distancia entre último y primer punto)
  perimeter += haversineDistance(coordinates[coordinates.length - 1], coordinates[0]);
  return perimeter / 1000; // Convertir a kilómetros
}

// Función para calcular área del polígono (fórmula de Gauss en coordenadas geográficas)
function calculateArea(coordinates: number[][]): number {
  const R = 6371000; // Radio de la Tierra en metros
  let area = 0;

  for (let i = 0; i < coordinates.length; i++) {
    const j = (i + 1) % coordinates.length;
    const lon1 = coordinates[i][0] * Math.PI / 180;
    const lat1 = coordinates[i][1] * Math.PI / 180;
    const lon2 = coordinates[j][0] * Math.PI / 180;
    const lat2 = coordinates[j][1] * Math.PI / 180;

    area += (lon2 - lon1) * (2 + Math.sin(lat1) + Math.sin(lat2));
  }

  area = Math.abs(area * R * R / 2);
  return area / 10000; // Convertir a hectáreas
}

// Valores reales del AOI Reserva Cochamó (coordenadas importadas desde /data/aoi_cochamo.ts)
const AREA_HA = 917; // hectáreas
const PERIMETER_KM = calculatePerimeter(reservaCochamoCoordinates);

type ViewMode = 'SAT' | 'TOPO';
type TerrainMode = '2D' | '3D';
type IndexType = 'hydro' | 'esi' | 'carbon' | 'risk';
type SubLayerType = string;

interface SubLayer {
  id: SubLayerType;
  label: string;
  visible: boolean;
}

interface IndexData {
  id: IndexType;
  title: string;
  icon: string;
  hidden?: boolean; // Permite ocultar temporalmente un índice del menú
  subLayers: SubLayer[];
}

interface MapStandaloneProps {
  onBack: () => void;
  onNavigate?: (view: 'hydro-consolidado' | 'ecostruc-consolidado' | 'carbon-consolidado' | 'risk-data-consolidado' | 'carbon-data-consolidado' | 'esi-data-consolidado' | 'hallazgos-propuesta', fromSource?: 'digital-asset-card') => void;
  shouldOpenAssetCard?: boolean;
  onAssetCardClosed?: () => void;
}

export function MapStandalone({ onBack, onNavigate, shouldOpenAssetCard, onAssetCardClosed }: MapStandaloneProps) {
  const mapRef = useRef<mapboxgl.Map | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [ready, setReady] = useState(false);
  const [viewMode, setViewMode] = useState<ViewMode>('SAT');
  const [terrainMode, setTerrainMode] = useState<TerrainMode>('3D');
  const { language, setLanguage } = useLanguage(); // USAR CONTEXTO GLOBAL en lugar de estado local
  const [activeIndex, setActiveIndex] = useState<IndexType | null>(null); // Todos los índices cerrados al inicio
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [expandedAOI, setExpandedAOI] = useState(false);
  const [selectedSubIndex, setSelectedSubIndex] = useState<string | null>(null);
  const [isRotating, setIsRotating] = useState(false);
  const rotationAnimationRef = useRef<number | null>(null);
  const isRotatingRef = useRef(false);
  const pauseTimeoutRef = useRef<number | null>(null);
  const isPausedRef = useRef(false);
  const bearingRef = useRef(0); // Bearing compartido entre rotación automática y manual
  const totalRotatedRef = useRef(0); // Grados totales rotados para detectar 360° completo
  const previousStyleRef = useRef<string | null>(null); // Trackear el estilo anterior para evitar recargas innecesarias
  const waterGeoJSONRef = useRef<any>(null); // ⭐ Guardar GeoJSON de agua para recrear capas sin fetch
  

  
  // Estados para modal draggable
  const [modalPosition, setModalPosition] = useState({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const [modalDragOffset, setModalDragOffset] = useState({ x: 0, y: 0 });
  const diagnosisModalRef = useRef<HTMLDivElement>(null);
  
  // MODO LOCALIZADOR para identificar elementos
  const [locatorMode, setLocatorMode] = useState(false);
  const [hoveredLocator, setHoveredLocator] = useState<string | null>(null);
  const [lockedLocator, setLockedLocator] = useState<string | null>(null);
  
  // Estado para mantener abierto el menú de Data Panels en la Tarjeta Digital
  const [keepDataPanelMenuOpen, setKeepDataPanelMenuOpen] = useState(false);
  
  
  // Estado para la posición del logo (arrastrable)
  const [logoPosition, setLogoPosition] = useState({ bottom: 50, left: 50 });
  const [isDraggingLogo, setIsDraggingLogo] = useState(false);
  const [logoDragOffset, setLogoDragOffset] = useState({ x: 0, y: 0 });
  
  const [isRecording, setIsRecording] = useState(false);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const recordedChunksRef = useRef<Blob[]>([]);
  
  // Estado para audio de instrucciones
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);
  const speechSynthesisRef = useRef<SpeechSynthesisUtterance | null>(null);
  const [availableVoices, setAvailableVoices] = useState<SpeechSynthesisVoice[]>([]);
  
  // Estado para audio de rotación 360°
  const [isPlaying360Audio, setIsPlaying360Audio] = useState(false);
  const rotation360AudioRef = useRef<SpeechSynthesisUtterance | null>(null);
  
  // Estados para posición arrastrable del modal de clasificación hidrológica
  const [legendPosition, setLegendPosition] = useState({ x: 20, y: 20 });
  const [isDraggingLegend, setIsDraggingLegend] = useState(false);
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });
  const legendRef = useRef<HTMLDivElement>(null);
  
  // Estados para posición arrastrable del modal de estructura ecosistémica
  const [ecosystemPosition, setEcosystemPosition] = useState({ x: 20, y: 120 });
  const [isDraggingEcosystem, setIsDraggingEcosystem] = useState(false);
  const [ecosystemDragOffset, setEcosystemDragOffset] = useState({ x: 0, y: 0 });
  
  // Estado para Tour 360°
  const [isTour360Open, setIsTour360Open] = useState(false);
  const ecosystemRef = useRef<HTMLDivElement>(null);
  
  // Estado para Tarjeta Digital del Activo
  const [isDigitalAssetOpen, setIsDigitalAssetOpen] = useState(false);
  
  // Estado para Panel de Capas Interactivas
  const [isLayersPanelOpen, setIsLayersPanelOpen] = useState(false);
  
  // Estados para el mapa independiente de la Tarjeta Digital
  const [assetMapLayers, setAssetMapLayers] = useState({
    water: false,
    vegetation: false,
    slopes: false,
    risk: false,
  });
  
  const [assetMapOpacity, setAssetMapOpacity] = useState({
    water: 0.8,
    vegetation: 0.7,
    slopes: 0.6,
    risk: 0.75,
  });
  
  // Abrir automáticamente la tarjeta digital si se vuelve desde el Executive Summary
  useEffect(() => {
    if (shouldOpenAssetCard) {
      setIsDigitalAssetOpen(true);
    }
  }, [shouldOpenAssetCard]);
  
  // Estado para expandir/contraer el modal de estructura ecosistémica
  const [isEcosystemExpanded, setIsEcosystemExpanded] = useState(() => {
    const saved = localStorage.getItem('lydaris-ecosystem-expanded');
    return saved ? JSON.parse(saved) : false;
  });
  
  // 💧 Estado para capa de agua (carga instantánea)
  const [waterLayerVisible, setWaterLayerVisible] = useState(false);
  const [waterLayerOpacity, setWaterLayerOpacity] = useState(0);
  const waterAnimationRef = useRef<number | null>(null);
  const isStyleChangingRef = useRef<boolean>(false);
  
  // 🌲 Estado para capa de Estructura Vertical (EV)
  const [evLayerVisible, setEvLayerVisible] = useState(false);
  
  // 🔥 Estado para capa de Removal Risk (LSI) - Risk Index
  const [lsiLayerVisible, setLsiLayerVisible] = useState(false);
  
  // 🎬 Estado para modal de video
  const [showVideoModal, setShowVideoModal] = useState(false);
  const [isPlayingVideoAudio, setIsPlayingVideoAudio] = useState(false);
  const videoAudioRef = useRef<SpeechSynthesisUtterance | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  
  const t = translations[language];

  const [indices, setIndices] = useState<IndexData[]>([
    {
      id: 'hydro',
      title: 'Hydro Index®',
      icon: '',
      subLayers: [
        { id: 'ch', label: language === 'en' ? 'CH – Hydrological Connectivity (73.1)' : 'CH – Conectividad Hídrica (73.1)', visible: false },
        { id: 'ra', label: language === 'en' ? 'RA – Regulation / Retention (67.6)' : 'RA – Regulación / Retención (67.6)', visible: false },
        { id: 'pa', label: language === 'en' ? 'PA – Presence & Accessibility (42.7)' : 'PA – Presencia y Accesibilidad (42.7)', visible: false },
        { id: 'cbc', label: language === 'en' ? 'CBC – Climatic Buffering Capacity (23.9)' : 'CBC – Capacidad de Amortiguación Climática (23.9)', visible: false },
        { id: 'hydro-data', label: language === 'en' ? '📊 Hydro Data' : '📊 Datos Hydro', visible: false },
      ],
    },
    {
      id: 'esi',
      title: language === 'en' ? 'Eco-Structural Index®' : 'Estructura Ecosistémica®',
      icon: '',
      subLayers: [
        { id: 'ev', label: language === 'en' ? 'EV – Ecosystem Vigor (77.14)' : 'EV – Vigor Ecosistémico (77.14)', visible: false },
        { id: 'dc', label: language === 'en' ? 'DC – Connectivity Density (90.38)' : 'DC – Densidad de Conectividad (90.38)', visible: false },
        { id: 'fc', label: language === 'en' ? 'FC – Coverage Fragmentation (69.36)' : 'FC – Fragmentación de Cobertura (69.36)', visible: false },
        { id: 'pa-inv', label: language === 'en' ? 'PA⁻ – Anthropogenic Pressure (90.10)' : 'PA⁻ – Presión Antrópica (90.10)', visible: false },
        { id: 'ce', label: language === 'en' ? 'CE – Ecological Continuity (98.86)' : 'CE – Continuidad Ecológica (98.86)', visible: false },
        { id: 'esi-data', label: language === 'en' ? '📊 Eco Structural Data' : '📊 Datos Estructura Ecosistémica', visible: false },
      ],
    },
    {
      id: 'carbon',
      title: 'Carbon Index®',
      icon: '',
      hidden: true, // Temporalmente oculto - cambiar a false para reactivar
      subLayers: [
        { id: 'carbon-score', label: language === 'en' ? 'Global Score AOI (68.3)' : 'Score global del AOI (68.3)', visible: false },
        { id: 'carbon-data', label: language === 'en' ? '📊 Carbon Data' : '📊 Datos Carbon', visible: false },
      ],
    },
    {
      id: 'risk',
      title: 'Risk Index®',
      icon: '',
      subLayers: [
        { id: 'cs', label: language === 'en' ? 'CS – Climate Stress (44.75)' : 'CS – Estrés Climático (44.75)', visible: false },
        { id: 'rhm', label: language === 'en' ? 'RHm – Regional Hydrology (54.29)' : 'RHm – Hidrología Regional (54.29)', visible: false },
        { id: 'ge', label: language === 'en' ? 'GE – Geomorphological Exposure (66.31)' : 'GE – Exposición Geomorfológica (66.31)', visible: false },
        { id: 'rf', label: language === 'en' ? 'RF – Fragmentation Risk (3.00)' : 'RF – Riesgo de Fragmentación (3.00)', visible: false },
        { id: 'lp', label: language === 'en' ? 'LP – Land Pressure (1.61)' : 'LP – Presión del Territorio (1.61)', visible: false },
        { id: 'risk-data', label: language === 'en' ? '📊 Risk Data' : '📊 Datos Risk', visible: false },
      ],
    },
  ]);

  // Cambiar cursor cuando está en modo localizador
  useEffect(() => {
    if (locatorMode) {
      document.body.style.cursor = 'crosshair';
    } else {
      document.body.style.cursor = 'default';
    }
    
    return () => {
      document.body.style.cursor = 'default';
    };
  }, [locatorMode]);

  // Cargar voces disponibles para Web Speech API
  useEffect(() => {
    const loadVoices = () => {
      const voices = window.speechSynthesis.getVoices();
      console.log('='.repeat(80));
      console.log('🎤 TOTAL DE VOCES DISPONIBLES:', voices.length);
      console.log('='.repeat(80));
      voices.forEach((v, i) => {
        console.log(`  ${i + 1}. ${v.name} (${v.lang})`);
      });
      console.log('='.repeat(80));
      setAvailableVoices(voices);
    };

    // Cargar voces inmediatamente
    loadVoices();
    
    // Intentar de nuevo después de 500ms (por si no estaban listas)
    setTimeout(loadVoices, 500);
    
    // Intentar de nuevo después de 1 segundo
    setTimeout(loadVoices, 1000);

    // Escuchar cambios en las voces disponibles
    if (window.speechSynthesis.onvoiceschanged !== undefined) {
      window.speechSynthesis.onvoiceschanged = loadVoices;
    }

    return () => {
      window.speechSynthesis.onvoiceschanged = null;
    };
  }, []);

  // Actualizar labels de subíndices cuando cambie el idioma
  useEffect(() => {
    setIndices(prevIndices => prevIndices.map(index => {
      if (index.id === 'hydro') {
        return {
          ...index,
          subLayers: index.subLayers.map(sub => {
            if (sub.id === 'ch') return { ...sub, label: language === 'en' ? 'CH – Hydrological Connectivity (73.1)' : 'CH – Conectividad Hídrica (73.1)' };
            if (sub.id === 'ra') return { ...sub, label: language === 'en' ? 'RA – Regulation / Retention (67.6)' : 'RA – Regulación / Retención (67.6)' };
            if (sub.id === 'pa') return { ...sub, label: language === 'en' ? 'PA – Presence & Accessibility (42.7)' : 'PA – Presencia y Accesibilidad (42.7)' };
            if (sub.id === 'cbc') return { ...sub, label: language === 'en' ? 'CBC – Climatic Buffering Capacity (23.9)' : 'CBC – Capacidad de Amortiguación Climática (23.9)' };
            if (sub.id === 'hydro-data') return { ...sub, label: language === 'en' ? '📊 Hydro Data' : '📊 Datos Hydro' };
            return sub;
          })
        };
      }
      if (index.id === 'esi') {
        return {
          ...index,
          title: language === 'en' ? 'Eco-Structural Index®' : 'Estructura Ecosistémica®',
          subLayers: index.subLayers.map(sub => {
            if (sub.id === 'ev') return { ...sub, label: language === 'en' ? 'EV – Ecosystem Vigor (77.14)' : 'EV – Vigor Ecosistémico (77.14)' };
            if (sub.id === 'dc') return { ...sub, label: language === 'en' ? 'DC – Connectivity Density (90.38)' : 'DC – Densidad de Conectividad (90.38)' };
            if (sub.id === 'fc') return { ...sub, label: language === 'en' ? 'FC – Coverage Fragmentation (69.36)' : 'FC – Fragmentación de Cobertura (69.36)' };
            if (sub.id === 'pa-inv') return { ...sub, label: language === 'en' ? 'PA⁻ – Anthropogenic Pressure (90.10)' : 'PA⁻ – Presión Antrópica (90.10)' };
            if (sub.id === 'ce') return { ...sub, label: language === 'en' ? 'CE – Ecological Continuity (98.86)' : 'CE – Continuidad Ecológica (98.86)' };
            if (sub.id === 'esi-data') return { ...sub, label: language === 'en' ? '📊 Eco Structural Data' : '📊 Datos Estructura Ecosistémica' };
            return sub;
          })
        };
      }
      if (index.id === 'carbon') {
        return {
          ...index,
          subLayers: index.subLayers.map(sub => {
            if (sub.id === 'carbon-score') return { ...sub, label: language === 'en' ? 'Global Score AOI (68.3)' : 'Score global del AOI (68.3)' };
            if (sub.id === 'carbon-data') return { ...sub, label: language === 'en' ? '📊 Carbon Data' : '📊 Datos Carbon' };
            return sub;
          })
        };
      }
      if (index.id === 'risk') {
        return {
          ...index,
          title: language === 'en' ? 'Risk Index™' : 'Risk Index®',
          subLayers: index.subLayers.map(sub => {
            if (sub.id === 'cs') return { ...sub, label: language === 'en' ? 'CS – Climate Stress (44.75)' : 'CS – Estrés Climático (44.75)' };
            if (sub.id === 'rhm') return { ...sub, label: language === 'en' ? 'RHm – Regional Hydrology (54.29)' : 'RHm – Hidrología Regional (54.29)' };
            if (sub.id === 'ge') return { ...sub, label: language === 'en' ? 'GE – Geomorphological Exposure (66.31)' : 'GE – Exposición Geomorfológica (66.31)' };
            if (sub.id === 'rf') return { ...sub, label: language === 'en' ? 'RF – Fragmentation Risk (3.00)' : 'RF – Riesgo de Fragmentación (3.00)' };
            if (sub.id === 'lp') return { ...sub, label: language === 'en' ? 'LP – Land Pressure (1.61)' : 'LP – Presión del Territorio (1.61)' };
            if (sub.id === 'risk-data') return { ...sub, label: language === 'en' ? '📊 Risk Data' : '📊 Datos Risk' };
            return sub;
          })
        };
      }
      return index;
    }));
  }, [language]);

  // Manejar evento fullscreen del video para ajustar object-fit dinámicamente
  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    const handleFullscreenChange = () => {
      const isFullscreen = !!(
        document.fullscreenElement ||
        (document as any).webkitFullscreenElement ||
        (document as any).mozFullScreenElement ||
        (document as any).msFullscreenElement
      );

      if (isFullscreen && document.fullscreenElement === video) {
        // En fullscreen: usar cover para llenar toda la pantalla sin espacios
        video.style.objectFit = 'cover';
        video.style.width = '100vw';
        video.style.height = '100vh';
      } else {
        // Fuera de fullscreen: usar cover para llenar el modal sin espacios
        video.style.objectFit = 'cover';
        video.style.width = '100%';
        video.style.height = '100%';
      }
    };

    // Escuchar eventos de cambio de fullscreen en todos los navegadores
    document.addEventListener('fullscreenchange', handleFullscreenChange);
    document.addEventListener('webkitfullscreenchange', handleFullscreenChange);
    document.addEventListener('mozfullscreenchange', handleFullscreenChange);
    document.addEventListener('MSFullscreenChange', handleFullscreenChange);

    return () => {
      document.removeEventListener('fullscreenchange', handleFullscreenChange);
      document.removeEventListener('webkitfullscreenchange', handleFullscreenChange);
      document.removeEventListener('mozfullscreenchange', handleFullscreenChange);
      document.removeEventListener('MSFullscreenChange', handleFullscreenChange);
    };
  }, []);

  // Click listener para fijar el locator
  useEffect(() => {
    if (!locatorMode || lockedLocator) return;
    
    const handleClick = () => {
      if (hoveredLocator) {
        setLockedLocator(hoveredLocator);
      }
    };
    
    window.addEventListener('click', handleClick);
    return () => window.removeEventListener('click', handleClick);
  }, [locatorMode, hoveredLocator, lockedLocator]);

  // Inicializar mapa
  useEffect(() => {
    if (!containerRef.current) return;

    // Destruir mapa anterior si existe
    if (mapRef.current) {
      mapRef.current.remove();
      mapRef.current = null;
    }

    mapboxgl.accessToken = MAPBOX_TOKEN;
    console.log('[Mapbox] Token configurado:', MAPBOX_TOKEN.substring(0, 30) + '...');

    // Seleccionar estilo según viewMode (usar configuración centralizada)
    const mapStyle = viewMode === 'SAT'
      ? MAPBOX_CONFIG.styles.satellite
      : MAPBOX_CONFIG.styles.outdoors;

    const map = new mapboxgl.Map({
      container: containerRef.current,
      style: mapStyle,
      center: DEFAULT_LOCATION.center,
      zoom: DEFAULT_LOCATION.zoom,
      pitch: terrainMode === '3D' ? DEFAULT_LOCATION.pitch3D : 0,
      bearing: terrainMode === '3D' ? DEFAULT_LOCATION.bearing3D : 0,
      antialias: true,
      dragRotate: true,
      pitchWithRotate: true,
      attributionControl: false, // Deshabilitado - usaremos atribución personalizada
      preserveDrawingBuffer: true,
      dragPan: true, // Permitir arrastre en todas las direcciones (horizontal y vertical)
    });

    // ✅ Inicializar previousStyleRef para evitar cambios innecesarios
    previousStyleRef.current = mapStyle;

    // NO eliminar el botón de atribución "?" - mantenerlo visible para el sistema localizador
    setTimeout(() => {
      const container = containerRef.current;
      if (container) {
        // Solo eliminar el contenido expandido de atribución
        const attribInner = container.querySelector('.mapboxgl-ctrl-attrib-inner');
        if (attribInner) attribInner.remove();
        
        console.log('[Mapbox] Contenido de atribución eliminado, botón "?" mantenido');
      }
    }, 100);

    map.on('style.load', () => {
      console.log('[Mapbox] Estilo cargado:', activeIndex === 'hydro' ? 'Hydro Cochamó' : mapStyle);
      
      // Ocultar todas las etiquetas de carreteras para evitar distorsión en videos
      const roadLabelLayers = [
        'road-label',
        'road-number-shield',
        'road-exit-shield',
        'road-label-simple',
        'road-simple',
        'road-street',
        'road-minor',
        'road-major-link',
        'road-minor-link',
        'road-street-case',
        'road-primary',
        'road-secondary-tertiary',
        'road-motorway-trunk',
      ];
      
      roadLabelLayers.forEach(layerId => {
        try {
          if (map && map.getLayer(layerId)) {
            map.setLayoutProperty(layerId, 'visibility', 'none');
          }
        } catch (e) {
          // Layer doesn't exist yet
        }
      });
      
      console.log('[Mapbox] Etiquetas de carreteras ocultas');
      
      // ⭐ REACTIVADO: Etiquetas de lugares ahora VISIBLES
      // Las etiquetas de POI, ciudades, países, estados, etc. ahora se muestran en el mapa
      /* COMENTADO - Para ocultar etiquetas de lugares, descomentar este bloque
      const poiLabelLayers = [
        'poi-label',
        'airport-label',
        'settlement-subdivision-label',
        'settlement-label',
        'settlement-minor-label',
        'settlement-major-label',
        'state-label',
        'country-label',
        'continent-label',
      ];
      
      poiLabelLayers.forEach(layerId => {
        try {
          if (map && map.getLayer(layerId)) {
            map.setLayoutProperty(layerId, 'visibility', 'none');
          }
        } catch (e) {
          // Layer doesn't exist yet
        }
      });
      */
      
      console.log('[Mapbox] ✓ Etiquetas de lugares VISIBLES - Nombres de ciudades, países y regiones activados');
      
      // NO eliminar el botón "?" - mantenerlo visible
      setTimeout(() => {
        const container = containerRef.current;
        if (container) {
          // Solo eliminar el contenido expandido
          const attribInner = container.querySelector('.mapboxgl-ctrl-attrib-inner');
          if (attribInner) attribInner.remove();
          
          console.log('[Mapbox] Contenido de atribución eliminado después de style.load');
        }
      }, 200);
      
      if (terrainMode === '3D') {
        map.addSource('mapbox-dem', {
          type: 'raster-dem',
          url: MAPBOX_CONFIG.dem.url,
          tileSize: MAPBOX_CONFIG.dem.tileSize,
          maxzoom: MAPBOX_CONFIG.dem.maxzoom,
        });
        map.setTerrain({ source: 'mapbox-dem', exaggeration: 1.2 });
      }

      map.addSource('reserva-cochamo', {
        type: 'geojson',
        data: {
          type: 'Feature',
          properties: {},
          geometry: {
            type: 'Polygon',
            coordinates: [reservaCochamoCoordinates],
          },
        },
      });

      map.addLayer({
        id: 'reserva-fill',
        type: 'fill',
        source: 'reserva-cochamo',
        paint: {
          'fill-color': '#10b981',
          'fill-opacity': 0.15,
        },
      });

      map.addLayer({
        id: 'reserva-outline',
        type: 'line',
        source: 'reserva-cochamo',
        paint: {
          'line-color': '#10b981',
          'line-width': 3,
          'line-opacity': 0.8,
        },
      });

      map.addSource('rio-cochamo', {
        type: 'geojson',
        data: riverGeoJSON,
      });

      map.addLayer({
        id: 'rio-line',
        type: 'line',
        source: 'rio-cochamo',
        paint: {
          'line-color': '#3b82f6',
          'line-width': 3,
          'line-opacity': 0.8,
        },
      });

      // ============================================
      // CAPA VECTORIAL: Water Classification (442KB)
      // ============================================
      // Cargar GeoJSON vectorial desde servidor Lydaris Data
      // URL: https://data.lydarisdata.eu/vector/water-classification.geojson
      // ⭐ Función para cargar la capa de agua
      const loadWaterClassification = () => {
        console.log('[Water Classification] 🔄 Iniciando carga de GeoJSON...');
        
        // Verificar si el estilo está cargado antes de acceder a las fuentes
        try {
          if (!map.isStyleLoaded()) {
            console.log('[Water Classification] ⏸️ Estilo aún no cargado, esperando...');
            return;
          }
        } catch (err) {
          console.log('[Water Classification] ⚠️ Error verificando estilo, esperando...');
          return;
        }
        
        // Verificar si ya existe la fuente para evitar duplicados
        if (map.getSource('water-classification')) {
          console.log('[Water Classification] ℹ️ Capa ya cargada previamente');
          return;
        }

        fetch(VECTOR_SOURCES.waterClassification)
          .then(response => {
            console.log('[Water Classification] 📥 Respuesta recibida, status:', response.status);
            if (!response.ok) {
              throw new Error(`HTTP ${response.status}`);
            }
            return response.json();
          })
          .then(data => {
            console.log('[Water Classification] 📊 GeoJSON parseado, features:', data.features?.length);
            
            // ⭐ GUARDAR EN REF para reutilizar sin fetch en futuros cambios de estilo
            waterGeoJSONRef.current = data;
            console.log('[Water Classification] ✅ GeoJSON guardado en ref para reutilización');
            
            // 🔍 DIAGNÓSTICO: Inspeccionar la estructura de los primeros 3 features
            if (data.features && data.features.length > 0) {
              console.log('[Water Classification] 🔍 Muestra de properties de los primeros 3 features:');
              data.features.slice(0, 3).forEach((feature: any, idx: number) => {
                console.log(`  Feature ${idx}:`, JSON.stringify(feature.properties));
              });
            }
            
            // Verificación final con try-catch para evitar errores de duplicados
            try {
              // Verificar que el estilo sigue cargado
              if (!map.isStyleLoaded()) {
                console.log('[Water Classification] ⚠️ Estilo ya no está cargado');
                return;
              }
              
              // Verificar nuevamente antes de agregar
              if (map.getSource('water-classification')) {
                console.log('[Water Classification] ℹ️ Source ya existe, omitiendo');
                return;
              }

              // Agregar source con los datos cargados
              map.addSource('water-classification', {
                type: 'geojson',
                data: data
              });

            // Capa de polígonos con colores según CLASS
            // ⭐ La visibilidad inicial depende del estado actual de waterLayerVisible
            const initialVisibility = waterLayerVisible ? 'visible' : 'none';
            const initialOpacity = waterLayerVisible ? 0.75 : 0;
            
            map.addLayer({
              id: 'water-class-polygons',
              type: 'fill',
              source: 'water-classification',
              layout: {
                'visibility': initialVisibility
              },
              paint: {
                'fill-color': [
                  'match',
                  ['get', 'class'],
                  1, '#7dd3fc',  // Clase 1: Seasonal Water (azul claro)
                  2, '#1e7db5',  // Clase 2: Permanent Water (azul medio)
                  3, '#4ade80',  // Clase 3: Wetlands (verde)
                  '#93c5fd'      // Default: azul claro (para valores inesperados)
                ],
                'fill-opacity': initialOpacity
              }
            });

            // Capa de bordes para mejor definición
            map.addLayer({
              id: 'water-class-outline',
              type: 'line',
              source: 'water-classification',
              layout: {
                'visibility': initialVisibility
              },
              paint: {
                'line-color': '#1e3a8a',
                'line-width': 1,
                'line-opacity': waterLayerVisible ? 0.5 : 0
              }
            });
            
            console.log('[Water Classification] ✓ Capas creadas con visibilidad inicial:', initialVisibility);

              console.log('[Water Classification] ✓ Capa vectorial cargada: ' + data.features.length + ' features');
            } catch (err: any) {
              // Si el source ya existe, simplemente ignorar el error
              if (err.message && err.message.includes('already a source')) {
                console.log('[Water Classification] ��️ Source ya existe (catch), ignorando');
              } else {
                throw err; // Re-lanzar otros errores
              }
            }
          })
          .catch(error => {
            console.error('[Water Classification] ❌ Error:', error.message);
            console.log('[Water Classification] 🔄 Usando datos locales de fallback...');
            
            // Usar datos locales como fallback
            try {
              if (map.getSource('water-classification')) {
                console.log('[Water Classification] ℹ️ Source ya existe, omitiendo fallback');
                return;
              }
              
              waterGeoJSONRef.current = waterClassificationGeoJSON;
              
              map.addSource('water-classification', {
                type: 'geojson',
                data: waterClassificationGeoJSON
              });
              
              const initialVisibility = waterLayerVisible ? 'visible' : 'none';
              const initialOpacity = waterLayerVisible ? 0.75 : 0;
              
              map.addLayer({
                id: 'water-class-polygons',
                type: 'fill',
                source: 'water-classification',
                layout: { 'visibility': initialVisibility },
                paint: {
                  'fill-color': [
                    'match',
                    ['get', 'class'],
                    1, '#7dd3fc',
                    2, '#1e7db5',
                    3, '#4ade80',
                    '#93c5fd'
                  ],
                  'fill-opacity': initialOpacity
                }
              });
              
              map.addLayer({
                id: 'water-class-outline',
                type: 'line',
                source: 'water-classification',
                layout: { 'visibility': initialVisibility },
                paint: {
                  'line-color': '#1e3a8a',
                  'line-width': 1,
                  'line-opacity': waterLayerVisible ? 0.5 : 0
                }
              });
              
              console.log('[Water Classification] ✅ Fallback local cargado');
            } catch (fallbackError: any) {
              console.error('[Water Classification] ❌ Error en fallback:', fallbackError.message);
            }
          });
      };

      // ⭐ Esperar al evento 'idle' que se dispara cuando el mapa está completamente listo
      map.once('idle', loadWaterClassification);

      // ============================================
      // CAPA TILES TMS: Estructura Vertical (EV) para ESI
      // ============================================
      // URL centralizada en: /config/data-sources.ts → TILE_SOURCES.ev2025
      // Esquema TMS (inversión Y)
      map.addSource('ev-tiles', {
        type: 'raster',
        tiles: [TILE_SOURCES.ev2025],
        tileSize: 256,
        scheme: 'tms' // TMS invierte el eje Y
      });
      
      map.addLayer({
        id: 'ev-layer',
        type: 'raster',
        source: 'ev-tiles',
        layout: {
          visibility: 'none' // Inicialmente oculta (solo visible en ESI)
        },
        paint: {
          'raster-opacity': 0.8
        }
      });
      
      console.log('[EV Tiles] ✓ Capa de Estructura Vertical agregada en inicialización');

      // ============================================
      // CAPA TILES TMS: Removal Risk (LSI) para Risk Index
      // ============================================
      // URL centralizada en: /config/data-sources.ts → TILE_SOURCES.lsi2025
      // Esquema TMS (inversión Y)
      map.addSource('lsi-tiles', {
        type: 'raster',
        tiles: [TILE_SOURCES.lsi2025],
        tileSize: 256,
        scheme: 'tms' // TMS invierte el eje Y
      });
      
      map.addLayer({
        id: 'lsi-layer',
        type: 'raster',
        source: 'lsi-tiles',
        layout: {
          visibility: 'none' // Inicialmente oculta (solo visible en Risk Index)
        },
        paint: {
          'raster-opacity': 0.8
        }
      });
      
      console.log('[LSI Tiles] ✓ Capa de Removal Risk agregada en inicialización');

      // ============================================
      // ETIQUETA PERSONALIZADA: Puchegüin Reserve
      // ============================================
      // Agregar fuente de datos para la etiqueta
      map.addSource('pucheguin-label', {
        type: 'geojson',
        data: {
          type: 'Feature',
          properties: {
            title: 'Puchegüin Reserve',
            subtitle: '133,000 ha Under Conservation'
          },
          geometry: {
            type: 'Point',
            coordinates: [-72.195301, -41.472315] // Posición actualizada del marcador
          }
        }
      });

      // Agregar capa de texto con estilo verde de Mapbox
      map.addLayer({
        id: 'pucheguin-label-text',
        type: 'symbol',
        source: 'pucheguin-label',
        minzoom: 0,
        maxzoom: 24,
        layout: {
          'text-field': ['get', 'title'],
          'text-font': ['Open Sans Semibold', 'Arial Unicode MS Bold'],
          'text-size': 16,
          'text-anchor': 'center',
          'text-offset': [0, -1.2],
          'text-rotation-alignment': 'viewport',
          'text-pitch-alignment': 'viewport',
          'text-allow-overlap': true,
          'text-ignore-placement': true,
          'symbol-sort-key': 999
        },
        paint: {
          'text-color': '#b4ffb4',
          'text-opacity': 1
        }
      });

      // Agregar segunda línea de texto (subtítulo)
      map.addLayer({
        id: 'pucheguin-label-subtitle',
        type: 'symbol',
        source: 'pucheguin-label',
        minzoom: 0,
        maxzoom: 24,
        layout: {
          'text-field': ['get', 'subtitle'],
          'text-font': ['Open Sans Semibold', 'Arial Unicode MS Bold'],
          'text-size': 14,
          'text-anchor': 'center',
          'text-offset': [0, 1.2],
          'text-rotation-alignment': 'viewport',
          'text-pitch-alignment': 'viewport',
          'text-allow-overlap': true,
          'text-ignore-placement': true,
          'symbol-sort-key': 999
        },
        paint: {
          'text-color': '#b4ffb4',
          'text-opacity': 1
        }
      });

      console.log('[Puchegüin Label] ✓ Etiqueta personalizada agregada');

      // ============================================
      // ETIQUETA PERSONALIZADA: Cochamó Valley Nature Sanctuary
      // ============================================
      map.addSource('cochamo-valley-label', {
        type: 'geojson',
        data: {
          type: 'Feature',
          properties: {
            title: 'Cochamó Valley Nature Sanctuary'
          },
          geometry: {
            type: 'Point',
            coordinates: [-72.131827, -41.401306] // Posición exacta del santuario
          }
        }
      });

      // Agregar capa de texto
      map.addLayer({
        id: 'cochamo-valley-label-text',
        type: 'symbol',
        source: 'cochamo-valley-label',
        minzoom: 0,
        maxzoom: 24,
        layout: {
          'text-field': ['get', 'title'],
          'text-font': ['Open Sans Semibold', 'Arial Unicode MS Bold'],
          'text-size': 16,
          'text-anchor': 'center',
          'text-offset': [0, 0],
          'text-rotation-alignment': 'viewport',
          'text-pitch-alignment': 'viewport',
          'text-allow-overlap': true,
          'text-ignore-placement': true,
          'symbol-sort-key': 999
        },
        paint: {
          'text-color': '#b4ffb4',
          'text-opacity': 1
        }
      });

      console.log('[Cochamó Valley Label] ✓ Etiqueta personalizada agregada');

      // ============================================
      // MARCADOR: Water Rights Point
      // ============================================
      
      map.addSource('water-rights', {
        type: 'geojson',
        data: {
          type: 'Feature',
          properties: {
            title: 'Water Rights'
          },
          geometry: {
            type: 'Point',
            coordinates: [-72.20443715, -41.42195418] // Coordenadas actualizadas del punto de captación
          }
        }
      });

      // Punto sobrio y discreto
      map.addLayer({
        id: 'water-rights-circle',
        type: 'circle',
        source: 'water-rights',
        paint: {
          'circle-radius': 5,
          'circle-color': '#ffffff',
          'circle-stroke-width': 1.5,
          'circle-stroke-color': '#0f1729'
        }
      });

      // Texto sobrio
      map.addLayer({
        id: 'water-rights-label',
        type: 'symbol',
        source: 'water-rights',
        layout: {
          'text-field': ['get', 'title'],
          'text-font': ['Open Sans Regular', 'Arial Unicode MS Regular'],
          'text-size': 11,
          'text-anchor': 'left',
          'text-offset': [0.7, 0],
          'text-allow-overlap': false
        },
        paint: {
          'text-color': '#ffffff',
          'text-halo-color': '#0f1729',
          'text-halo-width': 1.5
        }
      });

      console.log('[Water Rights] ✓ Marcador agregado en coordenadas exactas');

      // Event listener para obtener coordenadas al hacer clic
      map.on('click', (e) => {
        const { lng, lat } = e.lngLat;
        console.log(`%c�� COORDENADAS DEL CLIC: [${lng.toFixed(6)}, ${lat.toFixed(6)}]`, 'background: #2d7a4f; color: white; padding: 5px 10px; font-size: 14px; font-weight: bold;');
        console.log(`Para copiar: [${lng.toFixed(6)}, ${lat.toFixed(6)}]`);
      });

      setReady(true);
    });

    mapRef.current = map;

    // ⚡ Hacer el logo nativo de Mapbox clickeable
    const makeLogoClickable = () => {
      const container = containerRef.current;
      if (container) {
        const logo = container.querySelector('.mapboxgl-ctrl-logo') as HTMLElement;
        if (logo) {
          logo.style.cursor = 'pointer';
          logo.style.pointerEvents = 'auto';
          
          const logoLink = logo.querySelector('a');
          if (logoLink) {
            logoLink.href = 'https://www.mapbox.com/';
            logoLink.target = '_blank';
            logoLink.rel = 'noopener noreferrer';
            logoLink.style.cursor = 'pointer';
            logoLink.style.pointerEvents = 'auto';
          }
          
          // Agregar evento click directo al logo SIEMPRE
          logo.addEventListener('click', (e) => {
            e.stopPropagation();
            window.open('https://www.mapbox.com/', '_blank', 'noopener,noreferrer');
          }, true);
          
          // También al contenedor del logo
          const logoContainer = logo.parentElement;
          if (logoContainer) {
            logoContainer.style.pointerEvents = 'auto';
            logoContainer.style.cursor = 'pointer';
          }
          
          console.log('✅ Logo clickeable configurado');
        }
      }
    };

    setTimeout(makeLogoClickable, 50);
    setTimeout(makeLogoClickable, 100);
    setTimeout(makeLogoClickable, 300);
    setTimeout(makeLogoClickable, 500);
    setTimeout(makeLogoClickable, 1000);
    setTimeout(makeLogoClickable, 2000);

    // Manejar imágenes faltantes para evitar errores en la consola
    map.on('styleimagemissing', (e) => {
      const id = e.id;
      // Crear una imagen vacía transparente de 1x1 píxel para cualquier imagen faltante
      if (!map.hasImage(id)) {
        const canvas = document.createElement('canvas');
        canvas.width = 1;
        canvas.height = 1;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.clearRect(0, 0, 1, 1);
          map.addImage(id, ctx.getImageData(0, 0, 1, 1));
        }
      }
    });

    // Suprimir errores de tiles faltantes para evitar llenar la consola
    map.on('error', (e) => {
      // Suprimir solo errores de tiles (Failed to fetch)
      const error = e.error;
      if (error && error.message && error.message.includes('Failed to fetch')) {
        // Silenciar estos errores - son normales cuando algunas tiles no existen en el servidor
        return;
      }
      // Otros errores se pueden loggear si son importantes
      console.warn('[Map Error]', e);
    });

    // Ocultar todos los controles de Mapbox excepto el logo
    // Esperar a que el DOM esté listo
    setTimeout(() => {
      const mapContainer = containerRef.current;
      if (mapContainer) {
        // NO eliminar el botón de atribución "?" - mantenerlo visible
        // Solo eliminar el contenido expandido
        const attribInner = mapContainer.querySelector('.mapboxgl-ctrl-attrib-inner');
        if (attribInner) {
          attribInner.remove();
        }
        
        // Ocultar controles de navegación si existen
        const navControls = mapContainer.querySelectorAll('.mapboxgl-ctrl-group');
        navControls.forEach((elem) => {
          (elem as HTMLElement).style.display = 'none';
        });
      }
    }, 500);

    // Función para agregar locator IDs a elementos de Mapbox y gestionar controles
    const setupMapboxElementsForLocator = () => {
      const mapContainer = containerRef.current;
      if (!mapContainer) return;

      // AGREGAR data-locator-id al botón de atribución "?" (mantenerlo visible)
      const attribButton = mapContainer.querySelector('.mapboxgl-ctrl-attrib-button, button[aria-label="Toggle attribution"]');
      if (attribButton && !attribButton.getAttribute('data-locator-id')) {
        attribButton.setAttribute('data-locator-id', 'MAPBOX_ATTRIBUTION_BUTTON');
        
        // Agregar event listeners para el modo locator
        (attribButton as HTMLElement).addEventListener('mouseenter', () => {
          if (locatorMode) setHoveredLocator('MAPBOX_ATTRIBUTION_BUTTON');
        });
        (attribButton as HTMLElement).addEventListener('mouseleave', () => {
          if (locatorMode) setHoveredLocator(null);
        });
      }
      
      // Aplicar estilos de hover si está en modo locator
      if (attribButton && locatorMode) {
        if (hoveredLocator === 'MAPBOX_ATTRIBUTION_BUTTON') {
          (attribButton as HTMLElement).style.outline = '2px solid #10b981';
          (attribButton as HTMLElement).style.outlineOffset = '2px';
        } else {
          (attribButton as HTMLElement).style.outline = '';
          (attribButton as HTMLElement).style.outlineOffset = '';
        }
      }

      // Eliminar el contenido de atribución expandido (el texto que aparece al hacer clic en "?")
      const attribInner = mapContainer.querySelector('.mapboxgl-ctrl-attrib-inner');
      if (attribInner) {
        attribInner.remove();
      }

      // EL LOGO DE MAPBOX Y EL BOTÓN "?" SE MANTIENEN - obligatorio por términos de uso
    };

    // Ejecutar inmediatamente
    setupMapboxElementsForLocator();

    // Ejecutar con setInterval CONTINUAMENTE cada 100ms
    const cleanupInterval = setInterval(setupMapboxElementsForLocator, 100);

    // Configurar MutationObserver para detectar cuando Mapbox añade dinámicamente elementos
    const observer = new MutationObserver(() => {
      setupMapboxElementsForLocator();
    });

    if (containerRef.current) {
      observer.observe(containerRef.current, {
        childList: true,
        subtree: true,
        attributes: true,
        attributeFilter: ['class', 'style'],
      });
    }

    return () => {
      clearInterval(cleanupInterval);
      observer.disconnect();
      if (mapRef.current) {
        mapRef.current.remove();
        mapRef.current = null;
      }
    };
  }, [viewMode, terrainMode]);

  // 💧 EFECTO: Activar/desactivar automáticamente la capa de agua según el índice activo
  useEffect(() => {
    if (!mapRef.current || !ready) return;
    
    const map = mapRef.current;
    
    const applyWaterLayerVisibility = () => {
      // Esperar a que el estilo esté cargado (salir silenciosamente)
      try {
        if (!map.isStyleLoaded()) return;
      } catch (err) {
        // Si no hay estilo cargado aún, salir silenciosamente
        return;
      }
      
      // Verificar que las capas existan (salir silenciosamente)
      const hasPolygons = map.getLayer('water-class-polygons');
      const hasOutline = map.getLayer('water-class-outline');
      
      if (!hasPolygons || !hasOutline) return;
      
      // En ESI la capa se controla manualmente, solo aplicar el estado waterLayerVisible
      // En Hydro se activa automáticamente, en otros índices se desactiva
      let shouldBeVisible = waterLayerVisible;
      let needsStateUpdate = false;
      
      if (activeIndex === 'hydro') {
        shouldBeVisible = true; // Auto-activar en Hydro
        needsStateUpdate = (waterLayerVisible !== shouldBeVisible);
      } else if (activeIndex === 'esi') {
        // En ESI: FORZAR desactivación al entrar (luego se controla manualmente con botón)
        shouldBeVisible = false;
        needsStateUpdate = (waterLayerVisible !== false);
      } else {
        shouldBeVisible = false; // Desactivar fuera de Hydro/ESI
        needsStateUpdate = (waterLayerVisible !== shouldBeVisible);
      }
      
      const targetOpacity = shouldBeVisible ? 0.75 : 0;
      const targetVisibility = shouldBeVisible ? 'visible' : 'none';
      
      // Actualizar estado cuando es necesario (Hydro auto-on, ESI forzar-off al entrar, otros off)
      if (needsStateUpdate) {
        setWaterLayerVisible(shouldBeVisible);
        setWaterLayerOpacity(targetOpacity);
      }
      
      // SIEMPRE aplicar la visibilidad visual en el mapa
      try {
        map.setLayoutProperty('water-class-polygons', 'visibility', targetVisibility);
        map.setLayoutProperty('water-class-outline', 'visibility', targetVisibility);
        map.setPaintProperty('water-class-polygons', 'fill-opacity', targetOpacity);
        map.setPaintProperty('water-class-outline', 'line-opacity', targetOpacity * 0.67);
        
        console.log(`[Water Layer] ⚡ Capa ${shouldBeVisible ? 'activada' : 'desactivada'} - Hydro: auto, ESI: manual (${activeIndex}), otros: off`);
      } catch (err) {
        // Silenciosamente ignorar errores durante la carga
        return;
      }
    };
    
    // Intentar aplicar inmediatamente
    applyWaterLayerVisibility();
    
    // Escuchar el evento styledata para cuando el estilo termine de cargar
    const onStyleData = () => {
      // SOLO aplicar auto-control en Hydro y otros índices, NO en ESI
      if (activeIndex !== 'esi') {
        applyWaterLayerVisibility();
      }
      
      // 🔒 ELIMINADO: Control de EV y LSI movido 100% al useEffect unificado (línea ~2315)
      // Eliminar la lógica de aquí evita condiciones de carrera entre styledata y useEffect
      console.log('[Style Data] Evento disparado - EV/LSI controlados exclusivamente por useEffect unificado');
    };
    
    map.on('styledata', onStyleData);
    
    return () => {
      map.off('styledata', onStyleData);
    };
  }, [activeIndex, ready, terrainMode, viewMode]); // ⚠️ NO incluir evLayerVisible, lsiLayerVisible, waterLayerVisible - causan re-renders innecesarios

  // ============================================
  // EFECTO: Manejar cambios de terrainMode (2D/3D)
  // ============================================
  useEffect(() => {
    if (!mapRef.current || !ready) return;
    
    const map = mapRef.current;
    
    // ✅ Verificar que el estilo esté completamente cargado
    try {
      if (!map.isStyleLoaded()) {
        console.log('[Terrain Mode] ⏳ Esperando a que el estilo termine de cargar...');
        
        // Esperar al evento style.load
        const onStyleLoad = () => {
          applyTerrainMode();
        };
        
        map.once('style.load', onStyleLoad);
        return () => {
          map.off('style.load', onStyleLoad);
        };
      }
      
      // Si el estilo ya está cargado, aplicar inmediatamente
      applyTerrainMode();
    } catch (err) {
      console.log('[Terrain Mode] ⚠️ Error verificando estilo');
      return;
    }
    
    function applyTerrainMode() {
      if (!mapRef.current) return;
      const map = mapRef.current;
      
      console.log('[Terrain Mode] Cambiando a:', terrainMode);
      
      // Aplicar pitch y bearing según el modo
      map.easeTo({
        pitch: terrainMode === '3D' ? 60 : 0,
        bearing: terrainMode === '3D' ? -17.6 : 0,
        duration: 800,
      });
      
      // Añadir o eliminar terrain
      if (terrainMode === '3D') {
        // Verificar si ya existe la fuente DEM
        if (!map.getSource('mapbox-dem')) {
          map.addSource('mapbox-dem', {
            type: 'raster-dem',
            url: 'mapbox://mapbox.mapbox-terrain-dem-v1',
            tileSize: 512,
            maxzoom: 14,
          });
        }
        
        const exaggeration = viewMode === 'TOPO' ? 0.8 : 1.2;
        map.setTerrain({ source: 'mapbox-dem', exaggeration });
        console.log('[Terrain Mode] Terrain 3D activado');
      } else {
        // Eliminar terrain en modo 2D
        map.setTerrain(null);
        console.log('[Terrain Mode] Terrain 3D desactivado');
      }
      
      // ⚠️ YA NO es necesario re-aplicar capas aquí porque:
      // 1. Cambiar terrain (setTerrain) NO borra las capas personalizadas
      // 2. Solo setStyle() borra las capas, y eso se maneja en el useEffect de viewMode
      console.log('[Terrain Mode] ✅ Terrain cambiado exitosamente');
    }
  }, [terrainMode, ready]);

  // Cambiar estilo del mapa cuando se cambia viewMode (SAT/TOPO)
  useEffect(() => {
    if (!mapRef.current || !ready) return;

    const map = mapRef.current;
    
    // Cambiar estilo base solo si viewMode cambió
    let newStyle: string;
    newStyle = viewMode === 'SAT'
      ? MAPBOX_CONFIG.styles.satellite
      : MAPBOX_CONFIG.styles.outdoors;
    
    // Solo recargar el estilo si realmente ha cambiado
    if (previousStyleRef.current !== newStyle) {
      console.log('[Style Switch] Cambiando a estilo base:', newStyle);
      
      // ✅ CRÍTICO: Marcar que estamos cambiando el estilo
      isStyleChangingRef.current = true;
      
      // ✅ CRÍTICO: Cancelar animaciones de agua antes de cambiar el estilo
      if (waterAnimationRef.current) {
        cancelAnimationFrame(waterAnimationRef.current);
        waterAnimationRef.current = null;
        console.log('[Style Switch] 🛑 Animación de agua cancelada antes del cambio de estilo');
      }
      
      map.setStyle(newStyle, { diff: false });
      previousStyleRef.current = newStyle;
    } else {
      console.log('[Style Switch] Estilo sin cambios, omitiendo recarga');
    }
  }, [viewMode, ready, terrainMode]);

  // ============================================
  // EFECTO: Listener PERMANENTE para recargar capas cuando cambia el estilo
  // ============================================
  useEffect(() => {
    if (!mapRef.current || !ready) return;

    const map = mapRef.current;
    
    // Manejo de errores
    map.on('error', (e) => {
      // Filtrar errores de tiles faltantes (EV y LSI layers)
      const errorMessage = e.error?.message || '';
      const sourceId = e.sourceId || '';
      
      // Suprimir errores de tiles faltantes para capas en desarrollo
      if (errorMessage.includes('Failed to fetch') && 
          (sourceId === 'ev-tiles' || sourceId === 'lsi-tiles' ||
           errorMessage.includes('tiles_EV_RGBA_2025') || 
           errorMessage.includes('tiles_LSI_RGBA_2025'))) {
        // Silenciar - tiles faltantes son esperados en los bordes del área de datos
        return;
      }
      
      // Log de otros errores del mapa
      if (e.error && !errorMessage.includes('Failed to evaluate expression')) {
        console.error('[Mapbox Error Crítico]:', errorMessage, sourceId);
      }
    });
    
    // Función handler para el evento style.load (se ejecuta cada vez que cambia el estilo)
    const handleStyleLoad = () => {
      console.log('[Hydro] Estilo cargado - iniciando configuración de capas');
      
      // ✅ Resetear la bandera de cambio de estilo
      isStyleChangingRef.current = false;
      
      // ============================================
      // ⚡ PRIORIDAD 1: Cargar capa EV para ESI
      // ============================================
      // Sistema idéntico a la capa de agua: SIEMPRE se carga, el useEffect controla la visibilidad
      console.log('[EV Tiles] ⚡ Iniciando carga prioritaria de capa EV');
      try {
        // Agregar fuente si no existe
        if (!map.getSource('ev-tiles')) {
          map.addSource('ev-tiles', {
            type: 'raster',
            tiles: [TILE_SOURCES.ev2025],
            tileSize: 256,
            scheme: 'tms' // TMS invierte el eje Y
          });
          console.log('[EV Tiles] ✓ Fuente de tiles TMS agregada');
        }
        
        // Agregar capa si no existe - visibilidad FORZADA según activeIndex (no estado React)
        if (!map.getLayer('ev-layer')) {
          // 🔒 IMPORTANTE: Usar activeIndex directamente, NO evLayerVisible (evita condiciones de carrera)
          const evInitialVisibility = activeIndex === 'esi' ? 'visible' : 'none';
          map.addLayer({
            id: 'ev-layer',
            type: 'raster',
            source: 'ev-tiles',
            layout: {
              visibility: evInitialVisibility // Visibilidad SOLO basada en activeIndex
            },
            paint: {
              'raster-opacity': 0.8
            }
          }); // Se agrega sin beforeLayer para que esté al fondo
          
          console.log('[EV Tiles] ✓ Capa agregada con visibilidad:', evInitialVisibility, '(activeIndex:', activeIndex, ')');
        }
      } catch (err) {
        console.error('[EV Tiles] Error al agregar capa:', err);
      }
      
      // ⚡ PRIORIDAD 1.5: Cargar capa LSI para Risk Index (mismo sistema que EV)
      console.log('[LSI Tiles] ⚡ Iniciando carga prioritaria de capa LSI');
      try {
        // Agregar fuente si no existe
        if (!map.getSource('lsi-tiles')) {
          map.addSource('lsi-tiles', {
            type: 'raster',
            tiles: [TILE_SOURCES.lsi2025],
            tileSize: 256,
            scheme: 'tms' // TMS invierte el eje Y
          });
          console.log('[LSI Tiles] ✓ Fuente de tiles TMS agregada');
        }
        
        // Agregar capa si no existe - visibilidad FORZADA según activeIndex (no estado React)
        if (!map.getLayer('lsi-layer')) {
          // 🔒 IMPORTANTE: Usar activeIndex directamente, NO lsiLayerVisible (evita condiciones de carrera)
          const lsiInitialVisibility = activeIndex === 'risk' ? 'visible' : 'none';
          map.addLayer({
            id: 'lsi-layer',
            type: 'raster',
            source: 'lsi-tiles',
            layout: {
              visibility: lsiInitialVisibility // Visibilidad SOLO basada en activeIndex
            },
            paint: {
              'raster-opacity': 0.8
            }
          });
          
          console.log('[LSI Tiles] ✓ Capa agregada con visibilidad:', lsiInitialVisibility, '(activeIndex:', activeIndex, ')');
        }
      } catch (err) {
        console.error('[LSI Tiles] Error al agregar capa:', err);
      }
      
      // ⚡ PRIORIDAD 2: Cargar capas de agua DESPUÉS de la capa EV
      if (waterGeoJSONRef.current && (activeIndex === 'hydro' || activeIndex === 'esi')) {
        console.log('[Water Classification] ⚡ Carga PRIORITARIA desde ref (instantáneo)');
        try {
          if (!map.getSource('water-classification')) {
            map.addSource('water-classification', {
              type: 'geojson',
              data: waterGeoJSONRef.current
            });
          }
          
          if (!map.getLayer('water-class-polygons')) {
            const initialVisibility = waterLayerVisible ? 'visible' : 'none';
            
            map.addLayer({
              id: 'water-class-polygons',
              type: 'fill',
              source: 'water-classification',
              layout: { 'visibility': initialVisibility },
              paint: {
                'fill-color': [
                  'match',
                  ['get', 'class'],
                  1, '#7dd3fc',
                  2, '#1e7db5',
                  3, '#4ade80',
                  '#93c5fd'
                ],
                'fill-opacity': 0.75
              }
            });

            map.addLayer({
              id: 'water-class-outline',
              type: 'line',
              source: 'water-classification',
              layout: { 'visibility': initialVisibility },
              paint: {
                'line-color': '#1e3a8a',
                'line-width': 1,
                'line-opacity': 0.5
              }
            });
            
            console.log('[Water Classification] ⚡ Capas cargadas INSTANTÁNEAMENTE');
          }
        } catch (err) {
          console.error('[Water Classification] Error en carga prioritaria:', err);
        }
      }
      
      if (terrainMode === '3D') {
        if (!map.getSource('mapbox-dem')) {
          map.addSource('mapbox-dem', {
            type: 'raster-dem',
            url: 'mapbox://mapbox.mapbox-terrain-dem-v1',
            tileSize: 512,
            maxzoom: 14,
          });
        }
        const exaggeration = viewMode === 'TOPO' ? 0.8 : 1.2;
        map.setTerrain({ source: 'mapbox-dem', exaggeration });
      }

      // Añadir Hillshade cuando está en modo TOPO (usa fuente separada)
      if (viewMode === 'TOPO') {
        if (!map.getSource('mapbox-dem-hillshade')) {
          map.addSource('mapbox-dem-hillshade', {
            type: 'raster-dem',
            url: MAPBOX_CONFIG.dem.url,
            tileSize: MAPBOX_CONFIG.dem.tileSize,
            maxzoom: MAPBOX_CONFIG.dem.maxzoom,
          });
        }
        
        try {
          if (map && !map.getLayer('hillshade-layer')) {
            map.addLayer({
              id: 'hillshade-layer',
              type: 'hillshade',
              source: 'mapbox-dem-hillshade',
              layout: {
                visibility: 'visible'
              },
              paint: {
                'hillshade-shadow-color': '#0f1729',
                'hillshade-illumination-direction': 315,
                'hillshade-exaggeration': 0.6
              }
            });
            console.log('[Hillshade] Capa de sombreado activada en modo TOPO con fuente separada');
          }
        } catch (e) {
          console.log('[Hillshade] Error al agregar capa:', e);
        }
      } else {
        try {
          if (map && map.getLayer('hillshade-layer')) {
            map.removeLayer('hillshade-layer');
            console.log('[Hillshade] Capa de sombreado desactivada en modo SAT');
          }
        } catch (e) {
          // Layer doesn't exist
        }
      }

      if (!map.getSource('reserva-cochamo')) {
        map.addSource('reserva-cochamo', {
          type: 'geojson',
          data: {
            type: 'Feature',
            properties: {},
            geometry: {
              type: 'Polygon',
              coordinates: [reservaCochamoCoordinates],
            },
          },
        });
      }

      try {
        if (map && !map.getLayer('reserva-fill')) {
          map.addLayer({
            id: 'reserva-fill',
            type: 'fill',
            source: 'reserva-cochamo',
            layout: {
              'visibility': 'none'
            },
            paint: {
              'fill-color': '#10b981',
              'fill-opacity': 0.15,
            },
          });
          console.log('[Hydro Setup] Capa reserva-fill creada (oculta)');
        }
      } catch (e) {
        console.log('[Hydro Setup] Error al agregar reserva-fill:', e);
      }

      try {
        if (map && !map.getLayer('reserva-outline')) {
          map.addLayer({
            id: 'reserva-outline',
            type: 'line',
            source: 'reserva-cochamo',
            layout: {
              'visibility': 'none'
            },
            paint: {
              'line-color': '#10b981',
              'line-width': 3,
              'line-opacity': 0.8,
            },
          });
          console.log('[Hydro Setup] Capa reserva-outline creada (oculta)');
        }
      } catch (e) {
        console.log('[Hydro Setup] Error al agregar reserva-outline:', e);
      }

      if (map && map.getSource && !map.getSource('rio-cochamo')) {
        map.addSource('rio-cochamo', {
          type: 'geojson',
          data: riverGeoJSON,
        });
      }

      try {
        if (map && !map.getLayer('rio-line')) {
          map.addLayer({
            id: 'rio-line',
            type: 'line',
            source: 'rio-cochamo',
            layout: {
              'visibility': 'none'
          },
          paint: {
            'line-color': '#3b82f6',
            'line-width': 3,
            'line-opacity': 0.8,
          },
        });
        console.log('[Hydro Setup] Capa rio-line creada (oculta)');
        }
      } catch (e) {
        console.log('[Hydro Setup] Error al agregar rio-line:', e);
      }

      // ============================================
      // CAPA DE AGUA - TILES RASTER PNG
      // ============================================
      // ❌ DESACTIVADO - Reemplazado por capa vectorial GeoJSON
      // La capa vectorial (water-class-polygons) tiene mayor precisión y detalle
      console.log('[Water Setup] ℹ️ Capa RASTER desactivada - usando solo VECTORIAL (GeoJSON)');
      
      // ============================================
      // FUNCIÓN AUXILIAR: Crear capas de agua con GeoJSON
      // ============================================
      const createWaterLayers = (data: any) => {
        try {
          // Verificar que el estilo sigue cargado
          if (!map.isStyleLoaded()) {
            console.log('[Water Classification] ⚠️ Estilo ya no está cargado');
            return false;
          }
          
          // ✅ VERIFICAR SI LAS CAPAS YA EXISTEN (no solo el source)
          if (map.getLayer('water-class-polygons')) {
            console.log('[Water Classification] ℹ️ Capas ya existen, omitiendo');
            return false;
          }

          // ✅ Agregar source SOLO si no existe
          if (!map.getSource('water-classification')) {
            console.log('[Water Classification] Creando source...');
            map.addSource('water-classification', {
              type: 'geojson',
              data: data
            });
          } else {
            console.log('[Water Classification] Source ya existe, reutilizando...');
          }

          // ✅ Crear las capas con visibilidad inicial según el estado actual
          const initialVisibility = waterLayerVisible ? 'visible' : 'none';
          console.log('[Water Classification] Creando capas con visibilidad inicial:', initialVisibility);
          
          map.addLayer({
            id: 'water-class-polygons',
            type: 'fill',
            source: 'water-classification',
            layout: { 'visibility': initialVisibility },
            paint: {
              'fill-color': [
                'match',
                ['get', 'class'],
                1, '#7dd3fc',
                2, '#1e7db5',
                3, '#4ade80',
                '#93c5fd'
              ],
              'fill-opacity': 0.75
            }
          });

          map.addLayer({
            id: 'water-class-outline',
            type: 'line',
            source: 'water-classification',
            layout: { 'visibility': initialVisibility },
            paint: {
              'line-color': '#1e3a8a',
              'line-width': 1,
              'line-opacity': 0.5
            }
          });

          console.log('[Water Classification] ✅ Capas creadas con visibilidad:', initialVisibility, '(' + data.features.length + ' features)');
          return true;
        } catch (err: any) {
          console.error('[Water Classification] ❌ Error:', err);
          return false;
        }
      };
      
      // ============================================
      // CARGAR CAPA DE AGUA VECTORIAL DESPUÉS DEL SETSTYLE()
      // ============================================
      const loadWaterClassificationAfterStyleLoad = () => {
        try {
          if (!map.isStyleLoaded()) {
            console.log('[Water Classification RELOAD] ⏸️ Estilo aún no cargado');
            return;
          }
        } catch (err) {
          console.log('[Water Classification RELOAD] ⚠️ Error verificando estilo');
          return;
        }
        
        // ✅ NO validar si existe - SIEMPRE recrear después de setStyle()
        // (setStyle elimina todas las capas, incluso si el source queda en memoria)
        console.log('[Water Classification RELOAD] Recreando capas (sin validación previa)');

        // ⭐ ESTRATEGIA DUAL: Usar ref si existe, sino hacer fetch
        if (waterGeoJSONRef.current) {
          console.log('[Water Classification RELOAD] 🚀 Recreando desde ref (INSTANTÁNEO)');
          createWaterLayers(waterGeoJSONRef.current);
        } else {
          console.log('[Water Classification RELOAD] 📥 GeoJSON no en ref, haciendo fetch...');
          fetch(VECTOR_SOURCES.waterClassification)
            .then(response => {
              if (!response.ok) throw new Error(`HTTP ${response.status}`);
              return response.json();
            })
            .then(data => {
              waterGeoJSONRef.current = data;
              console.log('[Water Classification RELOAD] ✅ GeoJSON cargado y guardado en ref');
              createWaterLayers(data);
            })
            .catch(error => {
              console.error('[Water Classification RELOAD] ❌ Error:', error.message);
              console.log('[Water Classification RELOAD] 🔄 Usando datos locales de fallback...');
              waterGeoJSONRef.current = waterClassificationGeoJSON;
              createWaterLayers(waterClassificationGeoJSON);
            });
        }
      };

      // ⭐ COMENTADO: Capa de agua ya se carga PRIORITARIAMENTE al inicio de style.load (línea ~1395)
      // loadWaterClassificationAfterStyleLoad();
      
      // ============================================
      // ACTIVAR CAPAS HIDROLÓGICAS SI HYDRO O ESI ESTÁ ACTIVO
      // ============================================
      // ⚠️ NO activar water-class-polygons aquí - ya se crea con estado correcto en createWaterLayers()
      if (activeIndex === 'hydro' || activeIndex === 'esi') {
        console.log('[Style Load] ' + (activeIndex === 'hydro' ? 'Hydro' : 'ESI') + ' activo - activando capas hidrológicas (excepto water-class que ya tiene estado correcto)');
        
        try {
          if (map && map.getLayer('reserva-fill')) {
            map.setLayoutProperty('reserva-fill', 'visibility', 'visible');
            map.setLayoutProperty('reserva-outline', 'visibility', 'visible');
            map.setLayoutProperty('rio-line', 'visibility', 'visible');
            console.log('[Style Load] ✓ Capas hidrológicas activadas');
          }
        } catch (e) {
          console.log('[Style Load] Capas hidrológicas aún no disponibles');
        }
      }
      
      // Filtrar etiquetas "Freyja" y ACTIVAR etiquetas de lugares después de recargar estilo
      setTimeout(() => {
        try {
          if (!map.isStyleLoaded()) {
            console.log('[Style Load] Estilo aún no cargado, esperando...');
            return;
          }
        } catch (err) {
          console.log('[Style Load] ⚠️ Error verificando estilo');
          return;
        }
        
        // ⭐ ACTIVAR ETIQUETAS DE LUGARES (ciudades, países, estados, etc.)
        const placeLabels = [
          'settlement-subdivision-label',
          'settlement-label',
          'settlement-minor-label',
          'settlement-major-label',
          'state-label',
          'country-label',
        ];
        
        placeLabels.forEach(layerId => {
          try {
            if (map && map.getLayer(layerId)) {
              map.setLayoutProperty(layerId, 'visibility', 'visible');
            }
          } catch (e) {
            // Layer doesn't exist
          }
        });
        
        console.log('[Style Load] ✓ Etiquetas de lugares ACTIVADAS');
        
        try {
          const style = map.getStyle();
          const layers = style?.layers;
          if (layers) {
            layers.forEach((layer: any) => {
              // ⭐ CRÍTICO: Solo ocultar capas que tengan "freyja" en su ID
              // NO aplicar setFilter a TODAS las capas de texto (bloqueaba etiquetas de lugares)
              if (layer.id && layer.id.toLowerCase().includes('freyja')) {
                try {
                  map.setLayoutProperty(layer.id, 'visibility', 'none');
                  console.log('[Style Load] Capa Freyja ocultada:', layer.id);
                } catch (e) {
                  console.log('[Style Load] Error al ocultar capa Freyja:', layer.id);
                }
              }
            });
            console.log('[Style Load] Etiquetas "Freyja" filtradas');
          }
        } catch (error) {
          console.log('[Style Load] Error al filtrar etiquetas:', error);
        }
      }, 500);
    };
    
    // Agregar el listener (se ejecutará cada vez que se cargue el estilo)
    map.on('style.load', handleStyleLoad);
    
    // Cleanup: remover el listener cuando el componente se desmonte
    return () => {
      map.off('style.load', handleStyleLoad);
    };
  }, [ready]); // Solo depende de 'ready' - el listener se configura UNA VEZ y permanece activo

  // ============================================
  // EFECTO: Filtrar capas de agua según subíndices activos del Hydro Index
  // ============================================
  useEffect(() => {
    if (!mapRef.current || !ready) return;
    
    const map = mapRef.current;
    
    // Solo aplicar filtros si estamos en Hydro Index y las capas existen
    if (activeIndex === 'hydro') {
      // Usar setTimeout para asegurar que las capas están cargadas
      const timer = setTimeout(() => {
        if (!map.getLayer || !map.getLayer('water-class-polygons')) {
          console.log('[Hydro Filter] ⚠️ Capas de agua aún no cargadas');
          return;
        }
        
        // Obtener los subíndices visibles del Hydro Index
        const hydroIndex = indices.find(idx => idx.id === 'hydro');
        const visibleSubLayers = hydroIndex?.subLayers?.filter(sub => sub.visible && sub.id !== 'hydro-data') || [];
        
        // Si no hay subíndices activos, mostrar todas las clases de agua
        if (visibleSubLayers.length === 0) {
          map.setFilter('water-class-polygons', null);
          map.setFilter('water-class-outline', null);
          console.log('[Hydro Filter] Sin subíndices activos - mostrando todas las clases de agua');
          return;
        }
        
        // Mapeo de subíndices a clases de agua que deben mostrarse
        // Clase 1: Seasonal Water (agua estacional) | Clase 2: Permanent Water (agua permanente) | Clase 3: Wetlands (humedales)
        const waterClassMapping: Record<string, number[]> = {
          'ch': [1, 2, 3], // Conectividad Hídrica - todas las clases
          'ra': [2, 3],    // Regulación/Retención - agua permanente y humedales
          'pa': [1, 2, 3], // Presencia y Accesibilidad - todas las clases
          'cbc': [3],      // Capacidad Amortiguación Climática - solo humedales
        };
        
        // Combinar todas las clases de agua de los subíndices activos (sin duplicados)
        const classesToShow = new Set<number>();
        visibleSubLayers.forEach(subLayer => {
          const classes = waterClassMapping[subLayer.id];
          if (classes) {
            classes.forEach(c => classesToShow.add(c));
          }
        });
        
        // Construir el filtro de Mapbox
        if (classesToShow.size > 0) {
          const classArray = Array.from(classesToShow);
          // Filtro: mostrar solo features cuya propiedad 'class' esté en el array de clases
          const filter = ['in', ['get', 'class'], ['literal', classArray]];
          
          map.setFilter('water-class-polygons', filter);
          map.setFilter('water-class-outline', filter);
          
          console.log(`[Hydro Filter] ✓ Subíndices activos: ${visibleSubLayers.map(s => s.id).join(', ')} | Mostrando clases: ${classArray.join(', ')}`);
        } else {
          // Si no se encontraron mapeos, mostrar todo
          map.setFilter('water-class-polygons', null);
          map.setFilter('water-class-outline', null);
          console.log('[Hydro Filter] No se encontraron mapeos - mostrando todas las clases');
        }
      }, 100); // Pequeño delay para asegurar que las capas están cargadas
      
      return () => clearTimeout(timer);
    }
  }, [indices, activeIndex, ready]);

  // ============================================
  // EFECTO: Controlar visibilidad de capas según activeIndex
  // ============================================
  useEffect(() => {
    if (!mapRef.current || !ready) return;
    
    const map = mapRef.current;
    
    // Usar setTimeout para asegurar que las capas están cargadas después de cualquier recarga de estilo
    const timer = setTimeout(() => {
      // La AOI (reserva-fill, reserva-outline) SIEMPRE debe estar visible
      console.log('[Layer Visibility] Estado:', activeIndex || 'PANTALLA PRINCIPAL');
      
      // Activar AOI SIEMPRE (tanto en pantalla principal como en índices)
      try {
        if (map.getLayer('reserva-fill')) {
          map.setLayoutProperty('reserva-fill', 'visibility', 'visible');
          map.setLayoutProperty('reserva-outline', 'visibility', 'visible');
          console.log('[Layer Visibility] ✓ AOI visible');
        }
      } catch (e) {
        console.log('[Layer Visibility] AOI aún no disponible');
      }
      
      // Capas específicas del Hydro/ESI (solo cuando Hydro o ESI está activo)
      // ⚠️ NO controlar water-class-polygons aquí - ya se maneja en useEffect de activeIndex (línea ~1221)
      if (activeIndex === 'hydro' || activeIndex === 'esi') {
        console.log('[Hydro/ESI Visibility] Activando río (water-class ya controlado por otro useEffect)');
        
        // Activar río (solo para Hydro)
        try {
          if (map.getLayer('rio-line')) {
            map.setLayoutProperty('rio-line', 'visibility', 'visible');
            console.log('[Hydro Visibility] ✓ Capa de río activada');
          }
        } catch (e) {
          console.log('[Hydro Visibility] Capa de río aún no disponible');
        }
      } else {
        // Ocultar río cuando NO estamos en Hydro o ESI
        // (water-class ya se oculta automáticamente en otro useEffect)
        try {
          if (map.getLayer('rio-line')) {
            map.setLayoutProperty('rio-line', 'visibility', 'none');
          }
        } catch (e) {
          // Capa no existe
        }
      }
    }, 200); // Delay para asegurar que las capas están cargadas
    
    return () => clearTimeout(timer);
  }, [activeIndex, ready]);

  // Efecto removido - el usuario mantiene control manual de la cámara al activar Hydro Index

  const handleIndexClick = (indexId: IndexType) => {
    console.log('[Button Click] Índice clickeado:', indexId, '| Estado actual:', activeIndex);
    if (activeIndex === indexId) {
      console.log('[Button Click] Cerrando índice:', indexId);
      setActiveIndex(null);
      // Al cerrar el índice, resetear el sub-índice seleccionado
      setSelectedSubIndex(null);
    } else {
      console.log('[Button Click] Abriendo índice:', indexId);
      setActiveIndex(indexId);
      // Al cambiar a un nuevo índice, resetear el sub-índice seleccionado
      setSelectedSubIndex(null);
    }
  };

  const toggleSubLayer = (indexId: IndexType, subLayerId: string) => {
    // Si es un botón de "Data", navegar al panel de datos correspondiente
    if (onNavigate) {
      if (subLayerId === 'hydro-data') {
        onNavigate('hydro-consolidado');
        return;
      }
      if (subLayerId === 'esi-data') {
        onNavigate('esi-data-consolidado');
        return;
      }
      if (subLayerId === 'carbon-data') {
        onNavigate('carbon-data-consolidado');
        return;
      }
      if (subLayerId === 'risk-data') {
        onNavigate('risk-data-consolidado');
        return;
      }
    }

    // Verificar el estado actual ANTES de cambiar
    const currentSubLayer = indices.find(idx => idx.id === indexId)?.subLayers.find(sub => sub.id === subLayerId);
    const wasVisible = currentSubLayer?.visible || false;

    // Actualizar visibilidad del sub-índice
    setIndices(prev => prev.map(idx => {
      if (idx.id === indexId) {
        return {
          ...idx,
          subLayers: idx.subLayers.map(sub => 
            sub.id === subLayerId ? { ...sub, visible: !sub.visible } : sub
          ),
        };
      }
      return idx;
    }));

    // Actualizar el sub-índice seleccionado basado en el estado PREVIO
    if (!wasVisible) {
      // Se está activando, actualizar el contenido del diagnóstico
      setSelectedSubIndex(subLayerId);
    } else {
      // Se está desactivando, volver al diagnóstico general
      setSelectedSubIndex(null);
    }
  };

  // Función para resetear la cámara a la vista inicial de la AOI
  const resetCameraToAOI = () => {
    if (mapRef.current) {
      mapRef.current.flyTo({
        center: DEFAULT_LOCATION.center,
        zoom: DEFAULT_LOCATION.zoom,
        pitch: terrainMode === '3D' ? DEFAULT_LOCATION.pitch3D : 0,
        bearing: terrainMode === '3D' ? DEFAULT_LOCATION.bearing3D : 0,
        duration: 1500,
        essential: true,
      });
      console.log('[Camera Reset] Volviendo a vista inicial de AOI');
    }
  };

  // Manejadores para arrastre del modal de diagnóstico
  const handleModalMouseDown = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!diagnosisModalRef.current) return;
    
    const rect = diagnosisModalRef.current.getBoundingClientRect();
    setIsDragging(true);
    
    // Calcular offset basado en la posición real del modal en pantalla
    setModalDragOffset({
      x: e.clientX - rect.left,
      y: e.clientY - rect.top
    });
    
    // Si es la primera vez que se arrastra (posición 0,0), establecer la posición actual
    if (modalPosition.x === 0 && modalPosition.y === 0) {
      setModalPosition({
        x: rect.left,
        y: rect.top
      });
    }
  };

  const handleModalMouseMove = (e: MouseEvent) => {
    if (!isDragging) return;
    
    // Calcular nueva posición basada en el mouse y el offset
    const newX = e.clientX - modalDragOffset.x;
    const newY = e.clientY - modalDragOffset.y;
    
    setModalPosition({
      x: newX,
      y: newY
    });
  };

  const handleModalMouseUp = () => {
    setIsDragging(false);
  };

  // Efectos para drag del modal de diagnóstico
  useEffect(() => {
    if (isDragging) {
      window.addEventListener('mousemove', handleModalMouseMove);
      window.addEventListener('mouseup', handleModalMouseUp);
      return () => {
        window.removeEventListener('mousemove', handleModalMouseMove);
        window.removeEventListener('mouseup', handleModalMouseUp);
      };
    }
  }, [isDragging, modalDragOffset]);

  // Manejadores para arrastre del modal de clasificación hidrológica
  const handleLegendMouseDown = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!legendRef.current) return;
    
    setIsDraggingLegend(true);
    const rect = legendRef.current.getBoundingClientRect();
    setDragOffset({
      x: e.clientX - rect.left,
      y: e.clientY - rect.top
    });
    e.preventDefault();
  };

  const handleLegendMouseMove = (e: MouseEvent) => {
    if (!isDraggingLegend) return;
    
    const newX = e.clientX - dragOffset.x;
    const newY = e.clientY - dragOffset.y;
    
    setLegendPosition({ x: newX, y: newY });
  };

  const handleLegendMouseUp = () => {
    setIsDraggingLegend(false);
  };

  // Manejadores para arrastre del modal de estructura ecosistémica
  const handleEcosystemMouseDown = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!ecosystemRef.current) return;
    
    setIsDraggingEcosystem(true);
    const rect = ecosystemRef.current.getBoundingClientRect();
    setEcosystemDragOffset({
      x: e.clientX - rect.left,
      y: e.clientY - rect.top
    });
    e.preventDefault();
  };

  const handleEcosystemMouseMove = (e: MouseEvent) => {
    if (!isDraggingEcosystem) return;
    
    const newX = e.clientX - ecosystemDragOffset.x;
    const newY = e.clientY - ecosystemDragOffset.y;
    
    setEcosystemPosition({ x: newX, y: newY });
  };

  const handleEcosystemMouseUp = () => {
    setIsDraggingEcosystem(false);
  };

  // useEffect para agregar/eliminar event listeners del arrastre
  useEffect(() => {
    if (isDraggingLegend) {
      document.addEventListener('mousemove', handleLegendMouseMove);
      document.addEventListener('mouseup', handleLegendMouseUp);
    } else {
      document.removeEventListener('mousemove', handleLegendMouseMove);
      document.removeEventListener('mouseup', handleLegendMouseUp);
    }

    return () => {
      document.removeEventListener('mousemove', handleLegendMouseMove);
      document.removeEventListener('mouseup', handleLegendMouseUp);
    };
  }, [isDraggingLegend, dragOffset]);

  // useEffect para agregar/eliminar event listeners del arrastre (modal ecosistémico)
  useEffect(() => {
    if (isDraggingEcosystem) {
      document.addEventListener('mousemove', handleEcosystemMouseMove);
      document.addEventListener('mouseup', handleEcosystemMouseUp);
    } else {
      document.removeEventListener('mousemove', handleEcosystemMouseMove);
      document.removeEventListener('mouseup', handleEcosystemMouseUp);
    }

    return () => {
      document.removeEventListener('mousemove', handleEcosystemMouseMove);
      document.removeEventListener('mouseup', handleEcosystemMouseUp);
    };
  }, [isDraggingEcosystem, ecosystemDragOffset]);

  // Funciones para grabación de video capturando directamente el canvas del mapa
  const startRecording = async () => {
    try {
      if (!mapRef.current) {
        console.error('[Recording] Mapa no está listo');
        return;
      }

      console.log('[Recording] Iniciando grabación automática con rotación 360°...');
      
      // Obtener el canvas del mapa
      const canvas = mapRef.current.getCanvas();
      
      // Crear un canvas temporal para captura (soluciona el problema de canvas WebGL negro)
      const captureCanvas = document.createElement('canvas');
      captureCanvas.width = canvas.width;
      captureCanvas.height = canvas.height;
      const captureContext = captureCanvas.getContext('2d');
      
      if (!captureContext) {
        throw new Error('No se pudo crear contexto 2D para captura');
      }

      console.log('[Recording] Canvas de captura creado:', captureCanvas.width, 'x', captureCanvas.height);
      
      // Crear stream desde el canvas de captura
      const stream = captureCanvas.captureStream(30); // 30 FPS

      recordedChunksRef.current = [];
      
      // Determinar el mimeType soportado
      let mimeType = 'video/webm;codecs=vp9';
      if (!MediaRecorder.isTypeSupported(mimeType)) {
        mimeType = 'video/webm;codecs=vp8';
        if (!MediaRecorder.isTypeSupported(mimeType)) {
          mimeType = 'video/webm';
        }
      }
      
      const mediaRecorder = new MediaRecorder(stream, {
        mimeType: mimeType,
        videoBitsPerSecond: 8000000, // 8 Mbps para alta calidad
      });

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          recordedChunksRef.current.push(event.data);
        }
      };

      mediaRecorder.onstop = () => {
        const blob = new Blob(recordedChunksRef.current, {
          type: 'video/webm',
        });
        
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.style.display = 'none';
        a.href = url;
        const timestamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, -5);
        a.download = `lydaris-360-rotation-${timestamp}.webm`;
        document.body.appendChild(a);
        a.click();
        
        setTimeout(() => {
          document.body.removeChild(a);
          URL.revokeObjectURL(url);
        }, 100);
        
        console.log('[Recording] Video descargado exitosamente');
      };

      // Función para copiar frames del canvas WebGL al canvas de captura
      let isCapturing = true;
      const captureFrame = () => {
        if (!isCapturing) return;
        
        // Copiar el contenido del canvas WebGL al canvas 2D
        captureContext.drawImage(canvas, 0, 0);
        
        // Dibujar el logo "L.D | Powered by Lydaris Data Intelligence" sobre el video
        const logoBottomPx = logoPosition.bottom;
        const logoLeftPx = logoPosition.left;
        
        // Fondo del logo
        captureContext.save();
        captureContext.fillStyle = 'rgba(15, 23, 41, 0.95)';
        captureContext.strokeStyle = 'rgba(255, 255, 255, 0.15)';
        captureContext.lineWidth = 1;
        const logoX = logoLeftPx;
        const logoY = captureCanvas.height - logoBottomPx - 42; // Altura aproximada del logo
        const logoWidth = 280;
        const logoHeight = 42;
        
        // Dibujar fondo redondeado
        captureContext.beginPath();
        captureContext.roundRect(logoX, logoY, logoWidth, logoHeight, 8);
        captureContext.fill();
        captureContext.stroke();
        
        // Dibujar texto "L.D |"
        captureContext.fillStyle = '#ffffff';
        captureContext.font = '700 18px sans-serif';
        captureContext.letterSpacing = '-0.5px';
        captureContext.textBaseline = 'middle';
        const textY = logoY + logoHeight / 2;
        captureContext.fillText('L', logoX + 18, textY);
        captureContext.fillText('.', logoX + 30, textY - 3);
        captureContext.fillText('D', logoX + 38, textY);
        
        // Dibujar separador "|"
        captureContext.fillStyle = 'rgba(255, 255, 255, 0.6)';
        captureContext.font = '300 21px sans-serif';
        captureContext.fillText('|', logoX + 56, textY);
        
        // Dibujar "Powered by"
        captureContext.fillStyle = '#a8b8d8';
        captureContext.font = '400 12px sans-serif';
        captureContext.fillText('Powered by', logoX + 72, textY);
        
        // Dibujar "Lydaris Data Intelligence"
        captureContext.fillStyle = '#06b6d4';
        captureContext.font = '600 12px sans-serif';
        captureContext.fillText('Lydaris Data Intelligence', logoX + 145, textY);
        
        captureContext.restore();
        
        // Continuar capturando mientras esté grabando
        requestAnimationFrame(captureFrame);
      };

      mediaRecorder.start(100); // Recopilar datos cada 100ms
      mediaRecorderRef.current = mediaRecorder;
      setIsRecording(true);
      
      // Guardar función de limpieza en una ref accesible
      (mediaRecorder as any).stopCapture = () => {
        isCapturing = false;
      };
      
      // Iniciar la captura de frames
      captureFrame();
      
      console.log('[Recording] Grabación iniciada con codec:', mimeType, '@ 30fps');
      console.log('[Recording] Capturando frames desde canvas WebGL...');
      
      // Iniciar rotación 360° automáticamente
      console.log('[Recording] Iniciando rotación 360° automática...');
      startRotation();
      
    } catch (error) {
      console.error('[Recording] Error al iniciar grabación:', error);
      alert(language === 'en'
        ? `Recording error: ${(error as Error).message || 'Unknown error'}. Please try again.`
        : `Error de grabación: ${(error as Error).message || 'Error desconocido'}. Por favor intenta nuevamente.`);
      
      setIsRecording(false);
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      console.log('[Recording] Deteniendo grabación...');
      
      // Detener el loop de captura de frames
      if ((mediaRecorderRef.current as any).stopCapture) {
        (mediaRecorderRef.current as any).stopCapture();
      }
      
      // Detener el mediaRecorder - esto disparará el evento 'onstop' que descarga el archivo
      mediaRecorderRef.current.stop();
      
      // Esperar un momento antes de limpiar las referencias para que onstop se ejecute
      setTimeout(() => {
        setIsRecording(false);
        mediaRecorderRef.current = null;
        console.log('[Recording] Referencias limpiadas');
      }, 200);
    }
  };

  // Resize map when fullscreen changes
  useEffect(() => {
    if (mapRef.current) {
      setTimeout(() => {
        mapRef.current?.resize();
      }, 100);
    }
  }, [isFullscreen]);

  // Controlar visibilidad de la capa de agua con el botón manual
  // 💧 Auto-activar capa de agua SOLO en Hydro Index (en Eco Structural se controla manualmente)
  useEffect(() => {
    if (activeIndex === 'hydro') {
      setWaterLayerVisible(true);
      console.log('[Water Layer Auto] ✅ Capa de agua activada automáticamente en Hydro Index');
    } else if (activeIndex === 'esi') {
      // En Eco Structural, la capa comienza desactivada (control manual con botón)
      setWaterLayerVisible(false);
      console.log('[Water Layer Auto] 🔘 Eco Structural - capa desactivada (control manual con botón)');
    } else {
      setWaterLayerVisible(false);
      console.log('[Water Layer Auto] ❌ Capa de agua desactivada (fuera de Hydro/ESI)');
    }
  }, [activeIndex]); // Solo se dispara al cambiar de índice (NO en cambios de vista/terreno)

  // ============================================
  // EFECTO UNIFICADO: Control SÍNCRONO de capas EV y LSI
  // ============================================
  useEffect(() => {
    if (!ready || !mapRef.current) return;
    
    const map = mapRef.current;
    
    console.log(`[Layer Control] ⚡ SYNC: Ejecutando para ${activeIndex}`);
    
    try {
      // PASO 1: OCULTAR TODAS las capas INMEDIATAMENTE
      try {
        if (map.getLayer('ev-layer')) {
          map.setLayoutProperty('ev-layer', 'visibility', 'none');
          map.setPaintProperty('ev-layer', 'raster-opacity', 0);
        }
      } catch (e) { /* Ignorar */ }
      
      try {
        if (map.getLayer('lsi-layer')) {
          map.setLayoutProperty('lsi-layer', 'visibility', 'none');
          map.setPaintProperty('lsi-layer', 'raster-opacity', 0);
        }
      } catch (e) { /* Ignorar */ }
      
      console.log('[Layer Control] 🔒 Todas ocultadas');
      
      // PASO 2: ACTIVAR solo la capa del índice activo
      if (activeIndex === 'esi') {
        try {
          if (map.getLayer('ev-layer')) {
            map.setLayoutProperty('ev-layer', 'visibility', 'visible');
            map.setPaintProperty('ev-layer', 'raster-opacity', 0.8);
            setEvLayerVisible(true);
            console.log('[Layer Control] ✅ EV activada');
          }
        } catch (e) {
          console.warn('[Layer Control] ⚠️ EV no disponible');
        }
      } else if (activeIndex === 'risk') {
        try {
          if (map.getLayer('lsi-layer')) {
            map.setLayoutProperty('lsi-layer', 'visibility', 'visible');
            map.setPaintProperty('lsi-layer', 'raster-opacity', 0.8);
            setLsiLayerVisible(true);
            console.log('[Layer Control] ✅ LSI activada');
          }
        } catch (e) {
          console.warn('[Layer Control] ⚠️ LSI no disponible');
        }
      }
      
      // Actualizar estados React
      if (activeIndex !== 'esi') setEvLayerVisible(false);
      if (activeIndex !== 'risk') setLsiLayerVisible(false);
      
    } catch (err) {
      console.error('[Layer Control] ❌ Error:', err);
    }
    
  }, [activeIndex, ready]);

  // ============================================
  // EFECTOS DE TOGGLE ELIMINADOS - Ahora aplicación directa en botones
  // ============================================
  // 🔥 Los toggles de Water y EV ahora aplican cambios directamente en onClick
  // Esto elimina la competencia entre efectos y garantiza respuesta al primer clic

  const currentIndex = indices.find(idx => idx.id === activeIndex);

  // Función para obtener el contenido del diagnóstico basado en el sub-índice seleccionado
  const getDiagnosisContent = () => {
    if (!currentIndex) return '';

    // Si hay un sub-índice seleccionado, mostrar información específica
    if (selectedSubIndex) {
      // Contenido específico por sub-índice en inglés
      const subIndexContentEN: Record<string, string> = {
        // Technical Summary - Hydro Index
        'hydro-technical-summary': `Data, Temporal Windows and System Robustness

The hydrological layer visualized on the map represents multi-source detection of water and persistent functional moisture in Cochamó Reserve, integrating optical and radar satellite signals.

Detection considers a 36-month temporal window to identify all observed water (including episodic and seasonal events), and a 24-month window to discriminate persistent water, differentiating permanent water, seasonal water, and wetlands under vegetation cover.

The model operates with 6 active water sources, enabling capture of both visible surface water and functional water integrated into the ecosystem. Multi-source confidence (0.64) indicates solid system support, consistent with hydrologically complex territories where water manifests in distributed and partially hidden form. Average hydrological signal support (0.39) reflects moderate detection intensity, characteristic of landscapes dominated by forest, wetlands and saturated soils, rather than large open water bodies.

Global Findings

Cochamó Reserve presents a functionally active and well-organized hydrological system, characterized not by extensive permanent water surfaces, but by a distributed network of persistent water, seasonal water and wetlands, integrated into the forest landscape and mountain topography.

Of the total detected hydrological system, 10% corresponds to permanent water, 12.3% to recurrent seasonal water, and 6% to wetlands without open water, evidencing a natural water regulation pattern, with high retention and temporal buffering capacity.

Hydrological presence and accessibility is not expressed as surface concentration, but as functional availability, with water accessible through lagoons, humid corridors, secondary drainages and connected wetlands. This pattern sustains the territory's ecological continuity and explains the system's high connectivity, even when direct satellite visibility of water is moderate.

In terms of risk, the system presents moderate and balanced levels: flood risk (Flood: 37.7) associated with plains and low corridors; sedimentation risk (Sed: 40.6) linked to slopes and runoff dynamics; and hydrological deficit or drought risk (Dry: 44.5) controlled by ecosystem storage capacity. Total hydrological risk (40.9) reflects a stable and resilient system, where ecosystem structure and water organization reduce exposure to extreme events.`,
        
        // Technical Summary - Risk Index
        'risk-technical-summary': `Data, Temporal Windows and System Robustness

Risk Index® delivers an integrated reading of territorial risk in Cochamó Reserve, built from multiple physico-natural and anthropogenic dimensions derived from optical satellite, climatic, topographic and territorial pressure data.
The index is calculated using a temporal window of 10 years, allowing capture of structural conditions and medium-term trends, reducing the influence of point anomalies or isolated extreme events.

Climatic and hydroclimatic information is derived from satellite series and climate reanalysis integrating precipitation, potential evapotranspiration and water balance at regional scale, while biophysical and geomorphological conditions rely on high temporal density multispectral optical observations and topographic models.
The system has complete optical observational coverage, incorporating 100% of valid Sentinel-2 scenes available for the analyzed period (N = 874 / 874), which guarantees temporal robustness, multitemporal consistency and high statistical reliability of derived indicators.
Upon this observational base, consolidated satellite and geospatial layers are integrated including:
•	Forest cover and change derived from global forest loss series,
•	Land cover from global ecosystem classifications,
•	Topography and slope derived from digital elevation models,
•	Regional hydroclimatic stress and pressure indicators built from satellite series of precipitation and evapotranspiration,
•	Territorial pressure and landscape fragmentation signals.
Together, these layers enable an integrated reading of territorial risk, combining optical, climatic, geomorphological and anthropogenic information in a consistent, traceable base adequate for decision-making analysis at property scale.
Index robustness (QA_100 = 78.32), with confidence interval CI95 ± 3.90, indicates a solid and consistent satellite base for decision-making reading in territories of high environmental complexity.

Global Findings

Cochamó Reserve presents medium–low global risk (IR = 39.03), result of dynamic equilibrium between physico-natural conditions inherent to a mountain landscape and structural factors that contain effective risk expression.
Analysis confirms that risk is not driven by human pressure nor by ecological fragmentation, but by interaction among moderate hydroclimatic stress, regional water pressure context and natural geomorphological exposure of the territory.
From climatic and hydroclimatic perspective, the system positions in an intermediate dryness range, coherent with temperate mountain territories where water availability is functional but not surplus nor homogeneous. This condition is reflected in convergence between climatic stress (CS = 44.75) and regional hydrology (RHm = 54.29), which describe a moderate climatic pressure framework without indicating critical states.
In structural terms, Geomorphological Exposure (GE = 66.31) emerges as the main index driver, expressing high relief energy associated with slope, topography and mountain landscape organization. This component does not represent active environmental degradation, but a natural exposure condition that can activate erosive processes only under triggering scenarios, such as extreme precipitation events, accelerated snow melting or significant alterations of vegetation cover.
In contrast, effective anthropogenic pressure is minimal (LP = 1.61) and fragmentation risk is extremely low (RF = 3.00), confirming the territory is not being internally eroded by land use change, infrastructure or landscape fragmentation. These factors act as key stabilizing elements, preventing natural geomorphological exposure from translating into effective environmental risk.

Risk Index® describes Cochamó Reserve as a mostly intact territory, with low human pressure, high natural continuity and functional hydrological system, inserted in a moderate hydroclimatic stress context.
Observed risk is not of anthropogenic origin, but structural and physico-environmental, concentrating on geomorphological exposure inherent to a mountain landscape, whose activation depends on extreme events and abrupt changes, not on ongoing degradation processes.
This reading positions the asset as environmentally stable but not passive, where risk management is oriented to preserve soil integrity, vegetation cover and ecohydrological functionality, rather than mitigate impacts derived from direct human use.`,
        
        // Technical Summary - ESI (Ecosystem Structure Index)
        'esi-technical-summary': `Data, Temporal Windows and System Robustness

The index delivers a structural reading of ecosystem functioning at property scale through the integration of multi-annual optical satellite signals, spatial metrics from landscape ecology and anthropogenic pressure proxies, designed to capture relatively stable territorial properties and reduce dependence on point states or transitory events.
The temporal core of the index is supported by a continuous multi-annual window of 5 years (2021–2025), based on the complete archive of Sentinel-2 SR Harmonized images available for the area of interest, without exclusion of valid scenes. Over this complete archive, NDVI p90 is calculated, a robust statistic representing the recurring maximum capacity of photosynthetic activity per pixel, minimizing the influence of residual cloudiness, atmospheric noise, extreme seasonality or interannual anomalies. This methodological choice allows the vegetational vigor component of the index to represent a structural condition of the system rather than an ephemeral response to favorable point climatic conditions.

The spatial metrics that comprise the index architecture—connectivity density, coverage fragmentation and ecological continuity—are derived from geomatic operations that depend on spatial relationships (neighborhoods, distances, edges and patch sizes) and not on instantaneous values. In technical terms, these metrics are inherently more stable over time than purely dynamic biophysical variables, which brings robustness to the index for decisional and comparative readings.

Anthropogenic pressure is evaluated through independent satellite signals—land use and nocturnal radiance—integrated with percentile scaling, which reduces sensitivity to outliers and allows discrimination of effective human footprint against background noise. This component acts as a structural modulator, ensuring that the ecosystem reading is not contaminated with assumptions about human intervention not supported by satellite observation.

Overall, the robustness of Eco-Structural Index® is based on three pillars:
- Robust multi-annual vegetational signal with complete archive
- Structural spatial metrics with low temporal sensitivity, and
- Implicit cross-validation with absence of detectable anthropogenic pressure.

This allows the index to be used as a stable decisional layer for ecosystem integrity analysis, conservation, structural environmental risk and strategic ecological value.

Global Findings

Reserva Cochamó is a structurally intact, highly connected and ecologically continuous ecosystem system, whose functioning is dominated by physical and geomorphological regulators inherent to a mountain landscape, not by anthropogenic pressure nor internal degradation processes.

Ecosystem vigor reflects an eco physiologically healthy and stable system, sustained over time, but intrinsically heterogeneous. This heterogeneity accounts for the territory's geomorphological complexity: persistent shaded areas, altitudinal gradients, geo-hydro-nival mosaic and thermal seasonality. The system does not maximize uniform productivity; it maximizes functional stability under restrictive physical conditions, which constitutes a typical signature of resilient mountain ecosystems.

Connectivity density (DC) confirms that the ecosystem core does not behave as an isolated patch, but as a functional spatial continuum at local scale, an essential condition for the persistence of ecological processes, biological mobility and response capacity to disturbances. This local connectivity is amplified by the regional context in which the property is inserted, reinforcing systemic resilience beyond AOI boundaries.

Coverage fragmentation (FC), far from indicating degradation, reveals the presence of a complex spatial architecture, characterized by natural edges and eco hydrological transitions typical of mountain environments. These interfaces—forest-wetland, forest-water, forest-rock, forest-seasonal snow—constitute zones of functional exchange and niche diversity, increasing the system's adaptive capacity. The detected fragmentation is structural and natural, not anthropogenic.

Ecological continuity (CE) emerges as the main structural attribute of the territory. Its value close to maximum indicates that the system preserves almost ideal conditions for the operation of ecosystem processes without significant human interference. This continuity does not imply homogeneity, but integrity: the territory maintains the capacity for self-regulation through shaded microclimates, snow storage, altitudinal thermal regulation and eco hydrological organization, configuring itself as a structural climatic refuge of high relevance.

Inverted anthropogenic pressure (PA⁻) objectively confirms that the system's structural integrity is not being eroded by land use, infrastructure nor detectable human activity. This finding is critical, as it validates that the high connectivity and continuity values are not residual nor transitory, but the result of an effective absence and local disturbance.
Integrated with the Hydro Index® and Risk Index®, Eco-Structural Index® converges on a clear decisional reading: Reserva Cochamó is an ecosystem asset of high structural integrity, where vulnerability does not originate in internal fragmentation processes or human pressure, but in exogenous physical and climatic drivers inherent to mountain systems. The territory is not passive, but profoundly stable: its dynamics are governed by geomorphology, climate and natural landscape organization, not by ongoing degradation.`,
        
        // Technical Summary - Carbon Index
        'carbon-technical-summary': `Data, Temporal Windows and System Robustness

[Contenido pendiente - estructura lista para completar]

Global Findings

[Contenido pendiente - estructura lista para completar]`,
        
        // Hydro Index subindices
        'ch': 'Hydrological Connectivity (CH 73.1) evaluates spatial connectivity of the water system, measuring continuity between water bodies, humid corridors, hydrological proximity, and absence of functional fragmentation. High value indicates that water in Cochamó Reserve forms an integrated network, not isolated in patches, maintaining hydrological connectivity even under forest cover. Analysis reveals high connectivity between central lagoon, secondary lagoons, peripheral wetlands and minor drainages. The primary high-altitude lagoon (32 ha) functions as the central node of the water network, integrating with secondary lagoons through wetland corridors and drainage channels. Topography and forest reinforce continuity rather than fragmenting it. No relevant hydrological breaks observed. The water system presents high spatial continuity, with connectivity between water bodies, wetlands and secondary drainages functioning as an integrated, non-fragmented system.',
        'ra': 'Regulation / Retention (RA 67.6) measures the territory\'s capacity to regulate water flows, integrating stable soil moisture, active vegetation, functional wetlands, and relief that favors retention and gradual release. Answers: does the territory buffer or amplify hydrological extremes? High value shows Cochamó Reserve exhibits strong water buffering capacity, natural water retention, and progressive release over time. Wetlands and organic soils play a central role. Forest acts as natural water infrastructure. The primary lagoon is closely integrated with surrounding primary forest. Organic soils, dense vegetation cover, and shaded slopes enable slow, continuous filtration, ensuring hydrological stability and long-term ecosystem protection. Low response to extreme events. The territory presents elevated water regulation capacity, buffering floods and sustaining stable flows through wetlands, humid soils and continuous forest cover.',
        'pa': 'Presence & Accessibility (PA 42.7) evaluates effective presence of accessible water, considering detected open water, spatial density, surface accessibility, and hydrological visibility. This is the sub-index closest to direct human perception. Medium value indicates water is not omnipresent on surface, distributed in medium and small bodies, with much of the water not directly visible. Low dominance of large open lakes or rivers. High proportion of water in diffuse form (subsurface, wetlands). Lower PA is not a deficit but a characteristic of the system. Surface water presence is moderate and distributed. The system does not concentrate the resource in large visible bodies, but disperses it across the landscape.',
        'cbc': 'Climatic Buffering Capacity (CBC 23.9) assesses the territory\'s ability to buffer climate variability scenarios, based on structural climatic signals. It integrates effective recharge indicators (precipitation-evapotranspiration balance), average snow signal, topographic accumulation, and proxies for potential water storage, expressing the degree to which the territory can buffer climatic shocks. The value indicates low dominance of concentrated climate buffering, associated with the absence of large persistent snow reserves, glaciers, or long-term structural climatic surpluses. In this context, the territory\'s buffering against extreme climate events depends primarily on its powerful current hydrological structure and functioning. The territory\'s effective hydrological resilience emerges from the interaction between hydrological connectivity (CH), water regulation (RA), and climatic buffering (CBC), where each sub-index describes a complementary dimension of the system.',
        'hydro-data': 'Comprehensive hydrological dataset with key indicators: Total functional water 42.7% (~392.5 ha), Total wetlands 10.1% (~92.7 ha), Permanent water ~10%, Seasonal water ~12.3%, Subsurface wetlands ~6%, Total hydrological risk 40.9. Nearly half of the territory functionally participates in the water system. Primary high-altitude lagoon (32 ha) serves as natural freshwater reservoir capturing snowmelt and high-elevation rainfall. Registered water rights documented. Data integrates lagoons, rivers, wetlands, and permanent freshwater systems. Snow contributions from peaks, precipitation, extensive subsurface water network, and numerous wetlands. Sentinel-2 MSI water indices (MNDWI, NDWI), Landsat-8, ALOS/PALSAR DEM (12.5m), temporal analysis 2000-2024. Confidence 0.64 (6 active sources). A significant fraction of the territory acts as active water infrastructure, even where no visible open water exists.',
        'hydro-advanced': 'Advanced hydrological modeling reveals a buffered system that absorbs surpluses and gradually releases them, maintaining functions even in dry periods. The system combines permanent water (~10%), seasonal water (~12.3%), and wetlands without open water (~6%), allowing functional stability over time. Forest, organic soils and wetlands provide exceptional natural retention. The combination of snow, lagoons, wetlands, and subsurface water creates a highly resilient system against droughts, extreme events, and shifts in precipitation patterns, functioning as a natural climate buffer. Eco-hydrological diagnosis shows water acts as distributed ecological infrastructure rather than concentrated resource. Snow and precipitation from surrounding peaks sustain the water network with several lagoons, numerous wetlands, and an important subsurface water network.',
        'hydro-confidence': 'Index confidence is medium-high (0.64), consistent with temperate humid forest territories with dense canopy, chronic cloudiness, and complex topography. Integrates multiple sources and cross-validations (6 active sources). Hydrological risks remain in moderate ranges (total risk 40.9), without signs of structural water stress or critical vulnerability. Typical of active mountain systems without functional collapse indicators. The water system presents balanced combination of permanent, seasonal water and wetlands, enabling temporal functional stability and long-term hydrological stability under changing climatic conditions.',
        'ev': `The Ecosystem Vigor sub-index represents the spatial expression of the system's eco-physiological vigor, estimated from the 90th percentile of multi-annual NDVI calculated over a continuous five-year window; 2020 - 2025.

From a geomatic perspective, the use of NDVI p90 allows approximation of the recurrent functional ceiling of photosynthetic activity per pixel, significantly reducing the influence of outliers, interannual anomalies, and biases associated with incomplete temporal windows or persistent cloudiness, particularly relevant in humid mountain landscapes.

In mountain systems such as Cochamó Reserve, vegetational vigor rarely reaches extreme values close to saturation due to physical limitations that the optical sensor consistently registers: presence of prolonged shaded areas, reduction of effective irradiance due to orientation and slope, marked thermal seasonality, and a growing season limited by cold altitudinal conditions.

Additionally, the geo-hydro-nival heterogeneity of the territory —with coexistence of forest, exposed rock, surface water, wetlands, and seasonal snow— introduces persistent spatial variability that modulates the system's functional average without implying any deterioration.

In this framework, an EV of 77.14 describes a vigorous, structurally healthy, and eco-physiologically stable ecosystem, whose productivity is regulated by the geomorphological and climatic architecture of the landscape rather than by hydrological or anthropogenic limitations.

The conceptual integration with the Hydro Index® reinforces this reading: the system's water capital manifests mainly through organization, regulation, and connectivity (elevated CH and RA), while water presence and accessibility is not homogeneous at property scale, consistent with the territory's abrupt morphology.

The data provided by the Risk Index® indicates that moderate climatic stress does not translate into vigor loss thanks to the action of local physical regulators —shaded areas, altitudinal gradients, snow patterns, and cloudiness— that buffer climatic extremes. EV, therefore, expresses sustained functional integrity under structural conditions characteristic of a mountain landscape.`,
        'dc': `The sub-index quantifies the local density of core habitat structural connectivity through a focal average of the ecosystem nucleus in a spatial neighborhood of approximately 180 meters.

From a geomatic perspective, DC does not model connectivity as a graph or as a least-cost corridor, but as a direct measure of how much core habitat surface surrounds each pixel, thus capturing the system's immediate spatial continuity.

In mountain landscapes, this metric acquires particular relevance, since functional connectivity does not operate solely on the horizontal plane. The structural continuity detected by DC reflects the interconnection between ravines, slopes, riparian corridors, and altitudinal gradients, allowing the persistence of short and medium-distance ecological flows, as well as altitudinal micro-migrations associated with climatic responses.

A DC of 90.38 indicates that the ecosystem core does not present itself as an isolated patch, but as a continuous matrix at local scale, a key condition for ecological resilience in mountainous environments.

This reading is reinforced by the territorial context in which the property is inserted: a binational protected continuum of 1,600,000 hectares in extension, which amplifies effective connectivity beyond AOI boundaries, reducing risks of genetic isolation and favoring recolonization processes and ecological rescue after external disturbances.

The coherence with the Risk Index® is direct: an extremely low fragmentation risk finds here its structural correlate, confirming that the system's connectivity is not compromised by internal pressures or landscape discontinuities.`,
        'fc': `This sub-index characterizes the spatial structure of ecosystem coverage from the configuration of core habitat patches and the presence of functional edge in its immediate vicinity, incorporating an edge erosion designed to distinguish real core from peripheral transitions.

In landscape ecology terms, FC does not exclusively measure anthropogenic fragmentation, but rather detects the presence and distribution of spatial interfaces.

In Cochamó Reserve, an FC value of 69.36 should not be interpreted as a signal of degradation or loss of continuity, but as a geomatic expression of a structurally complex landscape. In mountain systems with high topographic and hydrological heterogeneity, natural edges —forest-wetland, forest-water, forest-rock, forest-seasonal snow— are abundant and functional, generating interfaces that increase local edge without being associated with human disturbance.

This apparent fragmentation is coherent with the eco-hydrological organization of the territory, where water is distributed in corridors, valley bottoms, and mallines (mountain meadows), while summits and slopes with high geomorphological energy structure the space into differentiated functional units.

The integration with Risk Index® data is clear: a high geomorphological exposure (GE) describes precisely this physical organization of the relief, which FC captures from the spatial perspective of coverage.

From a decision-making perspective, this Coverage Fragmentation range is indicative of positive structural heterogeneity, associated with diversity of niches, microclimates, and functional routes, key elements in mountain climate refuge systems.`,
        'pa-inv': `The PA⁻ sub-index quantifies the intensity of anthropogenic footprint detectable through satellite sensors, integrating information on infrastructure, land use, and nighttime radiance as a proxy for human activity.

The inversion of the index allows high values to represent low effective pressure, facilitating its integration with structural integrity metrics.

A PA⁻ of 90.10 confirms that Cochamó Reserve presents extremely low anthropogenic pressure, with absence of consistent signals of urbanization, agriculture, or nighttime human activity. This condition is not a qualitative appreciation, but an objective geomatic reading based on multiple independent sources.

The concordance with Risk Index® data is direct: minimal territorial pressure and an almost non-existent fragmentation risk find here their structural expression.

This low anthropogenic pressure is a fundamental prerequisite for ecological continuity and core connectivity to remain at such high levels, and for the geomorphological exposure of the territory not to translate into active degradation.`,
        'ce': `The CE sub-index represents the functional continuity of the ecological system through the integration of two fundamental geomatic components: the intactness derived from the distance to detectable anthropogenic disturbances and the spatial proximity to hydro-structural elements of the landscape.

An Ecological Continuity indicator of 98.86 indicates that Cochamó Reserve preserves a practically maximum ecological continuity, sustained primarily by the absence of infrastructure, agriculture, and signs of human intervention, and secondarily modulated by the spatial organization of hydro-geomorphological elements. The high score reflects a territory where natural climate regulators and ecosystem functioning can operate without external interference.

From an eco-territorial perspective, this continuity translates into the preservation of shade microclimates, cold altitudinal gradients, seasonal snow storage and gradual water release, as well as persistent orographic rainfall that sustains the system's effective moisture. These mechanisms, intrinsically linked to the landscape's geomorphology, confer the territory a structural climate refuge character.

In coherence with Risk Index®, such an elevated CE confirms that the relevant risk for the system is exogenous and physical, not the result of internal degradation processes, and that the Susceptibility of Removal events linked to the landscape geomorphology of the AOI are subject to the occurrence of exacerbated climatic phenomena as triggers.`,
        'ue': 'Ecological Units mapping identifies 8 distinct natural communities based on topographic position, moisture regime, and vegetation composition. Old-growth Nothofagus-dominated forest comprises 62% of area. Wetland complexes occupy valley bottoms (8% of AOI). Natural matrix integrity maintained with minimal anthropogenic conversion.',
        'carbon-score': 'Carbon Index (68.3) indicates strong sequestration potential. Above-ground biomass estimated at 245 tC/ha in mature stands. Soil organic carbon pools average 180 tC/ha in top 30cm. Total carbon stock approximately 425 tC/ha. Annual sequestration rate 2.8 tC/ha/year. Protection of existing stocks prioritized over enhancement activities.',
        
        // Risk Index subindices
        'cs': `CS represents the relative position of climatic dryness (P/PET) and its behavior in the 10-year series analyzed.
A CS < 45 indicates moderate climatic stress, relevant for resilience decisions, without representing a critical condition.
The Dry = 44.5 value from Hydro Index® reinforces this reading from the hydrological model, confirming that dryness is a present component of the system not due to absence of water capital, but due to mountain morphology, altitudinal gradients and spatial distribution of water.`,
        'rhm': `RHm evaluates regional hydroclimatic pressure in an extended environment, independent of the property's internal hydrological functioning.
An RHm < 55 positions the asset in a context of moderate regional water pressure, which does not contradict the presence of a functional hydrological system at local scale.
The need to analyze humidity windows, recharge and temporal continuity of water capital is reinforced, particularly in mountain systems where persistence depends on snow contributions, subsurface regulation and shade microclimates.`,
        'ge': `GE does not represent active environmental degradation nor structural loss of the territory.
This sub-index expresses potential geomorphological exposure associated with the combination of slope, relief energy and relative vegetation cover, characteristic of mountain landscapes.
A GE > 65 indicates that the system presents high geomorphological energy, which can activate erosive processes only under triggering conditions, such as:
- Significant alteration of vegetation cover
- Intense precipitation events
- Accelerated snow melting under elevated isotherms
In the absence of anthropogenic pressure or land use change, this condition corresponds to a natural structural characteristic of the landscape, not an effective environmental risk.
Analyzed together with transport and runoff indicators (Sed = 40.6; Flood = 37.7), the values describe a degree of latent geomorphological–hydrological susceptibility, characteristic of mountain systems, not an active hydrological risk.
Its activation depends on extreme events.`,
        'rf': `Very high natural continuity.
This extremely low RF indicates that the territory is classified mostly as continuous natural cover, with zero presence of internal anthropogenic matrices and high spatial coherence of the ecosystem.

From a risk reading, this condition implies that the system does not present significant structural fragmentation affecting ecological connectivity, biophysical flows or functional landscape integrity.
Low fragmentation acts as a stability factor, reducing edge effects, hydrological discontinuities and resilience loss associated with natural mosaic rupture.

In the index context, low RF does not eliminate other physical risks, but it does prevent their amplification by internal spatial degradation, contributing to global risk remaining in medium ranges.`,
        'lp': `Minimal effective human pressure detected.
Almost null LP indicates that the model does not detect relevant anthropogenic pressure within the AOI.
From a resilience reading, this is a favorable structural factor, since global risk is not being pushed by internal land use degradation.`,
        'risk-data': `Comprehensive risk dataset with key indicators: Final Risk Index (IR) 39.03 classified as medium risk level. Quality Assurance (QA) 78.32 with 95% confidence interval ±3.90, indicating robust and traceable analysis. Analysis year 2024 with 10-year time series (120/120 months utilized). Data sources include Sentinel-2 (N: 874/874 scenes processed). Multiscale analysis integrates optical imagery (10–30 m resolution), topographic data (30 m), and climatic datasets (~4–5 km). Sub-indices breakdown: Climate Stress (CS) 44.75, Regional Hydrology (RHm) 54.29, Geomorphological Exposure (GE) 66.31, Fragmentation Risk (RF) 3.00, Land Pressure (LP) 1.61. The territory presents a moderate risk profile driven primarily by natural geomorphological sensitivity, with minimal anthropogenic pressure and extremely low fragmentation, confirming an intact landscape with functional ecological coherence.`,
      };

      // Contenido específico por sub-índice en español
      const subIndexContentES: Record<string, string> = {
        // Resumen Técnico - Hydro Index
        'hydro-technical-summary': `Datos, ventanas temporales y robustez del sistema

La capa hídrica visualizada en el mapa representa la detección multifuente de agua y humedad funcional y persistente en la Reserva Cochamó, integrando señales satelitales ópticas y radar.

La detección considera una ventana temporal de 36 meses para identificar toda el agua observada (incluyendo eventos episódicos y estacionales), y una ventana de 24 meses para discriminar agua persistente, diferenciando agua permanente, agua estacional y humedales bajo cobertura vegetal.

El modelo opera con 6 fuentes de agua activas, lo que permite capturar tanto agua superficial visible como agua funcional integrada al ecosistema. La confianza multifuente (0,64) indica un respaldo sólido del sistema, consistente con territorios hídricamente complejos donde el agua se manifiesta de forma distribuida y parcialmente oculta. El soporte promedio de la señal hídrica (0,39) refleja una intensidad moderada de detección, característica de paisajes dominados por bosque, humedales y suelos saturados, más que por grandes espejos de agua abiertos.

Hallazgos Globales

Reserva Cochamó presenta un sistema hídrico funcionalmente activo y bien organizado, que no se caracteriza por extensas superficies de agua permanente, sino por una red distribuida de agua persistente, agua estacional y humedales, integrada al paisaje forestal y a la topografía de montaña.

Del total del sistema hídrico detectado, un 10 % corresponde a agua permanente, un 12,3 % a agua estacional recurrente y un 6 % a humedales sin agua abierta, lo que evidencia un patrón de regulación natural del agua, con alta capacidad de retención y amortiguación temporal.

La presencia y accesibilidad hídrica no se expresa como concentración superficial, sino como disponibilidad funcional, con agua accesible a través de lagunas, corredores húmedos, drenajes secundarios y humedales conectados. Este patrón sostiene la continuidad ecológica del territorio y explica la alta conectividad del sistema, aun cuando la visibilidad satelital directa del agua sea moderada.

En términos de riesgo, el sistema presenta niveles moderados y equilibrados: riesgo de inundación (Flood: 37,7) asociado a planicies y corredores bajos; riesgo de sedimentación (Sed: 40,6) vinculado a pendientes y dinámica de escorrentía; y riesgo de déficit hídrico o sequía (Dry: 44,5) controlado por la capacidad de almacenamiento ecosistémico. El riesgo hídrico total (40,9) refleja un sistema estable y resiliente, donde la estructura ecosistémica y la organización del agua reducen la exposición a eventos extremos.`,
        
        // Resumen Técnico - Risk Index
        'risk-technical-summary': `Datos, ventanas temporales y robustez del sistema

Risk Index® entrega una lectura integrada del riesgo territorial en la Reserva Cochamó, construida a partir de múltiples dimensiones físico-naturales y antrópicas, derivadas de datos satelitales ópticos, climáticos, topográficos y de presión territorial.
El índice se calcula utilizando una ventana temporal  de 10 años, lo que permite capturar condiciones estructurales y tendencias de mediano plazo, reduciendo la influencia de anomalías puntuales o eventos extremos aislados.

La información climática e hidroclimática se deriva de series satelitales y reanálisis climáticos que integran precipitación, evapotranspiración potencial y balance hídrico a escala regional, mientras que las condiciones biofísicas y geomorfológicas se apoyan en observaciones ópticas multiespectrales de alta densidad temporal y modelos topográficos.
El sistema cuenta con cobertura observacional óptica completa, incorporando el 100 % de las escenas Sentinel-2 válidas disponibles para el período analizado (N = 874 / 874), lo que garantiza robustez temporal, consistencia multitemporal y alta confiabilidad estadística de los indicadores derivados.
Sobre esta base observacional se integran capas satelitales y geoespaciales consolidadas que incluyen:
•	Cobertura y cambio de bosque derivados de series globales de pérdida forestal,
•	Cobertura del suelo a partir de clasificaciones ecosistémicas globales,
•	Topografía y pendiente derivadas de modelos digitales de elevación,
•	Indicadores de estrés y presión hidroclimática regional construidos a partir de series satelitales de precipitación y evapotranspiración,
•	Señales de presión territorial y fragmentación del paisaje.
En conjunto, estas capas permiten una lectura integrada del riesgo territorial, combinando información óptica, climática, geomorfológica y antrópica en una base consistente, trazable y adecuada para análisis decisional a escala predial.
La robustez del índice (QA_100 = 78,32), con un intervalo de confianza CI95 ± 3,90, indica una base satelital sólida y consistente para lectura decisional en territorios de alta complejidad ambiental.

Hallazgos Globales

La Reserva Cochamó presenta un riesgo global medio–bajo (IR = 39,03), resultado de un equilibrio dinámico entre condiciones físico-naturales propias de un paisaje cordillerano y factores estructurales que contienen la expresión efectiva del riesgo.
El análisis confirma que el riesgo no está impulsado por presión humana ni por fragmentación ecológica, sino por la interacción entre estrés hidroclimático moderado, presión hídrica regional de contexto y exposición geomorfológica natural del territorio.
Desde el punto de vista climático e hidroclimático, el sistema se posiciona en un rango intermedio de sequedad, coherente con territorios de montaña templada, donde la disponibilidad de agua es funcional pero no excedentaria ni homogénea. Esta condición se refleja en la convergencia entre el estrés climático (CS = 44,75) y la hidrología regional (RHm = 54,29), que describen un marco de presión climática moderada, sin indicar estados críticos.
En términos estructurales, la Exposición Geomorfológica (GE = 66,31) emerge como el principal driver del índice, expresando la alta energía del relieve asociada a pendiente, topografía y organización del paisaje cordillerano. Este componente no representa degradación ambiental activa, sino una condición natural de exposición que puede activar procesos erosivos únicamente bajo escenarios gatillantes, tales como eventos extremos de precipitación, derretimiento nival acelerado o alteraciones significativas de la cobertura vegetal.
En contraste, la presión antrópica efectiva es mínima (LP = 1,61) y el riesgo de fragmentación es extremadamente bajo (RF = 3,00), confirmando que el territorio no está siendo erosionado internamente por cambio de uso del suelo, infraestructura ni fragmentación del paisaje. Estos factores actúan como elementos estabilizadores clave, evitando que la exposición geomorfológica natural se traduzca en riesgo ambiental efectivo.

Risk Index® describe a la Reserva Cochamó como un territorio mayoritariamente intacto, con baja presión humana, alta continuidad natural y un sistema hidrológico funcional, inserto en un contexto de estrés hidroclimático moderado.
El riesgo observado no es de origen antrópico, sino estructural y físico-ambiental, concentrándose en la exposición geomorfológica propia de un paisaje cordillerano, cuya activación depende de eventos extremos y cambios abruptos, no de procesos de degradación en curso.
Esta lectura posiciona al activo como ambientalmente estable pero no pasivo, donde la gestión del riesgo se orienta a preservar la integridad del suelo, la cobertura vegetal y la funcionalidad ecohidrológica, más que a mitigar impactos derivados del uso humano directo.`,
        
        // Resumen Técnico - ESI (Índice de Estructura Ecosistémica)
        'esi-technical-summary': `Datos, ventanas temporales y robustez del sistema

El índice entrega una lectura estructural del funcionamiento ecosistémico a escala predial mediante la integración de señales satelitales ópticas multianuales, métricas espaciales de ecología del paisaje y proxies de presión antrópica, diseñadas para capturar propiedades relativamente estables del territorio y reducir la dependencia de estados puntuales o eventos transitorios.
El núcleo temporal del índice se sustenta en una ventana multianual continua de 5 años (2021–2025), basada en el archivo completo de imágenes Sentinel-2 SR Harmonized disponibles para el área de interés, sin exclusión de escenas válidas. Sobre este archivo completo se calcula el NDVI p90, un estadístico robusto que representa la capacidad máxima recurrente de actividad fotosintética por píxel, minimizando la influencia de nubosidad residual, ruido atmosférico, estacionalidad extrema o anomalías interanuales. Esta elección metodológica permite que el componente de vigor vegetacional del índice represente una condición estructural del sistema y no una respuesta efímera a condiciones climáticas favorables puntuales.

Las métricas espaciales que conforman la arquitectura del índice —densidad de conectividad, fragmentación de cobertura y continuidad ecológica— se derivan de operaciones geomáticas que dependen de relaciones espaciales (vecindades, distancias, bordes y tamaños de parche) y no de valores instantáneos. En términos técnicos, estas métricas son inherentemente más estables en el tiempo que variables biofísicas puramente dinámicas, lo que aporta solidez al índice para lecturas decisionales y comparativas.

La presión antrópica se evalúa mediante señales satelitales independientes —uso del suelo y radiancia nocturna— integradas con escalamiento por percentiles, lo que reduce la sensibilidad a valores atípicos y permite discriminar huella humana efectiva frente a ruido de fondo. Este componente actúa como un modulador estructural, asegurando que la lectura ecosistémica no se contamine con supuestos sobre intervención humana no respaldados por observación satelital.

En conjunto, la robustez del Eco-Structural Index® se fundamenta en tres pilares:
- Señal vegetacional multianual robusta con archivo completo
- Métricas espaciales estructurales de baja sensibilidad temporal, y
- Validación cruzada implícita con ausencia de presión antrópica detectable.

Esto permite que el índice sea utilizado como una capa decisional estable para análisis de integridad ecosistémica, conservación, riesgo ambiental estructural y valor ecológico estratégico.

Hallazgos globales

Reserva Cochamó es un sistema ecosistémico estructuralmente intacto, altamente conectado y ecológicamente continuo, cuyo funcionamiento está dominado por reguladores físicos y geomorfológicos propios de un paisaje cordillerano, y no por presión antrópica ni procesos de degradación interna.
El vigor ecosistémico refleja un sistema eco fisiológicamente sano y estable, sostenido en el tiempo, pero intrínsecamente heterogéneo. Esta heterogeneidad da cuenta la complejidad geomorfológica del territorio: umbrías persistentes, gradientes altitudinales, mosaico geo-hidro-nival y estacionalidad térmica. El sistema no maximiza productividad uniforme; maximiza estabilidad funcional bajo condiciones físicas restrictivas, lo que constituye una firma típica de ecosistemas de montaña resilientes.

La densidad de conectividad (DC) confirma que el núcleo ecosistémico no se comporta como un parche aislado, sino como un continuo espacial funcional a escala local, condición esencial para la persistencia de procesos ecológicos, movilidad biológica y capacidad de respuesta ante perturbaciones. Esta conectividad local se ve amplificada por el contexto regional en el que se inserta el predio, reforzando la resiliencia sistémica más allá de los límites del AOI.

La fragmentación de cobertura (FC), lejos de indicar degradación, revela la presencia de una arquitectura espacial compleja, caracterizada por bordes naturales y transiciones eco hidrológicas propias de ambientes montañosos. Estas interfaces —bosque-humedal, bosque-agua, bosque-roca, bosque-nieve estacional— constituyen zonas de intercambio funcional y diversidad de nichos, aumentando la capacidad adaptativa del sistema. La fragmentación detectada es estructural y natural, no antrópica.

La continuidad ecológica (CE) emerge como el principal atributo estructural del territorio. Su valor cercano al máximo indica que el sistema conserva condiciones casi ideales para la operación de procesos ecosistémicos sin interferencia humana significativa. Esta continuidad no implica homogeneidad, sino integridad: el territorio mantiene la capacidad de autorregularse mediante microclimas de umbría, almacenamiento nival, regulación térmica altitudinal y organización eco hidrológica, configurándose como un refugio climático estructural de alta relevancia.

La presión antrópica (PA⁻) confirma de manera objetiva que la integridad estructural del sistema no está siendo erosionada por uso del suelo, infraestructura ni actividad humana detectable. Este hallazgo es crítico, ya que valida que los altos valores de conectividad y continuidad no son residuales ni transitorios, sino el resultado de una ausencia efectiva y de disturbio local.
Integrado con el Hydro Index® y el Risk Index®, Eco-Structural Index® converge en una lectura decisional clara: Reserva Cochamó es un activo ecosistémico de alta integridad estructural, donde la vulnerabilidad no se origina en procesos internos de fragmentación o presión humana, sino en drivers físicos y climáticos exógenos propios de sistemas de montaña. El territorio no es pasivo, pero sí profundamente estable: su dinámica está gobernada por la geomorfología, el clima y la organización natural del paisaje, no por degradación en curso.`,
        
        // Resumen Técnico - Carbon Index
        'carbon-technical-summary': `Datos, ventanas temporales y robustez del sistema

[Contenido pendiente - estructura lista para completar]

Hallazgos Globales

[Contenido pendiente - estructura lista para completar]`,
        
        // Subíndices Hydro Index
        'ch': 'Conectividad Hídrica (CH 73.1) evalúa la conectividad espacial del sistema hídrico, midiendo continuidad entre cuerpos de agua, corredores húmedos, proximidad hidrológica y ausencia de fragmentación funcional. Valor alto indica que el agua en Reserva Cochamó forma una red integrada, no aislada en parches, manteniendo conectividad hidrológica incluso bajo cobertura forestal. Análisis revela alta conectividad entre laguna central, lagunas secundarias, humedales periféricos y drenajes menores. La laguna primaria de altura (32 ha) funciona como nodo central de la red hídrica, integrándose con lagunas secundarias a través de corredores de humedales y canales de drenaje. La topografía y el bosque refuerzan la continuidad en lugar de fragmentarla. No se observan cortes hidrológicos relevantes. El sistema hídrico presenta alta continuidad espacial, con conectividad entre cuerpos de agua, humedales y drenajes secundarios funcionando como un sistema integrado, no fragmentado.',
        'ra': 'Regulación / Retención (RA 67.6) mide la capacidad del territorio para regular flujos hídricos, integrando humedad estable del suelo, vegetación activa, humedales funcionales y relieve que favorece retención y liberación gradual. Responde a la pregunta: ¿el territorio amortigua o amplifica los extremos hídricos? Valor alto muestra que Reserva Cochamó exhibe fuerte capacidad de amortiguación hídrica, retención natural del agua y liberación progresiva en el tiempo. Humedales y suelos orgánicos juegan un rol central. El bosque actúa como infraestructura hídrica natural. La laguna primaria está estrechamente integrada con el bosque primario circundante. Suelos orgánicos, cobertura vegetal densa y laderas sombreadas permiten filtración lenta y continua, asegurando estabilidad hidrológica y protección ecosistémica de largo plazo. El territorio presenta una elevada capacidad de regulación hídrica, amortiguando crecidas y sosteniendo flujos estables mediante humedales, suelos húmedos y cobertura forestal continua.',
        'pa': 'Presencia y Accesibilidad (PA 42.7) evalúa la presencia efectiva de agua accesible, considerando agua abierta detectada, densidad espacial, accesibilidad superficial y visibilidad hidrológica. Es el subíndice más cercano a la percepción humana directa. El capital hídrico total medido en 36 meses registra un 52.8% del terreno con presencia de aguas: un 42.7% corresponde a agua (incluida la contenida en el follaje y vegetación) y un 10.1% a humedales. El agua que muestra persistencia mensual en un período de 24 meses alcanza un 28.3%, correspondiente a agua permanente en un 10% del terreno, a agua estacional sobre un 12.3% y a humedales en un 6% de la superficie. Su valor medio indica que el agua no está omnipresente en superficie, se distribuye en cuerpos medianos y pequeños, y gran parte del agua no es directamente visible, pero da un importante soporte. Baja dominancia de grandes lagos o ríos abiertos. Alta proporción de agua en forma difusa (subsuperficie, humedales). PA más bajo no es un déficit, sino una característica del sistema. La presencia de agua superficial es moderada y distribuida. El sistema no concentra el recurso en grandes cuerpos visibles, sino que lo dispersa a través del paisaje.',
        'cbc': 'La Capacidad de Amortiguación Climática (CBC 23.9) evalúa la capacidad del territorio para amortiguar escenarios de variabilidad climática, a partir de señales climáticas estructurales. Integra indicadores de recarga efectiva (balance precipitación–evapotranspiración), señal nival promedio, acumulación topográfica y proxies de almacenamiento hídrico potencial, expresando el grado en que el territorio puede amortiguar shocks climáticos. El valor indica una baja dominancia de amortiguación climática concentrada, asociada a la ausencia de grandes reservas nivales persistentes, glaciares o excedentes climáticos estructurales de largo plazo. En este contexto, la amortiguación del territorio frente a eventos climáticos extremos depende principalmente de su potente estructura y funcionamiento hídrico actual. La resistencia hídrica efectiva del territorio emerge de la interacción entre conectividad hídrica (CH), regulación hídrica (RA) y amortiguación climática (CBC), donde cada subíndice describe una dimensión complementaria del sistema.',
        'hydro-data': 'Dataset hidrológico comprensivo con indicadores clave: Agua funcional total 42.7% (~392.5 ha), Humedales totales 10.1% (~92.7 ha), Agua permanente ~10%, Agua estacional ~12.3%, Humedales subsuperficiales ~6%, Riesgo hídrico total 40.9. Casi la mitad del territorio participa funcionalmente del sistema hídrico. Laguna primaria de altura (32 ha) funciona como reservorio natural de agua dulce capturando deshielo nival y precipitaciones de altura. Derechos de agua registrados documentados. Datos integran lagunas, ríos, humedales y sistemas permanentes de agua dulce. Aportes nivales de cerros circundantes, precipitaciones, extensa red de agua subsuperficial y numerosos humedales. Índices de agua Sentinel-2 MSI (MNDWI, NDWI), Landsat-8, DEM ALOS/PALSAR (12.5m), análisis temporal 2000-2024. Confianza 0.64 (6 fuentes activas). Una fracción significativa del territorio actúa como infraestructura hídrica activa, incluso donde no hay agua abierta visible.',
        'hydro-advanced': 'Modelado hidrológico avanzado revela un sistema bufferizado que absorbe excedentes y los libera gradualmente, manteniendo funciones incluso en períodos secos. El sistema combina agua permanente (~10%), agua estacional (~12.3%) y humedales sin agua abierta (~6%), permitiendo estabilidad funcional en el tiempo. Bosque, suelos orgánicos y humedales proveen retención natural excepcional. La combinación de nieve, lagunas, humedales y agua subsuperficial crea un sistema altamente resiliente contra sequías, eventos extremos y cambios en patrones de precipitación, funcionando como amortiguador climático natural. Diagnóstico eco-hidrológico muestra que el agua actúa como infraestructura ecológica distribuida más que como recurso concentrado. Los cerros nevados circundantes aportan nieve y precipitaciones que sostienen la red hídrica con varias lagunas, gran número de humedales y una importante red de agua subsuperficial.',
        'hydro-confidence': 'La confianza del índice es media-alta (0.64), consistente con territorios de bosque templado húmedo con dosel denso, nubosidad crónica y topografía compleja. Integra múltiples fuentes y validaciones cruzadas (6 fuentes activas). Los riesgos hídricos se mantienen en rangos moderados (riesgo total 40.9), sin señales de estrés hídrico estructural o vulnerabilidad crítica. Propios de sistemas montanos activos sin indicios de colapso funcional. El sistema hídrico presenta una combinación equilibrada de agua permanente, estacional y humedales, permitiendo estabilidad funcional en el tiempo y estabilidad hidrológica de largo plazo bajo condiciones climáticas cambiantes.',
        'ev': `El subíndice Vigor Ecosistémico representa la expresión espacial del vigor eco fisiológico del sistema, estimado a partir del percentil 90 del NDVI multianual calculado sobre una ventana continua de cinco años; 2020 - 2025.

Desde una perspectiva geomática, el uso del NDVI p90 permite aproximar el techo funcional recurrente de actividad fotosintética por píxel, reduciendo de manera significativa la influencia de valores atípicos, anomalías interanuales y sesgos asociados a ventanas temporales incompletas o a la nubosidad persistente, particularmente relevante en paisajes húmedos de montaña.

En sistemas cordilleranos como la Reserva Cochamó, el vigor vegetacional raramente alcanza valores extremos cercanos a la saturación debido a limitaciones físicas que el sensor óptico registra de forma consistente: presencia de umbrías prolongadas, reducción de la irradiancia efectiva por orientación y pendiente, estacionalidad térmica marcada y una temporada de crecimiento acotada por condiciones altitudinales frías.

Adicionalmente, la heterogeneidad geo-hidro-nival del territorio —con coexistencia de bosque, roca expuesta, agua superficial, humedales y nieve estacional— introduce una variabilidad espacial persistente que modula el promedio funcional del sistema sin implicar deterioro alguno.

En este marco, un EV de 77.14 describe un ecosistema vigoroso, estructuralmente sano y eco fisiológicamente estable, cuya productividad está regulada por la arquitectura geomorfológica y climática del paisaje más que por limitaciones hídricas o antrópicas.

La integración conceptual con el Hydro Index® refuerza esta lectura: el capital hídrico del sistema se manifiesta principalmente a través de organización, regulación y conectividad (CH y RA elevados), mientras que la presencia y accesibilidad del agua no es homogénea a escala predial, coherente con la morfología abrupta del territorio.

La data aportada por Risk Index® indica que el estrés climático moderado no se traduce en pérdida de vigor gracias a la acción de reguladores físicos locales —umbrías, gradientes altitudinales, nivalidad y nubosidad— que amortiguan los extremos climáticos. EV, por tanto, expresa integridad funcional sostenida bajo condiciones estructurales propias de un paisaje de montaña.`,
        'dc': `El subíndice cuantifica la densidad local de conectividad estructural del hábitat core mediante un promedio focal del núcleo ecosistémico en una vecindad espacial de aproximadamente 180 metros.

Desde el punto de vista geomático, DC no modela conectividad como un grafo ni como un corredor de costo mínimo, sino como una medida directa de cuánta superficie de hábitat núcleo rodea cada píxel, capturando así la continuidad espacial inmediata del sistema.

En paisajes cordilleranos, esta métrica adquiere una relevancia particular, ya que la conectividad funcional no opera únicamente en el plano horizontal. La continuidad estructural detectada por DC refleja la interconexión entre quebradas, laderas, corredores riparios y gradientes altitudinales, permitiendo la persistencia de flujos ecológicos de corta y media distancia, así como micro-migraciones altitudinales asociadas a respuestas climáticas.

Un DC de 90.38 indica que el núcleo ecosistémico no se presenta como un parche aislado, sino como una matriz continua a escala local, condición clave para la resiliencia ecológica en ambientes montañosos.

Esta lectura se ve reforzada por el contexto territorial en el que se inserta el predio: un continuo protegido binacional de 1.600.000 hectáreas de extensión, que amplifica la conectividad efectiva más allá de los límites del AOI, reduciendo riesgos de aislamiento genético y favoreciendo procesos de recolonización y rescate ecológico tras perturbaciones externas.

La coherencia con el Risk Index® es directa: un riesgo de fragmentación extremadamente bajo encuentra aquí su correlato estructural, confirmando que la conectividad del sistema no está comprometida por presiones internas ni por discontinuidades del paisaje.`,
        'fc': `Este subíndice caracteriza la estructura espacial de la cobertura ecosistémica a partir de la configuración de parches del hábitat core y la presencia de borde funcional en su vecindad inmediata, incorporando una erosión de borde diseñada para distinguir núcleo real de transiciones periféricas.

En términos de ecología del paisaje, FC no mide fragmentación antrópica de manera exclusiva, sino que detecta la presencia y distribución de interfaces espaciales.

En la Reserva Cochamó, un valor de FC de 69.36 no debe interpretarse como señal de degradación ni pérdida de continuidad, sino como expresión geomática de un paisaje estructuralmente complejo. En sistemas cordilleranos con alta heterogeneidad topográfica e hídrica, los bordes naturales —bosque-humedal, bosque-agua, bosque-roca, bosque-nieve estacional— son abundantes y funcionales, generando interfaces que incrementan el edge local sin asociarse a disturbio humano.

Esta fragmentación aparente es coherente con la organización eco hidrológica del territorio, donde el agua se distribuye en corredores, fondos de valle y mallines, mientras que cumbres y laderas de alta energía geomorfológica estructuran el espacio en unidades funcionales diferenciadas.

La integración con la data de Risk Index® es clara: una exposición geomorfológica elevada (GE) describe precisamente esta organización física del relieve, que FC captura desde la perspectiva espacial de cobertura.

Desde una lectura decisional, este rango de Fragmentación de Cobertura es indicativo de heterogeneidad estructural positiva, asociada a diversidad de nichos, microclimas y rutas funcionales, elementos clave en sistemas de refugio climático de montaña.`,
        'pa-inv': `El subíndice PA⁻ cuantifica la intensidad de la huella antrópica detectable mediante sensores satelitales, integrando información sobre infraestructura, uso del suelo y radiancia nocturna como proxy de actividad humana.

La inversión del índice permite que valores altos representen baja presión efectiva, facilitando su integración con métricas de integridad estructural.

Un PA⁻ de 90.10 confirma que la Reserva Cochamó presenta una presión antrópica extremadamente baja, con ausencia de señales consistentes de urbanización, agricultura o actividad humana nocturna. Esta condición no es una apreciación cualitativa, sino una lectura geomática objetiva basada en múltiples fuentes independientes.

La concordancia con la data de Risk Index® es directa: una presión territorial mínima y un riesgo de fragmentación casi inexistente encuentran aquí su expresión estructural.

Esta baja presión antrópica es un prerrequisito fundamental para que la continuidad ecológica y la conectividad del núcleo se mantengan en niveles tan elevados, y para que la exposición geomorfológica del territorio no se traduzca en degradación activa.`,
        'ce': `El subíndice representa la continuidad funcional del sistema ecológico mediante la integración de dos componentes geomáticos fundamentales: la intactness derivada de la distancia a disturbios antrópicos detectables y la proximidad espacial a elementos hidro-estructurales del paisaje.

Un indicador de Conectividad Ecológica de 98.86 indica que Reserva Cochamó conserva una continuidad ecológica prácticamente máxima, sustentada principalmente en la ausencia de infraestructura, agricultura y señales de intervención humana, y secundariamente modulada por la organización espacial de elementos hidro-geomorfológicos. La alta puntuación refleja un territorio donde los reguladores naturales del clima y del funcionamiento ecosistémico pueden operar sin interferencias externas.

Desde una perspectiva eco-territorial, esta continuidad se traduce en la preservación de microclimas de umbría, gradientes altitudinales fríos, almacenamiento nival estacional y liberación gradual de agua, así como en una pluviosidad orográfica persistente que sostiene la humedad efectiva del sistema. Estos mecanismos, intrínsecamente ligados a la geomorfología del paisaje, confieren al territorio un carácter de refugio climático estructural.

En coherencia con Risk Index®, un CE tan elevado confirma que el riesgo relevante para el sistema es exógeno y físico, no resultado de procesos de degradación interna y que la Susceptibilidad de eventos de Remoción vinculados a la geomorfología del paisaje de la AOI están sujetos a la ocurrencia de fenómenos climáticos exacerbados como desencadenantes.`,
        'ue': 'Mapeo de Unidades Ecológicas identifica 8 comunidades naturales distintas basadas en posición topográfica, régimen de humedad y composición de vegetación. Bosque antiguo dominado por Nothofagus comprende 62% del área. Complejos de humedales ocupan fondos de valle (8% del AOI). Integridad de matriz natural mantenida con conversión antrópica mínima.',
        'carbon-score': 'Índice de Carbono (68.3) indica fuerte potencial de secuestro. Biomasa sobre el suelo estimada en 245 tC/ha en rodales maduros. Pools de carbono orgánico del suelo promedian 180 tC/ha en 30cm superiores. Stock total de carbono aproximadamente 425 tC/ha. Tasa de secuestro anual 2.8 tC/ha/año. Protección de stocks existentes priorizada sobre actividades de mejora.',
        
        // Subíndices Risk Index
        'cs': `CS representa la posición relativa de sequedad climática (P/PET) y su comportamiento en la serie de 10 años analizada.
Un CS < 45 indica estrés climático moderado, relevante para decisiones de resiliencia, sin representar una condición crítica.
El valor Dry = 44.5 del Hydro Index® refuerza esta lectura desde el modelo hídrico, confirmando que la sequedad es un componente presente del sistema no por ausencia de capital hídrico, sino por la morfología cordillerana, los gradientes altitudinales y la distribución espacial del agua.`,
        'rhm': `RHm evalúa la presión hidroclimática de contexto regional en un entorno ampliado, independiente del funcionamiento hidrológico interno del predio.
Un RHm < 55 posiciona el activo en un contexto de presión hídrica regional moderada, lo cual no contradice la presencia de un sistema hidrológico funcional a escala local.
Se refuerza la necesidad de analizar ventanas de humedad, recarga y continuidad temporal del capital hídrico, particularmente en sistemas cordilleranos donde la persistencia depende de aportes nivales, regulación subsuperficial y microclimas de umbría.`,
        'ge': `GE no representa degradación ambiental activa ni pérdida estructural del territorio.
Este subíndice expresa la exposición geomorfológica potencial asociada a la combinación de pendiente, energía del relieve y cobertura vegetal relativa, propia de paisajes cordilleranos.
Un GE > 65 indica que el sistema presenta alta energía geomorfológica, la cual puede activar procesos erosivos únicamente bajo condiciones gatillantes, tales como:
- Alteración significativa de la cobertura vegetal
- Eventos de precipitación intensa
- Derretimiento nival acelerado bajo isotermas elevadas
En ausencia de presión antrópica o cambio de uso del suelo, esta condición corresponde a una característica estructural natural del paisaje, no a un riesgo ambiental efectivo.
Analizado conjuntamente con indicadores de transporte y escorrentía (Sed = 40.6; Flood = 37.7), los valores describen un grado de susceptibilidad geomorfológica–hidrológica latente, propio de sistemas de montaña, no un riesgo hídrico activo.
Su activación depende de eventos extremos.`,
        'rf': `Continuidad natural muy alta.
Este RF extremadamente bajo indica que el territorio se clasifica mayoritariamente como cobertura natural continua, con nula presencia de matrices antrópicas internas y alta coherencia espacial del ecosistema.

Desde una lectura de riesgo, esta condición implica que el sistema no presenta fragmentación estructural significativa que afecte la conectividad ecológica, los flujos biofísicos o la integridad funcional del paisaje.
La baja fragmentación actúa como factor de estabilidad, reduciendo efectos de borde, discontinuidades hidrológicas y pérdida de resiliencia asociada a la ruptura del mosaico natural.

En el contexto del índice, RF bajo no elimina otros riesgos físicos, pero sí evita su amplificación por degradación espacial interna, contribuyendo a que el riesgo global permanezca en rangos medios–bajos.`,
        'lp': `Se detecta presión humana efectiva mínima.
LP casi nulo indica que el modelo no detecta presión antrópica relevante dentro del AOI.
Desde una lectura de resiliencia, esto es un factor estructural favorable, ya que el riesgo global no está siendo empujado por degradación interna por uso de suelo.`,
        'risk-data': `Dataset comprensivo de riesgo con indicadores clave: Índice de Riesgo Final (IR) 39.03 clasificado como nivel de riesgo medio–bajo. Aseguramiento de Calidad (QA) 78.32 con intervalo de confianza 95% ±3.90, indicando análisis robusto y trazable. Año de análisis 2024 con serie temporal de 10 años (120/120 meses utilizados). Fuentes de datos incluyen Sentinel-2 (N: 874/874 escenas procesadas). Análisis multiescala integra imágenes ópticas (resolución 10–30 m), datos topográficos (30 m) y datasets climáticos (~4–5 km). Desglose de sub-índices: Estrés Climático (CS) 44.75, Hidrología Regional (RHm) 54.29, Exposición Geomorfológica (GE) 66.31, Riesgo de Fragmentación (RF) 3.00, Presión del Territorio (LP) 1.61. El territorio presenta un perfil de riesgo moderado impulsado principalmente por sensibilidad geomorfológica natural, con presión antrópica mínima y fragmentación extremadamente baja, confirmando un paisaje intacto con coherencia ecológica funcional.`,
      };

      const content = language === 'en' ? subIndexContentEN[selectedSubIndex] : subIndexContentES[selectedSubIndex];
      if (content) return content;
    }

    // Si no hay sub-índice seleccionado, mostrar contenido general del índice
    if (currentIndex.id === 'hydro') {
      return language === 'en' 
        ? 'Cochamó Reserve exhibits a robust and highly efficient hydrological system. Total hydrological connectivity recorded over the last 3 years includes 42.7% of territory as water bodies (392.5 ha) and 10.1% as wetlands (92.7 ha) — representing all satellite water signals detected. The visualization layer shows Monthly Persistence observed over 24 months: permanent water (~10%), seasonal water (~12.3%), and wetlands (~6%), creating balanced temporal stability totaling 28.3% of AOI. Primary high-altitude lagoon (32 ha) acts as natural hydrological infrastructure, capturing snowmelt and high-elevation rainfall. Hydrological connectivity (CH 73.1) is excellent with lagoon serving as central network node. Strong regulation capacity (RA 67.6) through forest-water integration enables slow, continuous filtration. Regional water stress from climate change is effectively buffered here by local hydrological defenses. The combination of snow, lagoons, wetlands, and subsurface water creates a highly resilient system functioning as natural climate buffer against droughts and extreme events.'
        : 'Reserva Cochamó exhibe un sistema hidrológico robusto y altamente eficiente. La conectividad hídrica total registrada durante los últimos 3 años incluye 42.7% del territorio como cuerpos de agua (392.5 ha) y 10.1% como humedales (92.7 ha) — representando toda señal satelital de agua detectada. La capa de visualización muestra la Persistencia Mensual observada en 24 meses: agua permanente (~10%), agua estacional (~12.3%) y humedales (~6%), creando estabilidad temporal balanceada totalizando 28.3% del AOI. Laguna primaria de altura (32 ha) actúa como infraestructura hidrológica natural, capturando deshielo nival y precipitaciones de altura. Conectividad hídrica (CH 73.1) es excelente con laguna funcionando como nodo central de red. Fuerte capacidad de regulación (RA 67.6) mediante integración bosque-agua permite filtración lenta y continua. El estrés hídrico regional creciente debido al cambio climático se ve eficazmente amortiguado aquí por defensas hídricas locales. La combinación de nieve, lagunas, humedales y agua subsuperficial crea un sistema altamente resiliente funcionando como amortiguador climático natural contra sequías y eventos extremos.';
    }
    
    if (currentIndex.id === 'esi') {
      return language === 'en' 
        ? 'Ecosystem structural integrity with 81.8 score. Ecosystem Vigor (EV 77.14) indicates high primary productivity. Connectivity Density (DC 90.38) is excellent. Coverage Fragmentation (FC 69.36) shows moderate functional integrity. Ecological Continuity (CE 98.86) is near-maximum, enhanced by Futaleufú River riparian corridor.'
        : 'Integridad estructural ecosistémica con score 81.8. Vigor Ecosistémico (EV 77.14) indica alta productividad primaria. Densidad de Conectividad (DC 90.38) es excelente. Fragmentación de Cobertura (FC 69.36) muestra integridad funcional moderada. Continuidad Ecológica (CE 98.86) es casi máxima, potenciada por corredor ribereño del río Futaleufú.';
    }
    
    if (currentIndex.id === 'carbon') {
      return language === 'en' 
        ? 'Strong carbon sequestration potential with 68.3 index. Biomass stocks are concentrated in mature forest stands. Soil carbon pools are well-developed. Medium disturbance sensitivity requires protection measures in vulnerable areas.'
        : 'Fuerte potencial de secuestro de carbono con índice 68.3. Reservas de biomasa concentradas en rodales de bosque maduro. Pools de carbono del suelo bien desarrollados. Sensibilidad media a perturbaciones requiere medidas de protección en áreas vulnerables.';
    }
    
    if (currentIndex.id === 'risk') {
      return language === 'en' 
        ? 'Medium overall risk profile (IR 39.03) driven by physical-natural conditions. Geomorphological Exposure (GE 66.31) is the main driver, reflecting high relief energy characteristic of mountain landscapes. Climate Stress (CS 44.75) and Regional Hydrology (RHm 54.29) are moderate. Fragmentation Risk (RF 3.00) and Land Pressure (LP 1.61) are extremely low, confirming minimal anthropogenic pressure.'
        : 'Perfil de riesgo general medio (IR 39.03) impulsado por condiciones físico-naturales. Exposición Geomorfológica (GE 66.31) es el principal driver, reflejando alta energía de relieve característica de paisajes de montaña. Estrés Climático (CS 44.75) e Hidrología Regional (RHm 54.29) son moderados. Riesgo de Fragmentación (RF 3.00) y Presión del Territorio (LP 1.61) son extremadamente bajos, confirmando presión antrópica mínima.';
    }

    return '';
  };

  // ============================================
  // ROTACIÓN 360° CON PAUSA AUTOMÁTICA EN INTERACCIONES
  // ============================================
  const startRotation = () => {
    if (!mapRef.current || isRotatingRef.current) return;
    
    console.log('🎬 [Rotation] ===== INICIANDO ROTACIÓN 360° =====');
    
    setIsRotating(true);
    isRotatingRef.current = true;
    isPausedRef.current = false;
    
    // 🎯 INICIALIZACIÓN LIMPIA: Forzar bearing a 0 para rotación consistente
    const currentBearing = mapRef.current.getBearing();
    console.log(`[Rotation] Bearing actual: ${currentBearing.toFixed(2)}° → Forzando a 0°`);
    
    mapRef.current.setBearing(0);
    bearingRef.current = 0;
    totalRotatedRef.current = 0;
    
    console.log('[Rotation] ✅ Estados reseteados: bearing=0, totalRotated=0');
    
    // 🔊 Limpiar completamente cualquier síntesis anterior antes de iniciar audio
    console.log('[Rotation] 🔇 Limpiando sistema de audio...');
    
    // Limpiar event handlers del utterance anterior para evitar errores falsos
    if (rotation360AudioRef.current) {
      rotation360AudioRef.current.onstart = null;
      rotation360AudioRef.current.onend = null;
      rotation360AudioRef.current.onerror = null;
    }
    
    window.speechSynthesis.cancel(); // Siempre cancelar, incluso si no está hablando
    rotation360AudioRef.current = null; // Limpiar referencia anterior
    setIsPlaying360Audio(false);
    
    // Delay de 150ms para asegurar limpieza completa del audio anterior
    setTimeout(() => {
      console.log('[Rotation] 🔊 Iniciando audio de narración 360°');
      play360Audio();
    }, 150);
    
    // Detectar interacciones del usuario y pausar temporalmente
    const handleUserInteraction = () => {
      isPausedRef.current = true;
      
      // Limpiar timeout anterior
      if (pauseTimeoutRef.current) {
        clearTimeout(pauseTimeoutRef.current);
      }
      
      // Reanudar rotación después de 1 segundo sin interacciones
      pauseTimeoutRef.current = window.setTimeout(() => {
        isPausedRef.current = false;
      }, 1000);
    };
    
    // Sincronizar bearing cuando el usuario rota manualmente
    const handleRotate = () => {
      if (mapRef.current) {
        bearingRef.current = mapRef.current.getBearing();
      }
    };
    
    // Escuchar eventos de interacción
    mapRef.current.on('wheel', handleUserInteraction);
    mapRef.current.on('touchstart', handleUserInteraction);
    mapRef.current.on('mousedown', handleUserInteraction);
    mapRef.current.on('zoomstart', handleUserInteraction);
    mapRef.current.on('rotate', handleRotate); // Sincronizar durante rotación manual
    mapRef.current.on('pitch', handleUserInteraction); // Pausar durante cambio de pitch
    
    const rotate = () => {
      if (!mapRef.current || !isRotatingRef.current) return;
      
      // Solo rotar si no está pausado por interacción del usuario
      if (!isPausedRef.current) {
        // ⏱️ Velocidad: 4.20°/s a 60fps = 0.070° por frame
        bearingRef.current = (bearingRef.current + 0.070) % 360;
        mapRef.current.jumpTo({ bearing: bearingRef.current });
        
        // Incrementar contador de grados totales rotados
        totalRotatedRef.current += 0.070;
        
        // Log cada 90° para monitorear progreso
        if (Math.floor(totalRotatedRef.current) % 90 === 0 && Math.floor(totalRotatedRef.current - 0.070) % 90 !== 0) {
          console.log(`[Rotation] Progreso: ${totalRotatedRef.current.toFixed(1)}° / 360°`);
        }
        
        // Detener automáticamente al completar 360°
        if (totalRotatedRef.current >= 360) {
          console.log(`[Rotation] ✅ 360° completado (${totalRotatedRef.current.toFixed(2)}°) - deteniendo automáticamente`);
          stopRotation();
          return;
        }
      }
      
      rotationAnimationRef.current = requestAnimationFrame(rotate);
    };
    
    // Iniciar rotación con requestAnimationFrame
    rotationAnimationRef.current = requestAnimationFrame(rotate);
    console.log('[Rotation] ▶️ Loop de animación iniciado - Velocidad: 0.070°/frame (4.20°/s a 60fps)');
  };

  const stopRotation = () => {
    console.log(`🛑 [Rotation] Deteniendo rotación - Total rotado: ${totalRotatedRef.current.toFixed(2)}°`);
    
    setIsRotating(false);
    isRotatingRef.current = false;
    isPausedRef.current = false;
    
    if (rotationAnimationRef.current) {
      cancelAnimationFrame(rotationAnimationRef.current);
      rotationAnimationRef.current = null;
    }
    
    if (pauseTimeoutRef.current) {
      clearTimeout(pauseTimeoutRef.current);
      pauseTimeoutRef.current = null;
    }
    
    // Detener audio de narración 360° si está reproduciéndose
    if (rotation360AudioRef.current) {
      console.log('[Rotation] 🔇 Deteniendo audio de narración 360°');
      
      // Limpiar event handlers ANTES de cancelar para evitar errores falsos
      rotation360AudioRef.current.onstart = null;
      rotation360AudioRef.current.onend = null;
      rotation360AudioRef.current.onerror = null;
      
      window.speechSynthesis.cancel();
      setIsPlaying360Audio(false);
      rotation360AudioRef.current = null;
    }
    
    // Remover listeners
    if (mapRef.current) {
      mapRef.current.off('wheel');
      mapRef.current.off('touchstart');
      mapRef.current.off('mousedown');
      mapRef.current.off('zoomstart');
      mapRef.current.off('rotate');
      mapRef.current.off('pitch');
    }
    
    // Si hay una grabación activa, detenerla automáticamente
    if (isRecording && mediaRecorderRef.current) {
      console.log('[Rotation] 360° completado - deteniendo grabación automáticamente');
      stopRecording();
    }
  };

  const toggleRotation = () => {
    if (isRotatingRef.current) {
      stopRotation();
    } else {
      startRotation();
    }
  };

  // ============================================
  // Función para reproducir audio durante rotación 360°
  // ============================================
  const play360Audio = () => {
    // Detener cualquier audio de rotación en reproducción
    if (rotation360AudioRef.current) {
      // 🔇 Limpiar event handlers ANTES de cancelar para evitar errores falsos
      rotation360AudioRef.current.onstart = null;
      rotation360AudioRef.current.onend = null;
      rotation360AudioRef.current.onerror = null;
      
      window.speechSynthesis.cancel();
      setIsPlaying360Audio(false);
      rotation360AudioRef.current = null;
      return;
    }
    
    // ✅ Verificar que speechSynthesis esté listo y no esté hablando
    if (window.speechSynthesis.speaking) {
      console.warn('[360° Audio] ⚠️ speechSynthesis ocupado, esperando limpieza...');
      // Esperar un poco más si todavía está limpiando
      setTimeout(() => play360Audio(), 100);
      return;
    }

    const audioTextES = `
Reserva Cochamó es un activo privado estratégico de conservación en la Patagonia Andina chilena, inserto en uno de los bloques ecológicos continuos más relevantes del hemisferio sur. Forma parte de un sistema binacional de más de un millón seiscientas mil hectáreas protegidas, clave para la estabilidad hídrica, climática y ecológica regional.

Cumple un rol estructural dentro de un sistema de montaña templada húmeda donde la continuidad del bosque y la persistencia de la humedad sostienen la resiliencia territorial. En un escenario global de fragmentación de ecosistemas primarios, su integridad aporta estabilidad funcional a escala andina.

Su sistema hidrológico está dominado por lagunas de recarga nival y pluviométrica, junto a una red densa de humedales permanentes y estacionales que regulan almacenamiento, infiltración y liberación progresiva de agua. Esta arquitectura natural amortigua extremos climáticos y sostiene procesos ecológicos continuos.

La geomorfología de pendientes pronunciadas y valles cerrados favorece la retención hídrica, y también define su principal sensibilidad: la eventual pérdida de cobertura frente a eventos climáticos exacerbados que podrían alterar el equilibrio entre infiltración y escorrentía.

Ubicado en el centro del interés internacional por la conservación privada y contiguo a Hacienda Pucheguin —referente reciente en custodia ambiental a gran escala—, el territorio adquiere relevancia estratégica más allá de su superficie.

Permite consolidar conectividad ecológica y fortalecer corredores de escala mayor. Para la investigación científica, ofrece un sistema funcional poco intervenido desde el cual generar líneas base robustas y datos comparables para análisis regionales de cambio climático.

Su configuración hidro-geomorfológica lo posiciona como plataforma natural para monitoreo hidrológico de montaña y como referencia para modelamiento climático en la macrorregión andino-patagónica. Asimismo, presenta alto potencial para el desarrollo de programas activos de asilvestramiento a escala de paisaje, pudiendo proyectarse como núcleo operativo dentro de estrategias de restauración ecológica y fortalecimiento de dinámicas poblacionales de especies sensibles en el largo plazo.

Explore el panel interactivo para profundizar en los diagnósticos sistémicos, metadatos e indicadores ambientales que sustentan este activo y comprender su relevancia dentro del sistema territorial mayor al que pertenece.
`;

    const audioTextEN = `
Cochamó Reserve is a strategic private conservation asset in the Chilean Andean Patagonia, embedded within one of the most significant continuous ecological blocks in the southern hemisphere. It is part of a binational system of over one million six hundred thousand protected hectares, key to regional hydrological, climatic, and ecological stability.

It plays a structural role within a humid temperate mountain system where forest continuity and moisture persistence sustain territorial resilience. In a global scenario of primary ecosystem fragmentation, its integrity contributes functional stability at an Andean scale.

Its hydrological system is dominated by snow and rainfall-fed lagoons, along with a dense network of permanent and seasonal wetlands that regulate storage, infiltration, and progressive water release. This natural architecture buffers climatic extremes and sustains continuous ecological processes.

The geomorphology of steep slopes and enclosed valleys favors water retention, while also defining its main sensitivity: the potential loss of cover in the face of exacerbated climatic events that could alter the balance between infiltration and runoff.

Located at the center of international interest in private conservation and adjacent to Hacienda Pucheguin—a recent landmark in large-scale environmental stewardship—the territory acquires strategic relevance beyond its surface area.

It enables the consolidation of ecological connectivity and the strengthening of larger-scale corridors. For scientific research, it offers a minimally intervened functional system from which to generate robust baselines and comparable data for regional climate change analysis.

Its hydro-geomorphological configuration positions it as a natural platform for mountain hydrological monitoring and as a reference for climate modeling in the Andean-Patagonian macro-region. Likewise, it presents high potential for the development of active rewilding programs at landscape scale, being able to project itself as an operational nucleus within strategies of ecological restoration and strengthening of population dynamics of sensitive species in the long term.

Explore the interactive panel to delve deeper into the systemic diagnostics, metadata, and environmental indicators that support this asset and understand its relevance within the larger territorial system to which it belongs.
`;

    const text = language === 'es' ? audioTextES : audioTextEN;
    const utterance = new SpeechSynthesisUtterance(text);
    
    // Configuración de voz (misma que instrucciones)
    utterance.lang = language === 'es' ? 'es-ES' : 'en-US';
    utterance.rate = 0.9;
    utterance.pitch = 1.0;
    utterance.volume = 1.0;

    // Seleccionar voz profesional femenina
    if (availableVoices.length > 0) {
      const selectedVoice = language === 'es'
        ? availableVoices.find(v => v.name === 'Microsoft Sabina - Spanish (Spain)') || availableVoices.find(v => v.name.includes('Sabina'))
        : availableVoices.find(v => v.name === 'Google UK English Female') || availableVoices.find(v => v.name.includes('Google UK English Female'));
      
      if (selectedVoice) {
        utterance.voice = selectedVoice;
        console.log('🔊 [360° Audio] Voz:', selectedVoice.name);
      }
    } else {
      console.log('��� [360° Audio] Usando voz predeterminada del navegador para idioma:', language);
    }

    // Eventos
    utterance.onstart = () => {
      setIsPlaying360Audio(true);
      console.log('[360° Audio] Narración iniciada');
    };
    utterance.onend = () => {
      setIsPlaying360Audio(false);
      rotation360AudioRef.current = null;
      console.log('[360° Audio] Narración finalizada');
    };
    utterance.onerror = (event: any) => {
      setIsPlaying360Audio(false);
      rotation360AudioRef.current = null;
      
      // ✅ Ignorar errores normales de cancelación/interrupción (no son errores reales)
      if (event.error === 'canceled' || event.error === 'interrupted') {
        console.log(`[360° Audio] ℹ️ Audio ${event.error === 'canceled' ? 'cancelado' : 'interrumpido'} (normal)`);
        return;
      }
      
      // ❌ Solo loggear errores REALES como problemas
      console.error('[360° Audio] ❌ Error en narración:', {
        error: event.error || 'unknown',
        mensaje: !event.error ? 'Error sin código específico (posible bug del navegador)' :
                 event.error === 'audio-busy' ? 'Sistema de audio ocupado' :
                 event.error === 'audio-hardware' ? 'Problema con hardware de audio' :
                 event.error === 'network' ? 'Error de red' :
                 event.error === 'synthesis-unavailable' ? 'Síntesis de voz no disponible' :
                 event.error === 'synthesis-failed' ? 'Fallo en síntesis de voz' :
                 event.error === 'language-unavailable' ? 'Idioma no disponible' :
                 event.error === 'voice-unavailable' ? 'Voz no disponible' :
                 event.error === 'text-too-long' ? 'Texto demasiado largo' :
                 event.error === 'invalid-argument' ? 'Argumento inválido' :
                 `Error desconocido: ${event.error}`,
        charIndex: event.charIndex,
        elapsedTime: event.elapsedTime
      });
    };

    rotation360AudioRef.current = utterance;
    
    // ✅ Intentar reproducir con manejo de errores
    try {
      window.speechSynthesis.speak(utterance);
      console.log('[360° Audio] ✅ Audio iniciado correctamente');
    } catch (error) {
      console.error('[360° Audio] ❌ Error al iniciar audio:', error);
      setIsPlaying360Audio(false);
      rotation360AudioRef.current = null;
    }
  };

  // Función para reproducir instrucciones de audio
  const playInstructions = () => {
    // Detener cualquier audio en reproducción
    if (speechSynthesisRef.current) {
      window.speechSynthesis.cancel();
      setIsPlayingAudio(false);
      speechSynthesisRef.current = null;
      return;
    }

    const audioTextES = `
Bienvenido al visualizador de inteligencia ambiental satelital de avanzada de Lýdaris Data.

Use la botonera superior para zoom in, zoom out, alternar entre vista 2D y 3D, 
cambiar a modo satelital o topográfico, y girar en 360 grados de forma automática.
El botón radar le traerá de regreso al área en revisión.

El visualizador le da también la opción de rotar el mapa manualmente, en todas las direcciones y ángulos manteniendo pulsados Control más botón izquierdo del mouse.

El panel dispone de información detallada del activo en revisión, data panels, mapas con capas geosatelitales especializadas, acceso a geoanálisis interactivo y a la tarjeta digital del activo ambiental optimizada con código QR.

Expanda a pantalla completa para una experiencia mejorada e inmersiva que le permitirá conocer este activo en detalle.
`;

    const audioTextEN = `
Welcome to the Lydaris Data advanced satellite environmental intelligence viewer.

Use the top toolbar to zoom in, zoom out, toggle between 2D and 3D view, 
switch between satellite or topographic mode, and rotate 360 degrees automatically.
The radar button will bring you back to the area under review.

The viewer also gives you the option to manually rotate the map in all directions and angles by holding Control plus the left mouse button.

The panel provides detailed information on the asset under review, data panels, maps with specialized geosatellite layers, access to interactive geoanalysis, and the digital environmental asset card optimized with QR code.

Expand to full screen for an improved and immersive experience that will allow you to explore this asset in detail.
`;

    const text = language === 'es' ? audioTextES : audioTextEN;
    const utterance = new SpeechSynthesisUtterance(text);
    
    // Configuración de voz
    utterance.lang = language === 'es' ? 'es-ES' : 'en-US';
    utterance.rate = 0.9; // Velocidad más clara
    utterance.pitch = 1.0;
    utterance.volume = 1.0;

    // Seleccionar voz profesional femenina
    if (availableVoices.length > 0) {
      const selectedVoice = language === 'es'
        ? availableVoices.find(v => v.name === 'Microsoft Sabina - Spanish (Spain)') || availableVoices.find(v => v.name.includes('Sabina'))
        : availableVoices.find(v => v.name === 'Google UK English Female') || availableVoices.find(v => v.name.includes('Google UK English Female'));
      
      if (selectedVoice) {
        utterance.voice = selectedVoice;
        console.log('🔊 [User Guide] Voz:', selectedVoice.name);
      }
    }

    // Eventos
    utterance.onstart = () => setIsPlayingAudio(true);
    utterance.onend = () => {
      setIsPlayingAudio(false);
      speechSynthesisRef.current = null;
    };
    utterance.onerror = () => {
      setIsPlayingAudio(false);
      speechSynthesisRef.current = null;
    };

    speechSynthesisRef.current = utterance;
    window.speechSynthesis.speak(utterance);
  };

  // ============================================
  // FUNCIÓN PARA AUDIO DEL VIDEO
  // ============================================
  const playVideoAudio = () => {
    // Detener cualquier audio de video en reproducción
    if (videoAudioRef.current) {
      window.speechSynthesis.cancel();
      setIsPlayingVideoAudio(false);
      videoAudioRef.current = null;
      return;
    }

    // PLACEHOLDER: Aquí irá el texto que proporciones
    const audioTextES = `
[PENDIENTE: Agregar texto en español de narración del video]
`;

    const audioTextEN = `
[PENDING: Add English text for video narration]
`;

    const text = language === 'es' ? audioTextES : audioTextEN;
    const utterance = new SpeechSynthesisUtterance(text);
    
    // Configuración de voz (misma que User Guide)
    utterance.lang = language === 'es' ? 'es-ES' : 'en-US';
    utterance.rate = 0.9;
    utterance.pitch = 1.0;
    utterance.volume = 1.0;

    // Seleccionar voz profesional femenina
    if (availableVoices.length > 0) {
      const selectedVoice = language === 'es'
        ? availableVoices.find(v => v.name === 'Microsoft Sabina - Spanish (Spain)') || availableVoices.find(v => v.name.includes('Sabina'))
        : availableVoices.find(v => v.name === 'Google UK English Female') || availableVoices.find(v => v.name.includes('Google UK English Female'));
      
      if (selectedVoice) {
        utterance.voice = selectedVoice;
        console.log('🔊 [Geoanálisis] Voz:', selectedVoice.name);
      }
    }

    // Eventos
    utterance.onstart = () => setIsPlayingVideoAudio(true);
    utterance.onend = () => {
      setIsPlayingVideoAudio(false);
      videoAudioRef.current = null;
    };
    utterance.onerror = () => {
      setIsPlayingVideoAudio(false);
      videoAudioRef.current = null;
    };

    videoAudioRef.current = utterance;
    window.speechSynthesis.speak(utterance);
  };

  // Funciones para arrastrar el logo
  const handleLogoMouseDown = (e: React.MouseEvent<HTMLDivElement>) => {
    setIsDraggingLogo(true);
    const rect = (e.target as HTMLElement).closest('div')?.getBoundingClientRect();
    if (rect) {
      setLogoDragOffset({
        x: e.clientX - rect.left,
        y: e.clientY - rect.top,
      });
    }
  };

  const handleLogoMouseMove = (e: MouseEvent) => {
    if (!isDraggingLogo) return;
    
    const containerRect = containerRef.current?.getBoundingClientRect();
    if (!containerRect) return;

    // Calcular nueva posición basada en el mouse
    const newLeft = e.clientX - containerRect.left - logoDragOffset.x;
    const newBottom = containerRect.height - (e.clientY - containerRect.top) - logoDragOffset.y;

    // Limitar dentro del contenedor
    const boundedLeft = Math.max(0, Math.min(newLeft, containerRect.width - 200));
    const boundedBottom = Math.max(0, Math.min(newBottom, containerRect.height - 50));

    setLogoPosition({ left: boundedLeft, bottom: boundedBottom });
  };

  const handleLogoMouseUp = () => {
    if (isDraggingLogo) {
      setIsDraggingLogo(false);
      // Guardar posición en localStorage
      localStorage.setItem('lydaris_logo_position', JSON.stringify(logoPosition));
    }
  };

  // Cargar posición del logo desde localStorage
  useEffect(() => {
    const savedPosition = localStorage.getItem('lydaris_logo_position');
    if (savedPosition) {
      try {
        const position = JSON.parse(savedPosition);
        setLogoPosition(position);
      } catch (e) {
        console.error('Error loading logo position:', e);
      }
    }
  }, []);

  // Guardar estado de expansión del modal ecosistémico
  useEffect(() => {
    localStorage.setItem('lydaris-ecosystem-expanded', JSON.stringify(isEcosystemExpanded));
  }, [isEcosystemExpanded]);

  // Event listeners para arrastre del logo
  useEffect(() => {
    if (isDraggingLogo) {
      document.addEventListener('mousemove', handleLogoMouseMove);
      document.addEventListener('mouseup', handleLogoMouseUp);
      return () => {
        document.removeEventListener('mousemove', handleLogoMouseMove);
        document.removeEventListener('mouseup', handleLogoMouseUp);
      };
    }
  }, [isDraggingLogo, logoDragOffset, logoPosition]);

  // ============================================
  // LISTENER PARA TECLA ESC - CERRAR VIDEO MODAL Y SALIR DE FULLSCREEN
  // ============================================
  useEffect(() => {
    const handleEscKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        // Prioridad 1: Cerrar video modal si está abierto
        if (showVideoModal) {
          setShowVideoModal(false);
          if (videoRef.current) {
            videoRef.current.pause();
          }
          // Detener audio si está reproduciéndose
          if (isPlayingVideoAudio) {
            window.speechSynthesis.cancel();
            setIsPlayingVideoAudio(false);
            videoAudioRef.current = null;
          }
        }
        // Prioridad 2: Salir de fullscreen si está activo y no hay video modal
        else if (isFullscreen) {
          setIsFullscreen(false);
        }
      }
    };

    document.addEventListener('keydown', handleEscKey);
    return () => {
      document.removeEventListener('keydown', handleEscKey);
    };
  }, [showVideoModal, isPlayingVideoAudio, isFullscreen]);

  // Limpiar animaciones cuando se desmonte el componente
  useEffect(() => {
    return () => {
      stopRotation();
    };
  }, []);

  return (
    <>
      <style>{`
        @keyframes pulse {
          0%, 100% {
            opacity: 1;
          }
          50% {
            opacity: 0.5;
          }
        }
        
        @keyframes fadeScale {
          from {
            opacity: 0;
          }
          to {
            opacity: 1;
          }
        }
        
        @keyframes fadeIn {
          from {
            opacity: 0;
          }
          to {
            opacity: 1;
          }
        }
        
        /* Ocultar SOLO el contenido expandido de atribución, pero mantener el logo y el botón "?" */
        .mapboxgl-ctrl-attrib-inner {
          display: none !important;
          visibility: hidden !important;
          opacity: 0 !important;
        }
        
        /* Mantener visible el logo nativo de Mapbox (lo haremos clickeable) */
        .mapboxgl-ctrl-logo {
          display: block !important;
          visibility: visible !important;
          opacity: 1 !important;
          pointer-events: auto !important;
        }
        
        /* Mantener visible los contenedores */
        .mapboxgl-ctrl-bottom-left,
        .mapboxgl-ctrl-bottom-right {
          pointer-events: auto !important;
        }
        
        /* El botón de atribución "?" se mantiene visible */
        .mapboxgl-ctrl-attrib-button,
        button[aria-label="Toggle attribution"] {
          display: block !important;
          visibility: visible !important;
          opacity: 1 !important;
          pointer-events: auto !important;
        }
      `}</style>
      
      <div className="dashboard-container" style={{ width: '100vw', height: '100vh', position: 'relative', background: '#0f1729', display: 'flex' }}>
        {/* PANEL IZQUIERDO - Índices y Subíndices */}
      {!isFullscreen && (
        <div style={{
          width: '320px',
          height: '100vh',
          background: 'linear-gradient(180deg, #0f1729 0%, #1a2540 100%)',
          borderRight: '1px solid #2a3b5c',
          overflowY: 'auto',
          paddingTop: '56px',
          paddingBottom: '8px',
          display: 'flex',
          flexDirection: 'column',
          position: 'relative',
        }}>
          {/* Botón Tarjeta Digital posicionado a la altura del header */}
          <button
            onClick={() => {
              if (!locatorMode) setIsDigitalAssetOpen(true);
            }}
            style={{
              position: 'absolute',
              top: '12px',
              left: '50%',
              transform: 'translateX(-50%)',
              width: '288px',
              background: 'rgba(6, 182, 212, 0.15)',
              border: '1px solid rgba(6, 182, 212, 0.4)',
              borderRadius: '6px',
              padding: '6px 12px',
              color: '#06b6d4',
              fontSize: '0.75rem',
              fontWeight: 600,
              letterSpacing: '0.3px',
              cursor: 'pointer',
              transition: 'all 0.2s ease',
              zIndex: 10,
              lineHeight: '1.3',
              whiteSpace: 'nowrap',
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.background = 'rgba(6, 182, 212, 0.25)';
              e.currentTarget.style.borderColor = 'rgba(6, 182, 212, 0.6)';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.background = 'rgba(6, 182, 212, 0.15)';
              e.currentTarget.style.borderColor = 'rgba(6, 182, 212, 0.4)';
            }}
          >
            <div style={{ fontWeight: 600, marginBottom: '2px' }}>{language === 'en' ? 'Digital Environmental Asset Card' : 'Tarjeta Digital Activo Ambiental'}</div>
            <div style={{ fontSize: '0.7rem', fontWeight: 500, opacity: 0.85 }}>ID: LDI-RC-01-25</div>
          </button>

          <div style={{
            padding: '16px',
            borderBottom: '1px solid #2a3b5c',
            display: 'flex',
            gap: '8px',
          }}>
            <button
              data-locator-id="LEFT_PANEL_LANGUAGE_BUTTON_EN"
              onClick={() => {
                if (!locatorMode) setLanguage('en');
              }}
              onMouseEnter={() => {
                if (locatorMode) setHoveredLocator('LEFT_PANEL_LANGUAGE_BUTTON_EN');
              }}
              onMouseLeave={() => {
                if (locatorMode) setHoveredLocator(null);
              }}
              style={{
                flex: 1,
                padding: '8px 12px',
                borderRadius: '8px',
                background: locatorMode && hoveredLocator === 'LEFT_PANEL_LANGUAGE_BUTTON_EN'
                  ? 'rgba(16, 185, 129, 0.3)'
                  : language === 'en' ? 'rgba(6, 182, 212, 0.2)' : 'transparent',
                border: locatorMode && hoveredLocator === 'LEFT_PANEL_LANGUAGE_BUTTON_EN'
                  ? '2px solid #10b981'
                  : language === 'en' ? '1px solid #06b6d4' : '1px solid #2a3b5c',
                color: '#fff',
                cursor: 'pointer',
                fontSize: '0.8rem',
              }}
            >
              EN
            </button>
            <button
              data-locator-id="LEFT_PANEL_LANGUAGE_BUTTON_ES"
              onClick={() => {
                if (!locatorMode) setLanguage('es');
              }}
              onMouseEnter={() => {
                if (locatorMode) setHoveredLocator('LEFT_PANEL_LANGUAGE_BUTTON_ES');
              }}
              onMouseLeave={() => {
                if (locatorMode) setHoveredLocator(null);
              }}
              style={{
                flex: 1,
                padding: '8px 12px',
                borderRadius: '8px',
                background: locatorMode && hoveredLocator === 'LEFT_PANEL_LANGUAGE_BUTTON_ES'
                  ? 'rgba(16, 185, 129, 0.3)'
                  : language === 'es' ? 'rgba(6, 182, 212, 0.2)' : 'transparent',
                border: locatorMode && hoveredLocator === 'LEFT_PANEL_LANGUAGE_BUTTON_ES'
                  ? '2px solid #10b981'
                  : language === 'es' ? '1px solid #06b6d4' : '1px solid #2a3b5c',
                color: '#fff',
                cursor: 'pointer',
                fontSize: '0.8rem',
              }}
            >
              ES
            </button>
          </div>

          <div style={{ 
            padding: '12px 16px',
          }}>
            <h3 style={{ 
              color: '#fff', 
              fontSize: '0.9rem', 
              margin: '0 0 14px 0',
              fontWeight: 600,
              letterSpacing: '0.3px',
              textAlign: 'center',
            }}>
              {language === 'en' ? 'Indicators' : 'Indicadores'}
            </h3>

            {indices.filter(index => !index.hidden).map((index) => (
              <div key={index.id} style={{ marginBottom: '10px' }}>
                <button
                  data-locator-id={`LEFT_PANEL_INDEX_BUTTON_${index.id.toUpperCase()}`}
                  onClick={() => {
                    if (!locatorMode) handleIndexClick(index.id);
                  }}
                  onMouseEnter={() => {
                    if (locatorMode) setHoveredLocator(`LEFT_PANEL_INDEX_BUTTON_${index.id.toUpperCase()}`);
                  }}
                  onMouseLeave={() => {
                    if (locatorMode) setHoveredLocator(null);
                  }}
                  style={{
                    width: '100%',
                    padding: '10px',
                    background: locatorMode && hoveredLocator === `LEFT_PANEL_INDEX_BUTTON_${index.id.toUpperCase()}`
                      ? 'rgba(16, 185, 129, 0.3)'
                      : activeIndex === index.id ? 'rgba(6, 182, 212, 0.15)' : 'rgba(26, 37, 64, 0.5)',
                    border: locatorMode && hoveredLocator === `LEFT_PANEL_INDEX_BUTTON_${index.id.toUpperCase()}`
                      ? '2px solid #10b981'
                      : '1px solid #2a3b5c',
                    borderRadius: '8px',
                    color: '#fff',
                    cursor: 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    fontSize: '0.85rem',
                  }}
                >
                  <span>{index.icon} {index.title}</span>
                  {activeIndex === index.id ? <ChevronDown size={16} /> : <ChevronRight size={16} />}
                </button>

                {activeIndex === index.id && (
                  <div style={{
                    marginTop: '6px',
                    paddingLeft: '12px',
                  }}>
                    {/* Resumen Técnico - Click directo abre modal */}
                    <button
                      data-locator-id={`LEFT_PANEL_TECHNICAL_SUMMARY_${index.id.toUpperCase()}`}
                      onClick={() => {
                        if (!locatorMode) {
                          setSelectedSubIndex(`${index.id}-technical-summary`);
                        }
                      }}
                      onMouseEnter={() => {
                        if (locatorMode) setHoveredLocator(`LEFT_PANEL_TECHNICAL_SUMMARY_${index.id.toUpperCase()}`);
                      }}
                      onMouseLeave={() => {
                        if (locatorMode) setHoveredLocator(null);
                      }}
                      style={{
                        width: '100%',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '8px',
                        padding: '8px 10px',
                        marginBottom: '8px',
                        background: locatorMode && hoveredLocator === `LEFT_PANEL_TECHNICAL_SUMMARY_${index.id.toUpperCase()}`
                          ? 'rgba(16, 185, 129, 0.3)'
                          : 'rgba(6, 182, 212, 0.08)',
                        border: locatorMode && hoveredLocator === `LEFT_PANEL_TECHNICAL_SUMMARY_${index.id.toUpperCase()}`
                          ? '2px solid #10b981'
                          : '1px solid rgba(6, 182, 212, 0.25)',
                        borderRadius: '6px',
                        color: '#06b6d4',
                        cursor: 'pointer',
                        fontSize: '0.75rem',
                        fontWeight: 600,
                        transition: 'all 0.2s',
                      }}
                    >
                      <FileText size={13} />
                      {language === 'en' ? 'Technical Summary' : 'Resumen Técnico'}
                    </button>
                    
                    {index.subLayers.map((sub) => (
                      sub.id.endsWith('-data') ? (
                        // Botón especial para Data panels
                        <button
                          key={sub.id}
                          data-locator-id={`LEFT_PANEL_DATA_${index.id.toUpperCase()}_${sub.id.toUpperCase()}`}
                          onClick={() => {
                            if (!locatorMode) toggleSubLayer(index.id, sub.id);
                          }}
                          onMouseEnter={() => {
                            if (locatorMode) setHoveredLocator(`LEFT_PANEL_DATA_${index.id.toUpperCase()}_${sub.id.toUpperCase()}`);
                          }}
                          onMouseLeave={() => {
                            if (locatorMode) setHoveredLocator(null);
                          }}
                          style={{
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            padding: '10px 12px',
                            marginBottom: '4px',
                            marginTop: '8px',
                            background: locatorMode && hoveredLocator === `LEFT_PANEL_DATA_${index.id.toUpperCase()}_${sub.id.toUpperCase()}`
                              ? 'rgba(16, 185, 129, 0.3)'
                              : 'rgba(6, 182, 212, 0.15)',
                            border: locatorMode && hoveredLocator === `LEFT_PANEL_DATA_${index.id.toUpperCase()}_${sub.id.toUpperCase()}`
                              ? '2px solid #10b981'
                              : '1px solid #06b6d4',
                            borderRadius: '6px',
                            color: '#06b6d4',
                            cursor: 'pointer',
                            fontSize: '0.8rem',
                            fontWeight: 600,
                            width: '100%',
                            transition: 'all 0.2s',
                          }}
                        >
                          {sub.label}
                        </button>
                      ) : (
                        // Subíndices clickeables con icono de lupa
                        <div
                          key={sub.id}
                          data-locator-id={`LEFT_PANEL_SUBINDEX_${index.id.toUpperCase()}_${sub.id.toUpperCase()}`}
                          style={{
                            display: 'flex',
                            alignItems: 'center',
                            padding: '8px 12px',
                            marginBottom: '4px',
                            background: locatorMode && hoveredLocator === `LEFT_PANEL_SUBINDEX_${index.id.toUpperCase()}_${sub.id.toUpperCase()}` 
                              ? 'rgba(16, 185, 129, 0.3)' 
                              : 'rgba(26, 37, 64, 0.3)',
                            borderRadius: '6px',
                            color: '#fff',
                            cursor: 'pointer',
                            fontSize: '0.75rem',
                            gap: '8px',
                            transition: 'all 0.2s',
                            border: locatorMode && hoveredLocator === `LEFT_PANEL_SUBINDEX_${index.id.toUpperCase()}_${sub.id.toUpperCase()}` 
                              ? '2px solid #10b981' 
                              : '2px solid transparent',
                          }}
                          onMouseEnter={(e) => {
                            if (locatorMode) {
                              setHoveredLocator(`LEFT_PANEL_SUBINDEX_${index.id.toUpperCase()}_${sub.id.toUpperCase()}`);
                            } else {
                              e.currentTarget.style.background = 'rgba(6, 182, 212, 0.15)';
                            }
                          }}
                          onMouseLeave={(e) => {
                            if (locatorMode) {
                              setHoveredLocator(null);
                            } else {
                              e.currentTarget.style.background = 'rgba(26, 37, 64, 0.3)';
                            }
                          }}
                          onClick={() => {
                            if (!locatorMode) {
                              toggleSubLayer(index.id, sub.id);
                            }
                          }}
                        >
                          <Info 
                            size={14}
                            style={{
                              color: '#06b6d4',
                              flexShrink: 0,
                            }}
                          />
                          <span style={{ flex: 1 }}>
                            {sub.label}
                          </span>
                        </div>
                      )
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* Botón Hallazgos y Propuesta - Separado en la parte inferior */}
          <div style={{ 
            margin: '8px 16px 12px 16px',
            paddingTop: '10px',
            borderTop: '1px solid #2a3b5c',
            marginTop: 'auto',
          }}>
            <button
              data-locator-id="LEFT_PANEL_EXECUTIVE_SUMMARY_BUTTON"
              onClick={() => {
                if (!locatorMode && onNavigate) onNavigate('hallazgos-propuesta');
              }}
              onMouseEnter={(e) => {
                if (locatorMode) {
                  setHoveredLocator('LEFT_PANEL_EXECUTIVE_SUMMARY_BUTTON');
                } else {
                  e.currentTarget.style.background = 'rgba(16, 185, 129, 0.2)';
                  e.currentTarget.style.borderColor = 'rgba(16, 185, 129, 0.7)';
                }
              }}
              onMouseLeave={(e) => {
                if (locatorMode) {
                  setHoveredLocator(null);
                } else {
                  e.currentTarget.style.background = 'rgba(16, 185, 129, 0.1)';
                  e.currentTarget.style.borderColor = 'rgba(16, 185, 129, 0.5)';
                }
              }}
              style={{
                width: '100%',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: '8px',
                padding: '10px 16px',
                background: locatorMode && hoveredLocator === 'LEFT_PANEL_EXECUTIVE_SUMMARY_BUTTON'
                  ? 'rgba(16, 185, 129, 0.3)'
                  : 'rgba(16, 185, 129, 0.1)',
                border: locatorMode && hoveredLocator === 'LEFT_PANEL_EXECUTIVE_SUMMARY_BUTTON'
                  ? '2px solid #10b981'
                  : '2px solid rgba(16, 185, 129, 0.5)',
                borderRadius: '8px',
                color: '#10b981',
                cursor: 'pointer',
                fontSize: '0.85rem',
                fontWeight: 600,
                transition: 'all 0.2s',
              }}
            >
              <FileText size={16} />
              <span>{language === 'en' ? 'Executive Summary' : 'Resumen Ejecutivo'}</span>
              <Download size={15} style={{ marginLeft: '2px', opacity: 0.8 }} />
            </button>
          </div>
        </div>
      )}

      {/* MAPA CENTRAL */}
      <div style={{ 
        flex: 1, 
        position: 'relative',
        display: 'flex', 
        flexDirection: 'column',
      }}>
        {!isFullscreen && (
          <div style={{
            height: '56px',
            zIndex: 1000,
            background: 'linear-gradient(to right, #0f1729, #1a2540, #0f1729)',
            borderBottom: '1px solid #2a3b5c',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            padding: '0 20px',
          }}>
            <h1 style={{
              color: '#06b6d4',
              fontSize: '1.15rem',
              fontWeight: 600,
              margin: 0,
              letterSpacing: '0.3px',
              textAlign: 'center',
              lineHeight: '1.4',
            }}>
              {t.ui.headerTitle}
              <br />
              <span style={{ color: '#8b9cb8', fontSize: '0.85rem' }}>{t.ui.precisionGeospatial}</span>
            </h1>
          </div>
        )}

        <div style={{ 
          flex: 1, 
          display: 'flex', 
          position: 'relative',
        }}>
          <div 
            ref={containerRef} 
            style={{ 
              ...(isFullscreen ? {
                position: 'fixed',
                top: 0,
                left: 0,
                right: 0,
                bottom: 0,
                width: '100vw',
                height: '100vh',
                zIndex: 9998,
              } : {
                flex: 1,
                position: 'relative',
              })
            }} 
          />

          {/* BLOQUEADOR del botón "?" de Mapbox - Overlay físico que tapa la esquina inferior derecha */}
          <div style={{
            position: isFullscreen ? 'fixed' : 'absolute',
            bottom: 0,
            right: 0,
            width: '100px',
            height: '40px',
            background: 'transparent',
            zIndex: isFullscreen ? 9999 : 1000,
            pointerEvents: 'none',
          }} />

          {/* Leyenda de colores para Hydro Index */}
          {activeIndex === 'hydro' && (
            <div style={{
              position: isFullscreen ? 'fixed' : 'absolute',
              bottom: '16px',
              right: '16px',
              zIndex: isFullscreen ? 9999 : 10,
              background: 'rgba(15, 23, 41, 0.75)',
              border: '1px solid rgba(255, 255, 255, 0.08)',
              borderRadius: '4px',
              padding: '8px 10px',
              backdropFilter: 'blur(12px)',
              userSelect: 'none',
              display: 'flex',
              alignItems: 'center',
              gap: '12px',
              fontSize: '0.65rem',
              color: 'rgba(255, 255, 255, 0.85)',
              letterSpacing: '0.01em',
              boxShadow: '0 2px 8px rgba(0, 0, 0, 0.15)',
            }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                <div style={{
                  width: '12px',
                  height: '12px',
                  background: '#1e7db5',
                  borderRadius: '2px',
                  flexShrink: 0,
                  boxShadow: '0 1px 2px rgba(0, 0, 0, 0.2)',
                }} />
                <span style={{ whiteSpace: 'nowrap', opacity: 0.9 }}>Permanent</span>
              </div>
              
              <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                <div style={{
                  width: '12px',
                  height: '12px',
                  background: '#7dd3fc',
                  borderRadius: '2px',
                  flexShrink: 0,
                  boxShadow: '0 1px 2px rgba(0, 0, 0, 0.2)',
                }} />
                <span style={{ whiteSpace: 'nowrap', opacity: 0.9 }}>Seasonal</span>
              </div>
              
              <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                <div style={{
                  width: '12px',
                  height: '12px',
                  background: '#4ade80',
                  borderRadius: '2px',
                  flexShrink: 0,
                  boxShadow: '0 1px 2px rgba(0, 0, 0, 0.2)',
                }} />
                <span style={{ whiteSpace: 'nowrap', opacity: 0.9 }}>Wetlands</span>
              </div>
            </div>
          )}

          {/* Botón de guía del usuario con audio - Debajo de la botonera principal */}
          <div style={{
            position: isFullscreen ? 'fixed' : 'absolute',
            top: '56px', // Justo debajo de la botonera (16px top + 32px altura + 8px gap)
            right: '16px', // Alineado con la botonera principal
            zIndex: isFullscreen ? 999999 : 10,
            display: 'flex',
            flexDirection: 'column',
            gap: '6px',
          }}>
            <button
              data-locator-id="MAP_CONTROL_AUDIO_INSTRUCTIONS"
              onClick={() => {
                if (!locatorMode) playInstructions();
              }}
              onMouseEnter={() => {
                if (locatorMode) setHoveredLocator('MAP_CONTROL_AUDIO_INSTRUCTIONS');
              }}
              onMouseLeave={() => {
                if (locatorMode) setHoveredLocator(null);
              }}
              style={{
                padding: '8px 14px',
                height: '32px',
                borderRadius: '6px',
                background: locatorMode && hoveredLocator === 'MAP_CONTROL_AUDIO_INSTRUCTIONS'
                  ? 'rgba(16, 185, 129, 0.3)'
                  : isPlayingAudio 
                  ? 'rgba(6, 182, 212, 0.2)' 
                  : 'rgba(15, 23, 41, 0.95)',
                border: locatorMode && hoveredLocator === 'MAP_CONTROL_AUDIO_INSTRUCTIONS'
                  ? '2px solid #10b981'
                  : isPlayingAudio ? '1px solid #06b6d4' : '1px solid #2a3b5c',
                color: isPlayingAudio ? '#06b6d4' : '#fff',
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: '8px',
                backdropFilter: 'blur(10px)',
                animation: isPlayingAudio ? 'pulse 1.5s ease-in-out infinite' : 'none',
                fontSize: '0.7rem',
                fontWeight: 500,
                letterSpacing: '0.3px',
              }}
            >
              <Volume2 size={14} />
              <span>{language === 'en' ? 'User Guide' : 'Guía del usuario'}</span>
            </button>

            {/* Botón de Water Layer - debajo del botón de audio (solo visible en Eco Structural) */}
            {activeIndex === 'esi' && (
              <button
                data-locator-id="MAP_CONTROL_WATER_LAYER"
                onClick={() => {
                  if (!locatorMode && mapRef.current) {
                    const newValue = !waterLayerVisible;
                    setWaterLayerVisible(newValue);
                    
                    // Aplicar inmediatamente al mapa
                    const map = mapRef.current;
                    try {
                      if (map.isStyleLoaded() && map.getLayer('water-class-polygons') && map.getLayer('water-class-outline')) {
                        if (newValue) {
                          map.setLayoutProperty('water-class-polygons', 'visibility', 'visible');
                          map.setLayoutProperty('water-class-outline', 'visibility', 'visible');
                          map.setPaintProperty('water-class-polygons', 'fill-opacity', 0.75);
                          map.setPaintProperty('water-class-outline', 'line-opacity', 0.5);
                          console.log('[Water Toggle] ✅ Activada');
                        } else {
                          map.setLayoutProperty('water-class-polygons', 'visibility', 'none');
                          map.setLayoutProperty('water-class-outline', 'visibility', 'none');
                          console.log('[Water Toggle] ❌ Desactivada');
                        }
                      }
                    } catch (err) {
                      console.error('[Water Toggle] Error:', err);
                    }
                  }
                }}
                onMouseEnter={() => {
                  if (locatorMode) setHoveredLocator('MAP_CONTROL_WATER_LAYER');
                }}
                onMouseLeave={() => {
                  if (locatorMode) setHoveredLocator(null);
                }}
                style={{
                  height: '26px',
                  display: 'flex',
                  alignItems: 'center',
                  borderRadius: '4px',
                  background: locatorMode && hoveredLocator === 'MAP_CONTROL_WATER_LAYER'
                    ? 'rgba(16, 185, 129, 0.3)'
                    : waterLayerVisible 
                    ? 'rgba(6, 182, 212, 0.15)' 
                    : 'rgba(15, 23, 41, 0.85)',
                  border: locatorMode && hoveredLocator === 'MAP_CONTROL_WATER_LAYER'
                    ? '2px solid #10b981'
                    : waterLayerVisible ? '1px solid #06b6d4' : '1px solid rgba(42, 59, 92, 0.8)',
                  color: waterLayerVisible ? '#06b6d4' : '#fff',
                  cursor: 'pointer',
                  backdropFilter: 'blur(10px)',
                }}
              >
                <div style={{ 
                  width: '26px', 
                  height: '26px',
                  display: 'flex', 
                  alignItems: 'center', 
                  justifyContent: 'center',
                  flexShrink: 0
                }}>
                  <Layers size={12} />
                </div>
                <span style={{ 
                  fontSize: '10px', 
                  fontWeight: '500',
                  paddingRight: '6px',
                  opacity: 0.9
                }}>
                  {language === 'en' ? 'Water' : 'Agua'}
                </span>
              </button>
            )}

            {/* Botón de EV Layer - debajo del botón de agua (solo visible en ESI) */}
            {activeIndex === 'esi' && (
              <button
                data-locator-id="MAP_CONTROL_EV_LAYER"
                onClick={() => {
                  if (!locatorMode && mapRef.current) {
                    const newValue = !evLayerVisible;
                    setEvLayerVisible(newValue);
                    
                    // Aplicar inmediatamente al mapa
                    const map = mapRef.current;
                    try {
                      if (map.isStyleLoaded() && map.getLayer('ev-layer')) {
                        if (newValue) {
                          map.setLayoutProperty('ev-layer', 'visibility', 'visible');
                          map.setPaintProperty('ev-layer', 'raster-opacity', 0.8);
                          console.log('[EV Toggle] ✅ Activada');
                        } else {
                          map.setLayoutProperty('ev-layer', 'visibility', 'none');
                          map.setPaintProperty('ev-layer', 'raster-opacity', 0);
                          console.log('[EV Toggle] ❌ Desactivada');
                        }
                      }
                    } catch (err) {
                      console.error('[EV Toggle] Error:', err);
                    }
                  }
                }}
                onMouseEnter={() => {
                  if (locatorMode) setHoveredLocator('MAP_CONTROL_EV_LAYER');
                }}
                onMouseLeave={() => {
                  if (locatorMode) setHoveredLocator(null);
                }}
                style={{
                  height: '26px',
                  display: 'flex',
                  alignItems: 'center',
                  borderRadius: '4px',
                  background: locatorMode && hoveredLocator === 'MAP_CONTROL_EV_LAYER'
                    ? 'rgba(16, 185, 129, 0.3)'
                    : evLayerVisible 
                    ? 'rgba(34, 197, 94, 0.15)' 
                    : 'rgba(15, 23, 41, 0.85)',
                  border: locatorMode && hoveredLocator === 'MAP_CONTROL_EV_LAYER'
                    ? '2px solid #10b981'
                    : evLayerVisible ? '1px solid #22c55e' : '1px solid rgba(42, 59, 92, 0.8)',
                  color: evLayerVisible ? '#22c55e' : '#fff',
                  cursor: 'pointer',
                  backdropFilter: 'blur(10px)',
                }}
              >
                <div style={{ 
                  width: '26px', 
                  height: '26px',
                  display: 'flex', 
                  alignItems: 'center', 
                  justifyContent: 'center',
                  flexShrink: 0
                }}>
                  <Layers size={12} />
                </div>
                <span style={{ 
                  fontSize: '10px', 
                  fontWeight: '500',
                  paddingRight: '6px',
                  opacity: 0.9
                }}>
                  {language === 'en' ? 'Vertical Structure' : 'Estructura Vertical'}
                </span>
              </button>
            )}

            {/* Botón de LSI Layer - debajo del botón de EV (solo visible en Risk Index) */}
            {activeIndex === 'risk' && (
              <button
                data-locator-id="MAP_CONTROL_LSI_LAYER"
                onClick={() => {
                  if (!locatorMode && mapRef.current) {
                    const newValue = !lsiLayerVisible;
                    setLsiLayerVisible(newValue);
                    
                    // Aplicar inmediatamente al mapa
                    const map = mapRef.current;
                    try {
                      if (map.isStyleLoaded() && map.getLayer('lsi-layer')) {
                        if (newValue) {
                          map.setLayoutProperty('lsi-layer', 'visibility', 'visible');
                          map.setPaintProperty('lsi-layer', 'raster-opacity', 0.8);
                          console.log('[LSI Toggle] ✅ Activada');
                        } else {
                          map.setLayoutProperty('lsi-layer', 'visibility', 'none');
                          map.setPaintProperty('lsi-layer', 'raster-opacity', 0);
                          console.log('[LSI Toggle] ❌ Desactivada');
                        }
                      }
                    } catch (err) {
                      console.error('[LSI Toggle] Error:', err);
                    }
                  }
                }}
                onMouseEnter={() => {
                  if (locatorMode) setHoveredLocator('MAP_CONTROL_LSI_LAYER');
                }}
                onMouseLeave={() => {
                  if (locatorMode) setHoveredLocator(null);
                }}
                style={{
                  height: '26px',
                  display: 'flex',
                  alignItems: 'center',
                  borderRadius: '4px',
                  background: locatorMode && hoveredLocator === 'MAP_CONTROL_LSI_LAYER'
                    ? 'rgba(16, 185, 129, 0.3)'
                    : lsiLayerVisible 
                    ? 'rgba(239, 68, 68, 0.15)' 
                    : 'rgba(15, 23, 41, 0.85)',
                  border: locatorMode && hoveredLocator === 'MAP_CONTROL_LSI_LAYER'
                    ? '2px solid #10b981'
                    : lsiLayerVisible ? '1px solid #ef4444' : '1px solid rgba(42, 59, 92, 0.8)',
                  color: lsiLayerVisible ? '#ef4444' : '#fff',
                  cursor: 'pointer',
                  backdropFilter: 'blur(10px)',
                }}
              >
                <div style={{ 
                  width: '26px', 
                  height: '26px',
                  display: 'flex', 
                  alignItems: 'center', 
                  justifyContent: 'center',
                  flexShrink: 0
                }}>
                  <Layers size={12} />
                </div>
                <span style={{ 
                  fontSize: '10px', 
                  fontWeight: '500',
                  paddingRight: '6px',
                  opacity: 0.9
                }}>
                  {language === 'en' ? 'Removal Risk' : 'Riesgo de Remoción'}
                </span>
              </button>
            )}
          </div>

          {/* Toolbar derecha - Controles principales */}
          <div style={{
            position: isFullscreen ? 'fixed' : 'absolute',
            top: '16px',
            right: '16px',
            zIndex: isFullscreen ? 999999 : 10,
            display: 'flex',
            gap: '6px',
          }}>
            <button
              data-locator-id="MAP_CONTROL_ZOOM_IN"
              onClick={() => {
                if (!locatorMode) mapRef.current?.zoomIn();
              }}
              onMouseEnter={() => {
                if (locatorMode) setHoveredLocator('MAP_CONTROL_ZOOM_IN');
              }}
              onMouseLeave={() => {
                if (locatorMode) setHoveredLocator(null);
              }}
              style={{
                width: '32px',
                height: '32px',
                borderRadius: '6px',
                background: locatorMode && hoveredLocator === 'MAP_CONTROL_ZOOM_IN'
                  ? 'rgba(16, 185, 129, 0.3)'
                  : 'rgba(15, 23, 41, 0.95)',
                border: locatorMode && hoveredLocator === 'MAP_CONTROL_ZOOM_IN'
                  ? '2px solid #10b981'
                  : '1px solid #2a3b5c',
                color: '#fff',
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                backdropFilter: 'blur(10px)',
              }}
            >
              <ZoomIn size={14} />
            </button>
            <button
              data-locator-id="MAP_CONTROL_ZOOM_OUT"
              onClick={() => {
                if (!locatorMode) mapRef.current?.zoomOut();
              }}
              onMouseEnter={() => {
                if (locatorMode) setHoveredLocator('MAP_CONTROL_ZOOM_OUT');
              }}
              onMouseLeave={() => {
                if (locatorMode) setHoveredLocator(null);
              }}
              style={{
                width: '32px',
                height: '32px',
                borderRadius: '6px',
                background: locatorMode && hoveredLocator === 'MAP_CONTROL_ZOOM_OUT'
                  ? 'rgba(16, 185, 129, 0.3)'
                  : 'rgba(15, 23, 41, 0.95)',
                border: locatorMode && hoveredLocator === 'MAP_CONTROL_ZOOM_OUT'
                  ? '2px solid #10b981'
                  : '1px solid #2a3b5c',
                color: '#fff',
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                backdropFilter: 'blur(10px)',
              }}
            >
              <ZoomOut size={14} />
            </button>
            <button
              data-locator-id="MAP_CONTROL_RESET_TO_AOI"
              onClick={() => {
                if (!locatorMode) resetCameraToAOI();
              }}
              onMouseEnter={() => {
                if (locatorMode) setHoveredLocator('MAP_CONTROL_RESET_TO_AOI');
              }}
              onMouseLeave={() => {
                if (locatorMode) setHoveredLocator(null);
              }}
              title={language === 'en' ? 'Reset to AOI' : 'Volver a AOI'}
              style={{
                width: '32px',
                height: '32px',
                borderRadius: '6px',
                background: locatorMode && hoveredLocator === 'MAP_CONTROL_RESET_TO_AOI'
                  ? 'rgba(16, 185, 129, 0.3)'
                  : 'rgba(15, 23, 41, 0.95)',
                border: locatorMode && hoveredLocator === 'MAP_CONTROL_RESET_TO_AOI'
                  ? '2px solid #10b981'
                  : '1px solid #2a3b5c',
                color: '#06b6d4',
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                backdropFilter: 'blur(10px)',
              }}
            >
              <LocateFixed size={14} />
            </button>
            <button
              onClick={() => setTerrainMode(terrainMode === '2D' ? '3D' : '2D')}
              style={{
                padding: '0 10px',
                height: '32px',
                borderRadius: '6px',
                background: 'rgba(15, 23, 41, 0.95)',
                border: '1px solid #2a3b5c',
                color: '#fff',
                cursor: 'pointer',
                fontSize: '0.7rem',
                backdropFilter: 'blur(10px)',
              }}
            >
              {terrainMode}
            </button>
            <button
              onClick={() => setViewMode(viewMode === 'SAT' ? 'TOPO' : 'SAT')}
              style={{
                padding: '0 10px',
                height: '32px',
                borderRadius: '6px',
                background: 'rgba(15, 23, 41, 0.95)',
                border: '1px solid #2a3b5c',
                color: '#fff',
                cursor: 'pointer',
                fontSize: '0.7rem',
                backdropFilter: 'blur(10px)',
              }}
            >
              {viewMode}
            </button>
            <button
              data-locator-id="MAP_CONTROL_360_ROTATION"
              onClick={() => {
                if (!locatorMode) toggleRotation();
              }}
              onMouseEnter={() => {
                if (locatorMode) setHoveredLocator('MAP_CONTROL_360_ROTATION');
              }}
              onMouseLeave={() => {
                if (locatorMode) setHoveredLocator(null);
              }}
              title={isRotating 
                ? (language === 'en' ? 'Stop Rotation' : 'Detener Rotación')
                : (language === 'en' ? 'Start 360° Rotation' : 'Iniciar Rotación 360°')
              }
              style={{
                width: '32px',
                height: '32px',
                borderRadius: '6px',
                background: locatorMode && hoveredLocator === 'MAP_CONTROL_360_ROTATION'
                  ? 'rgba(16, 185, 129, 0.3)'
                  : isRotating 
                  ? 'rgba(6, 182, 212, 0.2)' 
                  : 'rgba(15, 23, 41, 0.95)',
                border: locatorMode && hoveredLocator === 'MAP_CONTROL_360_ROTATION'
                  ? '2px solid #10b981'
                  : isRotating ? '1px solid #06b6d4' : '1px solid #2a3b5c',
                color: isRotating ? '#06b6d4' : '#fff',
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                backdropFilter: 'blur(10px)',
              }}
            >
              <div style={{ position: 'relative', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                {isRotating ? <Pause size={14} /> : <Repeat size={14} />}
                {isPlaying360Audio && (
                  <Volume2 
                    size={10} 
                    style={{
                      position: 'absolute',
                      top: '-4px',
                      right: '-4px',
                      color: '#10b981',
                      animation: 'pulse 1.5s ease-in-out infinite',
                    }} 
                  />
                )}
              </div>
            </button>
            {SHOW_CAMERA_RECORDING && (
              <button
                data-locator-id="MAP_CONTROL_VIDEO_RECORDING"
                onClick={() => {
                  if (!locatorMode) {
                    if (isRecording) {
                      stopRecording();
                    } else {
                      startRecording();
                    }
                  }
                }}
                onMouseEnter={() => {
                  if (locatorMode) setHoveredLocator('MAP_CONTROL_VIDEO_RECORDING');
                }}
                onMouseLeave={() => {
                  if (locatorMode) setHoveredLocator(null);
                }}
                title={isRecording 
                  ? (language === 'en' ? 'Stop Recording' : 'Detener Grabación')
                  : (language === 'en' ? 'Record Video' : 'Grabar Video')
                }
                style={{
                  width: '32px',
                  height: '32px',
                  borderRadius: '6px',
                  background: isRecording 
                    ? 'rgba(239, 68, 68, 0.2)' 
                    : 'rgba(15, 23, 41, 0.95)',
                  border: isRecording ? '1px solid #ef4444' : '1px solid #2a3b5c',
                  color: isRecording ? '#ef4444' : '#fff',
                  cursor: 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  backdropFilter: 'blur(10px)',
                }}
              >
                {isRecording ? <StopCircle size={14} /> : <Video size={14} />}
              </button>
            )}
            <button
              onClick={() => setIsFullscreen(!isFullscreen)}
              style={{
                width: '32px',
                height: '32px',
                borderRadius: '6px',
                background: 'rgba(15, 23, 41, 0.95)',
                border: '1px solid #2a3b5c',
                color: '#fff',
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                backdropFilter: 'blur(10px)',
              }}
            >
              {isFullscreen ? <Minimize size={14} /> : <Maximize size={14} />}
            </button>
            {isFullscreen && (
              <button
                onClick={() => setIsFullscreen(false)}
                title={language === 'en' ? 'Exit Fullscreen (ESC)' : 'Salir de Pantalla Completa (ESC)'}
                style={{
                  width: '32px',
                  height: '32px',
                  borderRadius: '6px',
                  background: 'rgba(15, 23, 41, 0.95)',
                  border: '1px solid #2a3b5c',
                  color: '#fff',
                  cursor: 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  backdropFilter: 'blur(10px)',
                }}
              >
                <X size={14} />
              </button>
            )}
          </div>



          {/* Logo Lydaris Data - Arrastrable */}
          <div 
            onMouseDown={handleLogoMouseDown}
            style={{
              position: isFullscreen ? 'fixed' : 'absolute',
              bottom: `${logoPosition.bottom}px`,
              left: `${logoPosition.left}px`,
              zIndex: isFullscreen ? 9999 : 10,
              display: 'none', // ⭐ OCULTO - No se muestra en el mapa principal
              alignItems: 'center',
              gap: '14px',
              background: 'rgba(15, 23, 41, 0.98)',
              backdropFilter: 'blur(16px)',
              padding: '12px 20px',
              borderRadius: '8px',
              border: isDraggingLogo ? '2px solid #06b6d4' : '1px solid rgba(255, 255, 255, 0.2)',
              cursor: isDraggingLogo ? 'grabbing' : 'grab',
              userSelect: 'none',
              transition: isDraggingLogo ? 'none' : 'border 0.2s ease',
              boxShadow: isDraggingLogo 
                ? '0 8px 24px rgba(6, 182, 212, 0.4), 0 0 0 1px rgba(6, 182, 212, 0.3)' 
                : '0 6px 20px rgba(0, 0, 0, 0.7), 0 0 0 1px rgba(255, 255, 255, 0.08)',
            }}>
            <div style={{
              display: 'flex',
              alignItems: 'center',
              gap: '3px',
              fontSize: '1.2rem',
              fontWeight: '700',
              color: '#fff',
              letterSpacing: '-0.5px',
              textShadow: '0 2px 4px rgba(0, 0, 0, 0.7)',
            }}>
              <span>L</span>
              <span style={{ fontSize: '1.5rem', lineHeight: '1' }}>.</span>
              <span>D</span>
              <span style={{ 
                marginLeft: '4px',
                fontSize: '1.4rem',
                fontWeight: '300',
                opacity: 0.6,
              }}>|</span>
            </div>
            <span style={{
              fontSize: '0.8rem',
              color: '#c0d0f0',
              letterSpacing: '0.4px',
              fontWeight: 400,
              textShadow: '0 2px 3px rgba(0, 0, 0, 0.7)',
            }}>
              Powered by{' '}
              <span style={{ color: '#06b6d4', fontWeight: 600 }}>
                Lydaris Data Intelligence
              </span>
            </span>
          </div>

          {/* Botones Satelital/Topográfico en modo fullscreen */}
          {isFullscreen && (
            <div style={{
              position: 'fixed',
              top: '16px',
              left: '16px',
              zIndex: 9999,
              display: 'flex',
              gap: '8px',
            }}>
              <button
                onClick={() => setViewMode('SAT')}
                style={{
                  padding: '8px 16px',
                  background: viewMode === 'SAT' ? 'rgba(6, 182, 212, 0.2)' : 'rgba(15, 23, 41, 0.95)',
                  border: viewMode === 'SAT' ? '1px solid #06b6d4' : '1px solid #2a3b5c',
                  borderRadius: '6px',
                  color: '#fff',
                  cursor: 'pointer',
                  fontSize: '0.75rem',
                  backdropFilter: 'blur(10px)',
                }}
              >
                {t.ui.satellite}
              </button>
              <button
                onClick={() => setViewMode('TOPO')}
                style={{
                  padding: '8px 16px',
                  background: viewMode === 'TOPO' ? 'rgba(6, 182, 212, 0.2)' : 'rgba(15, 23, 41, 0.95)',
                  border: viewMode === 'TOPO' ? '1px solid #06b6d4' : '1px solid #2a3b5c',
                  borderRadius: '6px',
                  color: '#fff',
                  cursor: 'pointer',
                  fontSize: '0.75rem',
                  backdropFilter: 'blur(10px)',
                }}
              >
                {t.ui.topographic}
              </button>
            </div>
          )}

          {/* Atribución de Mapbox - REQUERIDA POR LICENCIA */}
          <div style={{
            position: isFullscreen ? 'fixed' : 'absolute',
            bottom: '8px',
            right: '8px',
            zIndex: isFullscreen ? 9999 : 10,
            background: 'rgba(255, 255, 255, 0.9)',
            padding: '4px 10px',
            borderRadius: '3px',
            fontSize: '11px',
            display: 'flex',
            alignItems: 'center',
            gap: '4px',
            pointerEvents: 'none',
          }}>
            <svg width="16" height="16" viewBox="0 0 88 88" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M44 0C19.7 0 0 19.7 0 44s19.7 44 44 44 44-19.7 44-44S68.3 0 44 0zm27.1 44c0 2.8-.4 5.5-1.1 8.1l-13-4.4c.1-.6.1-1.2.1-1.8 0-4.4-3.6-8-8-8s-8 3.6-8 8c0 .6 0 1.2.1 1.8l-13 4.4c-.7-2.6-1.1-5.3-1.1-8.1 0-14.9 12.1-27 27-27s27 12.1 27 27zm-27-7.9c4.4 0 7.9 3.6 7.9 7.9 0 4.4-3.6 7.9-7.9 7.9-4.4 0-7.9-3.6-7.9-7.9 0-4.3 3.5-7.9 7.9-7.9z" fill="#000"/>
            </svg>
            <span style={{ color: '#000', fontWeight: 500 }}>Mapbox</span>
          </div>
        </div>
      </div>

      {/* PANEL DERECHO - Métricas + Diagnosis + AOI */}
      {!isFullscreen && (
        <div style={{
          width: '360px',
          height: '100vh',
          background: 'linear-gradient(180deg, #0f1729 0%, #1a2540 100%)',
          borderLeft: '1px solid #2a3b5c',
          overflowY: 'hidden',
          display: 'flex',
          flexDirection: 'column',
          paddingBottom: '16px',
        }}>
          {/* Botones Satelital/Topográfico */}
          <div style={{
            padding: '16px',
            borderBottom: '1px solid #2a3b5c',
            display: 'flex',
            gap: '8px',
            justifyContent: 'flex-end',
          }}>
            <button
              onClick={() => setViewMode('SAT')}
              style={{
                padding: '8px 16px',
                background: viewMode === 'SAT' ? 'rgba(6, 182, 212, 0.2)' : 'rgba(26, 37, 64, 0.7)',
                border: viewMode === 'SAT' ? '1px solid #06b6d4' : '1px solid #2a3b5c',
                borderRadius: '6px',
                color: '#fff',
                cursor: 'pointer',
                fontSize: '0.75rem',
              }}
            >
              {t.ui.satellite}
            </button>
            <button
              onClick={() => setViewMode('TOPO')}
              style={{
                padding: '8px 16px',
                background: viewMode === 'TOPO' ? 'rgba(6, 182, 212, 0.2)' : 'rgba(26, 37, 64, 0.7)',
                border: viewMode === 'TOPO' ? '1px solid #06b6d4' : '1px solid #2a3b5c',
                borderRadius: '6px',
                color: '#fff',
                cursor: 'pointer',
                fontSize: '0.75rem',
              }}
            >
              {t.ui.topographic}
            </button>
            {/* ⭐ BOTÓN IMAGES - OCULTO TEMPORALMENTE */}
            <button
              onClick={() => setShowVideoModal(true)}
              style={{
                display: 'none', // ⭐ OCULTO - Botón de Images desactivado temporalmente
                padding: '8px 16px',
                background: 'rgba(26, 37, 64, 0.7)',
                border: '1px solid #2a3b5c',
                borderRadius: '6px',
                color: '#fff',
                cursor: 'pointer',
                fontSize: '0.75rem',
                transition: 'all 0.2s ease',
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.background = 'rgba(6, 182, 212, 0.2)';
                e.currentTarget.style.borderColor = '#06b6d4';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.background = 'rgba(26, 37, 64, 0.7)';
                e.currentTarget.style.borderColor = '#2a3b5c';
              }}
            >
              {t.ui.images}
            </button>
          </div>

          <div style={{ flex: 1, padding: '16px' }}>
            {currentIndex && (
              <>
                {/* Header del Índice Seleccionado */}
                <div style={{
                  background: 'linear-gradient(135deg, rgba(6, 182, 212, 0.15), rgba(6, 182, 212, 0.05))',
                  border: '1px solid rgba(6, 182, 212, 0.3)',
                  borderRadius: '8px',
                  padding: '12px',
                  marginBottom: '12px',
                }}>
                  <div style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '8px',
                    marginBottom: '8px',
                  }}>
                    <div>
                      <h3 style={{
                        color: '#fff',
                        fontSize: '0.9rem',
                        margin: 0,
                        fontWeight: 600,
                      }}>
                        {currentIndex.title}
                      </h3>
                    </div>
                  </div>

                  {/* Valor Principal */}
                  <div style={{ 
                    display: 'flex', 
                    alignItems: 'baseline', 
                    gap: '10px',
                  }}>
                    <div style={{ 
                      color: '#06b6d4', 
                      fontSize: '2rem', 
                      fontWeight: 700,
                      lineHeight: 1,
                    }}>
                      {currentIndex.id === 'hydro' && INDICES_VALUES.hydro.valor}
                      {currentIndex.id === 'esi' && INDICES_VALUES.esi.valor}
                      {currentIndex.id === 'carbon' && INDICES_VALUES.carbon.valor}
                      {currentIndex.id === 'risk' && INDICES_VALUES.risk.valor}
                    </div>
                    <div>
                      <div style={{ color: '#fff', fontSize: '0.8rem', fontWeight: 600 }}>
                        {currentIndex.id === 'hydro' && INDICES_VALUES.hydro.categoriaCorta[language]}
                        {currentIndex.id === 'esi' && INDICES_VALUES.esi.categoriaCorta[language]}
                        {currentIndex.id === 'carbon' && INDICES_VALUES.carbon.categoriaCorta[language]}
                        {currentIndex.id === 'risk' && INDICES_VALUES.risk.categoriaCorta[language]}
                      </div>
                      <div style={{ color: '#8b9cb8', fontSize: '0.65rem' }}>
                        {currentIndex.id === 'hydro' && (language === 'en' ? `Confidence: ${INDICES_VALUES.hydro.confianzaTexto.en}` : `Confianza: ${INDICES_VALUES.hydro.confianzaTexto.es}`)}
                        {currentIndex.id === 'esi' && (language === 'en' ? `Confidence: ${INDICES_VALUES.esi.confianzaTexto.en}` : `Confianza: ${INDICES_VALUES.esi.confianzaTexto.es}`)}
                        {currentIndex.id === 'carbon' && (language === 'en' ? `Confidence: ${INDICES_VALUES.carbon.confianzaTexto.en}` : `Confianza: ${INDICES_VALUES.carbon.confianzaTexto.es}`)}
                        {currentIndex.id === 'risk' && (language === 'en' ? `Confidence: ${INDICES_VALUES.risk.confianzaTexto.en}` : `Confianza: ${INDICES_VALUES.risk.confianzaTexto.es}`)}
                      </div>
                    </div>
                  </div>

                  {/* Datos de Conectividad Hídrica (solo para Hydro Index) */}
                  {currentIndex.id === 'hydro' && (
                    <div style={{
                      marginTop: '12px',
                      paddingTop: '12px',
                      borderTop: '1px solid rgba(6, 182, 212, 0.2)',
                    }}>
                      <div style={{
                        color: '#8b9cb8',
                        fontSize: '0.7rem',
                        fontWeight: 600,
                        marginBottom: '8px',
                        letterSpacing: '0.5px',
                      }}>
                        {language === 'en' ? 'HYDROLOGICAL CONNECTIVITY (2023 - 2025)' : 'CONECTIVIDAD HÍDRICA (2023 - 2025)'}
                      </div>
                      <div style={{
                        display: 'grid',
                        gridTemplateColumns: '1fr 1fr',
                        gap: '8px',
                        fontSize: '0.7rem',
                        marginBottom: '12px',
                      }}>
                        <div style={{ display: 'flex', flexDirection: 'column', gap: '2px' }}>
                          <span style={{ color: '#8b9cb8' }}>
                            {language === 'en' ? 'Water' : 'Agua'}
                          </span>
                          <span style={{ color: '#06b6d4', fontWeight: 600 }}>42.7%</span>
                          <span style={{ color: '#5fa66c', fontSize: '0.65rem' }}>392.5 ha</span>
                        </div>
                        <div style={{ display: 'flex', flexDirection: 'column', gap: '2px' }}>
                          <span style={{ color: '#8b9cb8' }}>
                            {language === 'en' ? 'Wetlands' : 'Humedales'}
                          </span>
                          <span style={{ color: '#06b6d4', fontWeight: 600 }}>10.1%</span>
                          <span style={{ color: '#5fa66c', fontSize: '0.65rem' }}>92.7 ha</span>
                        </div>
                      </div>
                      
                      {/* Persistencia Mensual */}
                      <div style={{
                        background: 'rgba(6, 182, 212, 0.08)',
                        border: '1px solid rgba(6, 182, 212, 0.2)',
                        borderRadius: '6px',
                        padding: '8px',
                        marginTop: '8px',
                      }}>
                        <div style={{
                          color: '#06b6d4',
                          fontSize: '0.68rem',
                          fontWeight: 600,
                          marginBottom: '6px',
                          letterSpacing: '0.5px',
                        }}>
                          {language === 'en' ? 'MONTHLY PERSISTENCE (2024 - 2025)' : 'PERSISTENCIA MENSUAL (2024 - 2025)'}
                        </div>
                        <div style={{ display: 'flex', flexDirection: 'column', gap: '4px', fontSize: '0.68rem' }}>
                          <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                            <span style={{ color: '#8b9cb8' }}>
                              {language === 'en' ? 'Permanent Water' : 'Agua Permanente'}
                            </span>
                            <span style={{ color: '#c5d4e8', fontWeight: 600 }}>10%</span>
                          </div>
                          <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                            <span style={{ color: '#8b9cb8' }}>
                              {language === 'en' ? 'Seasonal Water' : 'Agua Estacional'}
                            </span>
                            <span style={{ color: '#c5d4e8', fontWeight: 600 }}>12.3%</span>
                          </div>
                          <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                            <span style={{ color: '#8b9cb8' }}>
                              {language === 'en' ? 'Wetlands' : 'Humedales'}
                            </span>
                            <span style={{ color: '#c5d4e8', fontWeight: 600 }}>6%</span>
                          </div>
                          <div style={{
                            borderTop: '1px solid rgba(6, 182, 212, 0.2)',
                            marginTop: '4px',
                            paddingTop: '4px',
                            display: 'flex',
                            justifyContent: 'space-between',
                          }}>
                            <span style={{ color: '#06b6d4', fontWeight: 600 }}>
                              {language === 'en' ? 'Total' : 'Total'}
                            </span>
                            <span style={{ color: '#06b6d4', fontWeight: 700 }}>
                              {language === 'en' ? '28.3% of AOI' : '28.3% del AOI'}
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                </div>

                {/* AOI Context & Metadata */}
                <div style={{
                  background: 'linear-gradient(135deg, rgba(6, 182, 212, 0.08), rgba(6, 182, 212, 0.02))',
                  border: '1.5px solid rgba(6, 182, 212, 0.35)',
                  borderRadius: '10px',
                  marginBottom: '20px',
                  boxShadow: '0 2px 8px rgba(6, 182, 212, 0.1)',
                }}>
                  <div
                    style={{
                      width: '100%',
                      padding: '8px 12px',
                      background: 'transparent',
                      border: 'none',
                      color: '#fff',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      fontSize: '0.7rem',
                      fontWeight: 600,
                      letterSpacing: '0.3px',
                    }}
                  >
                    <span style={{ color: '#06b6d4' }}>
                      {language === 'en' ? '🌍 AOI Context' : '🌍 Contexto del AOI'}
                    </span>
                  </div>
                  
                  {/* Datos básicos */}
                  <div style={{
                    padding: '0 12px 10px 12px',
                  }}>
                    <div style={{ 
                      fontSize: '0.65rem',
                      marginBottom: '6px',
                    }}>
                      <div style={{ color: '#fff', fontWeight: 400, marginBottom: '8px', fontSize: '0.7rem' }}>
                        Reserva Cochamó
                      </div>
                      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px' }}>
                        <div>
                          <div style={{ color: '#10b981', fontWeight: 600, marginBottom: '2px' }}>
                            {language === 'en' ? 'Surface' : 'Superficie'}
                          </div>
                          <div style={{ color: '#fff', fontWeight: 400 }}>917 ha</div>
                        </div>
                        <div>
                          <div style={{ color: '#10b981', fontWeight: 600, marginBottom: '2px' }}>
                            {language === 'en' ? 'Perimeter' : 'Perímetro'}
                          </div>
                          <div style={{ color: '#fff', fontWeight: 400 }}>15.7 km</div>
                        </div>
                        <div style={{ gridColumn: '1 / -1' }}>
                          <div style={{ color: '#10b981', fontWeight: 600, marginBottom: '2px' }}>
                            {language === 'en' ? 'Ecoregion' : 'Ecorregión'}
                          </div>
                          <div style={{ color: '#fff', fontWeight: 400 }}>
                            {language === 'en' ? 'Valdivian Temperate Forests' : 'Bosques Templados Valdivianos'}
                          </div>
                        </div>
                        <div style={{ gridColumn: '1 / -1' }}>
                          <div style={{ color: '#10b981', fontWeight: 600, marginBottom: '2px' }}>
                            {language === 'en' ? 'Biome' : 'Bioma'}
                          </div>
                          <div style={{ color: '#fff', fontWeight: 400 }}>
                            {language === 'en' ? 'Temperate Rainforest' : 'Bosque Templado Lluvioso'}
                          </div>
                        </div>
                        <div style={{ gridColumn: '1 / -1' }}>
                          <div style={{ color: '#10b981', fontWeight: 600, marginBottom: '2px' }}>
                            {language === 'en' ? 'Climate Classification' : 'Clasificación Climática'}
                          </div>
                          <div style={{ color: '#fff', fontWeight: 400 }}>
                            {language === 'en' ? 'Cfb – Oceanic Temperate Climate' : 'Cfb – Clima templado oceánico'}
                          </div>
                        </div>
                        <div>
                          <div style={{ color: '#10b981', fontWeight: 600, marginBottom: '2px' }}>
                            {language === 'en' ? 'Analysis Period' : 'Período Análisis'}
                          </div>
                          <div style={{ color: '#fff', fontWeight: 400 }}>2020-2025</div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </>
            )}

            {/* Cuando NO hay índice seleccionado - Vista expandida del AOI */}
            {!currentIndex && (
              <div style={{ 
                display: 'flex', 
                flexDirection: 'column', 
                gap: '16px',
              }}>
                {/* Header del AOI destacado */}
                <div style={{
                  background: 'linear-gradient(135deg, rgba(16, 185, 129, 0.15), rgba(16, 185, 129, 0.05))',
                  border: '1px solid rgba(16, 185, 129, 0.3)',
                  borderRadius: '10px',
                  padding: '16px',
                  position: 'relative',
                }}>
                  <div style={{ 
                    color: '#10b981', 
                    fontSize: '0.7rem', 
                    marginBottom: '10px', 
                    fontWeight: 600,
                    letterSpacing: '0.5px',
                  }}>
                    {language === 'en' ? 'AOI Context' : 'Contexto del AOI'}
                  </div>
                  <h2 style={{ 
                    color: '#fff', 
                    fontSize: '1.3rem', 
                    marginBottom: '12px',
                    fontWeight: 700,
                    margin: '0 0 12px 0',
                  }}>
                    Reserva Cochamó
                  </h2>
                  <div style={{ 
                    fontSize: '0.68rem',
                  }}>
                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px' }}>
                      <div>
                        <div style={{ color: '#10b981', fontWeight: 600, marginBottom: '2px' }}>
                          {language === 'en' ? 'Surface' : 'Superficie'}
                        </div>
                        <div style={{ color: '#fff', fontWeight: 400 }}>917 ha</div>
                      </div>
                      <div>
                        <div style={{ color: '#10b981', fontWeight: 600, marginBottom: '2px' }}>
                          {language === 'en' ? 'Perimeter' : 'Perímetro'}
                        </div>
                        <div style={{ color: '#fff', fontWeight: 400 }}>15.7 km</div>
                      </div>
                      <div style={{ gridColumn: '1 / -1' }}>
                        <div style={{ color: '#10b981', fontWeight: 600, marginBottom: '2px' }}>
                          {language === 'en' ? 'Ecoregion' : 'Ecorregión'}
                        </div>
                        <div style={{ color: '#fff', fontWeight: 400 }}>
                          {language === 'en' ? 'Valdivian Temperate Forests' : 'Bosques Templados Valdivianos'}
                        </div>
                      </div>
                      <div style={{ gridColumn: '1 / -1' }}>
                        <div style={{ color: '#10b981', fontWeight: 600, marginBottom: '2px' }}>
                          {language === 'en' ? 'Biome' : 'Bioma'}
                        </div>
                        <div style={{ color: '#fff', fontWeight: 400 }}>
                          {language === 'en' ? 'Temperate Rainforest' : 'Bosque Templado Lluvioso'}
                        </div>
                      </div>
                      <div style={{ gridColumn: '1 / -1' }}>
                        <div style={{ color: '#10b981', fontWeight: 600, marginBottom: '2px' }}>
                          {language === 'en' ? 'Climate Classification' : 'Clasificación Climática'}
                        </div>
                        <div style={{ color: '#fff', fontWeight: 400 }}>
                          {language === 'en' ? 'Cfb – Oceanic Temperate Climate' : 'Cfb – Clima templado oceánico'}
                        </div>
                      </div>
                      <div>
                        <div style={{ color: '#10b981', fontWeight: 600, marginBottom: '2px' }}>
                          {language === 'en' ? 'Analysis Period' : 'Período Análisis'}
                        </div>
                        <div style={{ color: '#fff', fontWeight: 400 }}>2020-2025</div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* 🎬 TOUR 360° - Bloque Fijo */}
                <div style={{
                  background: 'linear-gradient(135deg, rgba(6, 182, 212, 0.15) 0%, rgba(15, 23, 41, 0.5) 100%)',
                  border: '1px solid rgba(6, 182, 212, 0.4)',
                  borderRadius: '8px',
                  boxShadow: '0 2px 8px rgba(6, 182, 212, 0.15)',
                  overflow: 'hidden',
                }}>
                  <button
                    onClick={() => setIsTour360Open(true)}
                    style={{
                      width: '100%',
                      padding: '12px 14px',
                      background: 'transparent',
                      border: 'none',
                      color: '#fff',
                      cursor: 'pointer',
                      display: 'flex',
                      flexDirection: 'column',
                      alignItems: 'center',
                      justifyContent: 'center',
                      gap: '6px',
                      transition: 'all 0.3s ease',
                    }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.background = 'rgba(6, 182, 212, 0.1)';
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.background = 'transparent';
                    }}
                  >
                    <div style={{
                      position: 'relative',
                      width: '80px',
                      height: '80px',
                      borderRadius: '50%',
                      background: 'linear-gradient(135deg, rgba(6, 182, 212, 0.3) 0%, rgba(59, 130, 246, 0.4) 100%)',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      boxShadow: '0 8px 24px rgba(6, 182, 212, 0.3)',
                    }}>
                      {/* Arco parcial 270° - minimalista */}
                      <svg 
                        style={{
                          position: 'absolute',
                          top: '-12px',
                          left: '-12px',
                          width: '104px',
                          height: '104px',
                          pointerEvents: 'none',
                        }}
                        viewBox="0 0 104 104"
                      >
                        <path
                          d="M 52 6 A 46 46 0 1 1 6 52"
                          fill="none"
                          stroke="#06b6d4"
                          strokeWidth="2"
                          strokeLinecap="round"
                          opacity="0.6"
                        />
                      </svg>
                      
                      <Satellite size={40} color="#fff" />
                    </div>
                    <div style={{
                      textAlign: 'center',
                    }}>
                      <div style={{
                        fontSize: '1.1rem',
                        fontWeight: 700,
                        color: '#06b6d4',
                        marginBottom: '6px',
                        letterSpacing: '0.5px',
                      }}>
                        {language === 'en' ? 'Interactive Geo-Analysis' : 'Geoanálisis Interactivo'}
                      </div>
                      <div style={{
                        fontSize: '0.82rem',
                        color: '#e2e8f0',
                        lineHeight: '1.5',
                        maxWidth: '220px',
                      }}>
                        {language === 'en' 
                          ? 'Immersive geo-environmental assessment' 
                          : 'Evaluación geoambiental inmersiva'}
                      </div>
                    </div>
                  </button>
                </div>

                {/* Digital Environmental Assets - Casilla separada */}
                <div style={{
                  background: 'linear-gradient(135deg, rgba(6, 182, 212, 0.08), rgba(6, 182, 212, 0.02))',
                  border: '1.5px solid rgba(6, 182, 212, 0.35)',
                  borderRadius: '10px',
                  marginBottom: '20px',
                  boxShadow: '0 2px 8px rgba(6, 182, 212, 0.1)',
                }}>
                  <button
                    onClick={() => {
                      if (onNavigate) {
                        onNavigate('digital-assets');
                      }
                    }}
                    style={{
                      width: '100%',
                      padding: '14px 16px',
                      background: 'transparent',
                      border: 'none',
                      display: 'flex',
                      alignItems: 'center',
                      gap: '12px',
                      cursor: 'pointer',
                      transition: 'all 0.2s ease',
                    }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.background = 'rgba(6, 182, 212, 0.05)';
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.background = 'transparent';
                    }}
                  >
                    <div style={{
                      width: '36px',
                      height: '36px',
                      borderRadius: '6px',
                      background: 'rgba(6, 182, 212, 0.15)',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      flexShrink: 0,
                    }}>
                      <Layers size={18} color="#06b6d4" />
                    </div>
                    <div style={{
                      flex: 1,
                      textAlign: 'left',
                    }}>
                      <div style={{
                        fontSize: '0.9rem',
                        fontWeight: 600,
                        color: '#e9eef9',
                        marginBottom: '2px',
                      }}>
                        {language === 'en' ? 'Digital Environmental Assets' : 'Activos Ambientales Digitales'}
                      </div>
                      <div style={{
                        fontSize: '0.72rem',
                        color: '#8a94a8',
                        lineHeight: '1.3',
                      }}>
                        {language === 'en' 
                          ? 'Innovation in Territorial Analytics' 
                          : 'Innovación en Analítica Territorial'}
                      </div>
                    </div>
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      </div>

      {/* Modal centrado para subíndices */}
      {selectedSubIndex && (
        <>
          {/* Backdrop transparente solo para detectar clicks */}
          <div
            onClick={() => {
              setSelectedSubIndex(null);
              setModalPosition({ x: 0, y: 0 });
            }}
            style={{
              position: 'fixed',
              top: 0,
              left: 0,
              right: 0,
              bottom: 0,
              background: 'transparent',
              zIndex: 9998,
            }}
          />
          
          {/* Panel deslizante desde la derecha */}
          <div
            key={`${selectedSubIndex}-${language}`}
            ref={diagnosisModalRef}
            onClick={(e) => e.stopPropagation()}
            style={{
              position: 'fixed',
              top: modalPosition.y === 0 ? '50%' : `${modalPosition.y}px`,
              left: modalPosition.x === 0 ? '50%' : `${modalPosition.x}px`,
              transform: modalPosition.x === 0 && modalPosition.y === 0 ? 'translate(-50%, -50%)' : 'none',
              width: '800px',
              maxWidth: '90vw',
              maxHeight: '85vh',
              background: 'linear-gradient(180deg, #1a2540 0%, #0f1729 100%)',
              boxShadow: '0 20px 60px rgba(0, 0, 0, 0.6)',
              zIndex: 9999,
              display: 'flex',
              flexDirection: 'column',
              animation: 'fadeScale 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
              border: '1px solid rgba(6, 182, 212, 0.3)',
              borderRadius: '12px',
              cursor: isDragging ? 'grabbing' : 'default',
            }}
          >
            {/* Header del Panel */}
            <div 
              onMouseDown={handleModalMouseDown}
              style={{
                padding: '24px 28px',
                borderBottom: '1px solid rgba(6, 182, 212, 0.25)',
                cursor: isDragging ? 'grabbing' : 'grab',
              display: 'flex',
              alignItems: 'flex-start',
              justifyContent: 'space-between',
              gap: '16px',
              flexShrink: 0,
              background: 'rgba(6, 182, 212, 0.05)',
            }}>
              <div style={{ flex: 1, display: 'flex', alignItems: 'flex-start', gap: '8px' }}>
                <GripVertical 
                  size={20} 
                  style={{ 
                    color: 'rgba(6, 182, 212, 0.5)', 
                    marginTop: '2px',
                    flexShrink: 0,
                    cursor: isDragging ? 'grabbing' : 'grab',
                  }} 
                />
                <div style={{ flex: 1 }}>
                  <h2 style={{
                    color: '#06b6d4',
                    fontSize: '1.25rem',
                    fontWeight: 700,
                    margin: 0,
                    marginBottom: '6px',
                    lineHeight: 1.3,
                  }}>
                    {language === 'en' ? 'Diagnosis & Conservation Insights' : 'Diagnóstico y Perspectivas de Conservación'}
                  </h2>
                <div style={{
                  color: '#8b9cb8',
                  fontSize: '0.9rem',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '6px',
                  flexWrap: 'wrap',
                }}>
                  {selectedSubIndex && (
                    <>
                      <span style={{ color: '#06b6d4', fontWeight: 600 }}>
                        {indices
                          .flatMap(idx => idx.subLayers || [])
                          .find(sub => sub.id === selectedSubIndex)?.label || selectedSubIndex.toUpperCase()}
                      </span>
                      <span style={{ color: 'rgba(6, 182, 212, 0.4)' }}>•</span>
                    </>
                  )}
                  <span>{currentIndex ? currentIndex.title : 'Ecosystem Index'}</span>
                  <span style={{ color: 'rgba(6, 182, 212, 0.4)' }}>•</span>
                  <span>Reserva Cochamó</span>
                </div>
                </div>
              </div>
              
              <button
                onClick={() => {
                  setSelectedSubIndex(null);
                  setModalPosition({ x: 0, y: 0 });
                }}
                style={{
                  width: '38px',
                  height: '38px',
                  borderRadius: '8px',
                  background: 'rgba(6, 182, 212, 0.12)',
                  border: '1px solid rgba(6, 182, 212, 0.35)',
                  color: '#06b6d4',
                  cursor: 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  flexShrink: 0,
                  transition: 'all 0.2s',
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.background = 'rgba(6, 182, 212, 0.25)';
                  e.currentTarget.style.transform = 'scale(1.05)';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.background = 'rgba(6, 182, 212, 0.12)';
                  e.currentTarget.style.transform = 'scale(1)';
                }}
              >
                <X size={20} />
              </button>
            </div>
            
            {/* Contenido Scrollable */}
            <div style={{
              flex: 1,
              overflowY: 'auto',
              padding: '28px 32px',
            }}>
              <div style={{
                color: '#d5e3f7',
                fontSize: '1.05rem',
                lineHeight: '1.85',
                fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif',
                letterSpacing: '0.01em',
                textAlign: 'justify',
              }}>
                {getDiagnosisContent().split('\n').map((line, idx) => {
                  // Detectar títulos principales (subtítulos cyan) - case-insensitive
                  const lineLower = line.toLowerCase();
                  const isTitle = lineLower.includes('datos, ventanas temporales y robustez del sistema') || 
                                  lineLower.includes('hallazgos globales') ||
                                  lineLower.includes('data, temporal windows and system robustness') ||
                                  lineLower.includes('global findings');
                  
                  if (isTitle) {
                    return (
                      <h3 key={idx} style={{
                        color: '#06b6d4',
                        fontSize: '1.25rem',
                        fontWeight: 700,
                        marginTop: idx === 0 ? 0 : '28px',
                        marginBottom: '16px',
                        lineHeight: 1.3,
                      }}>
                        {line}
                      </h3>
                    );
                  }
                  
                  if (line.trim() === '') {
                    return <div key={idx} style={{ height: '12px' }} />;
                  }
                  
                  return <p key={idx} style={{ margin: '0 0 12px 0' }}>{line}</p>;
                })}
              </div>
            </div>
          </div>
        </>
      )}
      {/* MODO LOCALIZADOR - Banner y funcionalidad */}
      {locatorMode && (
        <>
          {/* Banner superior */}
          <div style={{
            position: isFullscreen ? 'fixed' : 'absolute',
            top: isFullscreen ? '20px' : '80px',
            left: '50%',
            transform: 'translateX(-50%)',
            zIndex: 99999,
            background: 'linear-gradient(135deg, rgba(16, 185, 129, 0.95), rgba(6, 182, 212, 0.95))',
            padding: '16px 32px',
            borderRadius: '12px',
            border: '2px solid #10b981',
            boxShadow: '0 8px 32px rgba(16, 185, 129, 0.5)',
            color: '#fff',
            fontWeight: 700,
            fontSize: '16px',
            textAlign: 'center',
            backdropFilter: 'blur(10px)',
            animation: 'pulse 2s infinite',
            display: 'flex',
            alignItems: 'center',
            gap: '16px',
            pointerEvents: 'auto',
          }}>
            <span>🎯 LOCATOR MODE - {lockedLocator ? 'LOCKED ✓' : 'HOVER & CLICK TO LOCK'}</span>
            <button
              onClick={() => {
                setLocatorMode(false);
                setHoveredLocator(null);
                setLockedLocator(null);
              }}
              style={{
                background: '#fff',
                color: '#10b981',
                border: 'none',
                borderRadius: '6px',
                padding: '6px 12px',
                cursor: 'pointer',
                fontWeight: 700,
                fontSize: '14px',
              }}
            >
              ✕ EXIT
            </button>
          </div>

          {/* Tooltip flotante - SE FIJA CON CLICK */}
          {(hoveredLocator || lockedLocator) && (
            <div 
              onClick={() => {
                if (!lockedLocator && hoveredLocator) {
                  setLockedLocator(hoveredLocator);
                }
              }}
              style={{
                position: 'fixed',
                top: '50%',
                left: '50%',
                transform: 'translate(-50%, -50%)',
                zIndex: 999999,
                background: 'rgba(15, 23, 41, 0.98)',
                padding: '24px 32px',
                borderRadius: '12px',
                border: lockedLocator ? '3px solid #f59e0b' : '3px solid #10b981',
                boxShadow: lockedLocator ? '0 12px 48px rgba(245, 158, 11, 0.6)' : '0 12px 48px rgba(16, 185, 129, 0.6)',
                color: '#fff',
                minWidth: '400px',
                cursor: lockedLocator ? 'default' : 'pointer',
              }}
            >
              <div style={{
                fontSize: '14px',
                color: lockedLocator ? '#f59e0b' : '#10b981',
                marginBottom: '12px',
                fontWeight: 600,
              }}>
                {lockedLocator ? '🔒 LOCKED ID:' : '🎯 HOVER (CLICK TO LOCK):'}
              </div>
              
              <input 
                type="text"
                readOnly
                value={lockedLocator || hoveredLocator || ''}
                onClick={(e) => {
                  e.currentTarget.select();
                  e.stopPropagation();
                }}
                style={{
                  width: '100%',
                  fontSize: '16px',
                  fontWeight: 700,
                  color: '#fff',
                  fontFamily: 'monospace',
                  background: lockedLocator ? 'rgba(245, 158, 11, 0.15)' : 'rgba(16, 185, 129, 0.15)',
                  padding: '14px',
                  borderRadius: '6px',
                  border: lockedLocator ? '2px solid #f59e0b' : '2px solid #10b981',
                  marginBottom: '12px',
                  cursor: 'text',
                }}
              />
              
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  const id = lockedLocator || hoveredLocator || '';
                  
                  // Método fallback para copiar al portapapeles
                  const textarea = document.createElement('textarea');
                  textarea.value = id;
                  textarea.style.position = 'fixed';
                  textarea.style.opacity = '0';
                  document.body.appendChild(textarea);
                  textarea.select();
                  try {
                    document.execCommand('copy');
                    alert('✅ ID copied: ' + id);
                  } catch (err) {
                    alert('❌ Error copying: ' + id);
                  }
                  document.body.removeChild(textarea);
                }}
                style={{
                  width: '100%',
                  background: lockedLocator ? '#f59e0b' : '#10b981',
                  color: '#fff',
                  border: 'none',
                  padding: '12px',
                  borderRadius: '6px',
                  cursor: 'pointer',
                  fontWeight: 700,
                  fontSize: '14px',
                  marginBottom: lockedLocator ? '8px' : '0',
                }}
              >
                📋 COPY ID
              </button>
              
              {lockedLocator && (
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    setLockedLocator(null);
                  }}
                  style={{
                    width: '100%',
                    background: '#ef4444',
                    color: '#fff',
                    border: 'none',
                    padding: '10px',
                    borderRadius: '6px',
                    cursor: 'pointer',
                    fontWeight: 600,
                    fontSize: '13px',
                  }}
                >
                  🔓 UNLOCK (Continue identifying)
                </button>
              )}
            </div>
          )}

          {/* Overlay semitransparente - NO BLOQUEA EVENTOS */}
          <div 
            style={{
              position: 'fixed',
              top: 0,
              left: 0,
              right: 0,
              bottom: 0,
              zIndex: -1,
              background: 'rgba(0, 0, 0, 0.3)',
              pointerEvents: 'none',
            }}
          />
        </>
      )}

      {/* ============================================ */}
      {/* 🎬 MODAL DE VIDEO */}
      {/* ============================================ */}
      {/* ⭐ OCULTO TEMPORALMENTE - Modal de video desactivado */}
      {false && showVideoModal && (
        <>
          {/* Backdrop */}
          <div
            onClick={() => {
              setShowVideoModal(false);
              if (videoRef.current) {
                videoRef.current.pause();
              }
              // Detener audio si está reproduciéndose
              if (isPlayingVideoAudio) {
                window.speechSynthesis.cancel();
                setIsPlayingVideoAudio(false);
                videoAudioRef.current = null;
              }
            }}
            style={{
              position: 'fixed',
              top: 0,
              left: 0,
              right: 0,
              bottom: 0,
              background: 'rgba(0, 0, 0, 0.85)',
              zIndex: 10000,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              backdropFilter: 'blur(8px)',
            }}
          >
            {/* Modal Container */}
            <div
              onClick={(e) => e.stopPropagation()}
              style={{
                position: 'relative',
                width: '95%',
                maxWidth: '1600px',
                height: '95vh',
                background: 'linear-gradient(180deg, #0f1729 0%, #1a2540 100%)',
                borderRadius: '16px',
                border: '2px solid rgba(6, 182, 212, 0.3)',
                boxShadow: '0 8px 32px rgba(0, 0, 0, 0.5), 0 0 80px rgba(6, 182, 212, 0.15)',
                overflow: 'hidden',
                animation: 'slideUp 0.3s ease-out',
                display: 'flex',
                flexDirection: 'column',
              }}
            >
              {/* Header */}
              <div style={{
                padding: '12px 16px',
                background: 'rgba(6, 182, 212, 0.1)',
                borderBottom: '1px solid rgba(6, 182, 212, 0.3)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                flexShrink: 0,
              }}>
                <div style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '12px',
                }}>
                  <Video size={24} color="#06b6d4" />
                  <h2 style={{
                    margin: 0,
                    fontSize: '1.25rem',
                    fontWeight: 600,
                    color: '#fff',
                    letterSpacing: '0.3px',
                  }}>
                    {t.ui.videoGallery}
                  </h2>
                </div>
                
                <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
                  {/* Botón de audio narrado */}
                  <button
                    onClick={playVideoAudio}
                    style={{
                      padding: '8px 16px',
                      background: isPlayingVideoAudio ? 'rgba(6, 182, 212, 0.4)' : 'rgba(6, 182, 212, 0.2)',
                      border: '1px solid #06b6d4',
                      borderRadius: '8px',
                      color: '#fff',
                      cursor: 'pointer',
                      fontSize: '0.85rem',
                      fontWeight: 500,
                      display: 'flex',
                      alignItems: 'center',
                      gap: '8px',
                      transition: 'all 0.2s ease',
                    }}
                    onMouseEnter={(e) => {
                      if (!isPlayingVideoAudio) {
                        e.currentTarget.style.background = 'rgba(6, 182, 212, 0.35)';
                      }
                    }}
                    onMouseLeave={(e) => {
                      if (!isPlayingVideoAudio) {
                        e.currentTarget.style.background = 'rgba(6, 182, 212, 0.2)';
                      }
                    }}
                  >
                    {isPlayingVideoAudio ? (
                      <>
                        <StopCircle size={18} />
                        {t.ui.stopAudio}
                      </>
                    ) : (
                      <>
                        <Volume2 size={18} />
                        {t.ui.playAudio}
                      </>
                    )}
                  </button>

                  {/* Botón cerrar con tooltip */}
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <button
                          onClick={() => {
                            setShowVideoModal(false);
                            if (videoRef.current) {
                              videoRef.current.pause();
                            }
                            if (isPlayingVideoAudio) {
                              window.speechSynthesis.cancel();
                              setIsPlayingVideoAudio(false);
                              videoAudioRef.current = null;
                            }
                          }}
                          style={{
                            width: '44px',
                            height: '44px',
                            background: 'rgba(6, 182, 212, 0.25)',
                            border: '2px solid #06b6d4',
                            borderRadius: '10px',
                            color: '#06b6d4',
                            cursor: 'pointer',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            transition: 'all 0.2s ease',
                            boxShadow: '0 2px 8px rgba(6, 182, 212, 0.3)',
                          }}
                          onMouseEnter={(e) => {
                            e.currentTarget.style.background = 'rgba(6, 182, 212, 0.45)';
                            e.currentTarget.style.transform = 'scale(1.05)';
                          }}
                          onMouseLeave={(e) => {
                            e.currentTarget.style.background = 'rgba(6, 182, 212, 0.25)';
                            e.currentTarget.style.transform = 'scale(1)';
                          }}
                        >
                          <X size={22} strokeWidth={2.5} />
                        </button>
                      </TooltipTrigger>
                      <TooltipContent side="bottom">
                        <p style={{ margin: 0, fontSize: '0.85rem' }}>
                          {t.ui.closeVideo} <span style={{ opacity: 0.6, fontSize: '0.75rem' }}>(ESC)</span>
                        </p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                </div>
              </div>

              {/* Video Container */}
              <div style={{
                padding: '16px',
                display: 'flex',
                flexDirection: 'column',
                gap: '12px',
                flex: 1,
                minHeight: 0,
              }}>
                {/* PLACEHOLDER: Aquí va el video */}
                <div style={{
                  width: '100%',
                  height: '100%',
                  background: 'linear-gradient(135deg, rgba(6, 182, 212, 0.1), rgba(6, 182, 212, 0.05))',
                  borderRadius: '12px',
                  border: '2px dashed rgba(6, 182, 212, 0.3)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  position: 'relative',
                  overflow: 'hidden',
                  padding: '16px 32px',
                }}>
                  {/* Video element - Cloudinary optimizado */}
                  <video
                    ref={videoRef}
                    controls
                    id="lydaris-video-player"
                    style={{
                      width: '100%',
                      height: '100%',
                      borderRadius: '8px',
                      objectFit: 'cover',
                    }}
                  >
                    <source src="https://res.cloudinary.com/dccdjpskq/video/upload/q_auto,f_auto/Cochamó_Reserve_Mp4_1_q9ri25.mp4" type="video/mp4" />
                    {language === 'es' 
                      ? 'Tu navegador no soporta reproducción de video.'
                      : 'Your browser does not support video playback.'}
                  </video>
                </div>
              </div>
            </div>
          </div>

          {/* CSS Animation */}
          <style>{`
            @keyframes slideUp {
              from {
                opacity: 0;
                transform: translateY(30px);
              }
              to {
                opacity: 1;
                transform: translateY(0);
              }
            }

            /* Estilos para video en modo fullscreen - ajuste preciso sin márgenes */
            #lydaris-video-player:fullscreen {
              position: fixed !important;
              top: 0 !important;
              left: 0 !important;
              width: 100vw !important;
              height: 100vh !important;
              max-width: none !important;
              max-height: none !important;
              object-fit: cover !important;
              background: #000 !important;
              padding: 0 !important;
              margin: 0 !important;
              border-radius: 0 !important;
            }
            
            #lydaris-video-player:-webkit-full-screen {
              position: fixed !important;
              top: 0 !important;
              left: 0 !important;
              width: 100vw !important;
              height: 100vh !important;
              max-width: none !important;
              max-height: none !important;
              object-fit: cover !important;
              background: #000 !important;
              padding: 0 !important;
              margin: 0 !important;
              border-radius: 0 !important;
            }
            
            #lydaris-video-player:-moz-full-screen {
              position: fixed !important;
              top: 0 !important;
              left: 0 !important;
              width: 100vw !important;
              height: 100vh !important;
              max-width: none !important;
              max-height: none !important;
              object-fit: cover !important;
              background: #000 !important;
              padding: 0 !important;
              margin: 0 !important;
              border-radius: 0 !important;
            }
            
            #lydaris-video-player:-ms-fullscreen {
              position: fixed !important;
              top: 0 !important;
              left: 0 !important;
              width: 100vw !important;
              height: 100vh !important;
              max-width: none !important;
              max-height: none !important;
              object-fit: cover !important;
              background: #000 !important;
              padding: 0 !important;
              margin: 0 !important;
              border-radius: 0 !important;
            }
          `}</style>
        </>
      )}

      {/* Tarjeta Digital del Activo */}
      <DigitalAssetCard
        isOpen={isDigitalAssetOpen}
        onClose={() => {
          setIsDigitalAssetOpen(false);
          setKeepDataPanelMenuOpen(false);
          if (onAssetCardClosed) onAssetCardClosed();
        }}
        language={language}
        keepDataPanelMenuOpen={keepDataPanelMenuOpen}
        onNavigateToSummary={() => {
          // Navegar a Executive Summary desde Tarjeta Digital
          if (onNavigate) {
            onNavigate('hallazgos-propuesta', 'digital-asset-card');
          }
        }}
        onNavigateToMaps={() => {
          // Cerrar el modal - el usuario ya está en el mapa con capas
          // El dashboard principal es el mapa interactivo
        }}
        onOpenLayersPanel={() => {
          // Abrir el panel de capas interactivas
          setIsLayersPanelOpen(true);
        }}
        onNavigateToDataPanels={(index) => {
          // Navegar al data panel correspondiente desde Tarjeta Digital
          setKeepDataPanelMenuOpen(true); // Mantener el menú abierto cuando regrese
          if (onNavigate) {
            if (index === 'hydro') {
              onNavigate('hydro-consolidado', 'digital-asset-card');
            } else if (index === 'esi') {
              onNavigate('esi-data-consolidado', 'digital-asset-card');
            } else if (index === 'risk') {
              onNavigate('risk-data-consolidado', 'digital-asset-card');
            }
          }
        }}
        onNavigateToTour={() => {
          // Abrir Tour 360°
          setIsTour360Open(true);
        }}
      />

      {/* Mapa Independiente de la Tarjeta Digital */}
      <DigitalAssetMapViewer
        isOpen={isLayersPanelOpen}
        activeLayer={null}
        layerOpacity={assetMapOpacity}
        enabledLayers={assetMapLayers}
      />

      {/* Panel de Control de Capas Interactivas (controla el mapa independiente) */}
      <LayersControlPanel
        isOpen={isLayersPanelOpen}
        onClose={() => setIsLayersPanelOpen(false)}
        language={language}
        onLayerToggle={(layerId, enabled) => {
          // Actualizar estado de capas del mapa independiente
          setAssetMapLayers(prev => ({
            ...prev,
            [layerId]: enabled,
          }));
        }}
        onOpacityChange={(layerId, opacity) => {
          // Actualizar opacidad de capas del mapa independiente
          setAssetMapOpacity(prev => ({
            ...prev,
            [layerId]: opacity,
          }));
        }}
        onBackToCard={() => {
          // Cerrar panel y reabrir tarjeta digital
          setIsLayersPanelOpen(false);
          setIsDigitalAssetOpen(true);
        }}
      />

      {/* Tour 360° Modal */}
      <Tour360
        isOpen={isTour360Open}
        onClose={() => setIsTour360Open(false)}
        language={language}
      />

    </>
  );
}