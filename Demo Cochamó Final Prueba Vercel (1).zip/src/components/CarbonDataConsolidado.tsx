import { ArrowRight, ArrowLeft, ChevronDown, ChevronUp, Info } from 'lucide-react';
import React, { useState } from 'react';
import { useIsMobile } from '../hooks/useIsMobile';

const carbonData = {
  location: 'Reserva Cochamó - Patagonia Chilena',
  ecorregion: 'Ecorregión Bosque Templado Valdiviano',
  area: {
    aoi: 919.0,
    aguaTotal: 392.5,
    humedales: 92.7
  },
  indice: {
    valor: 68.3,
    categoria: 'Almacenamiento carbono alto funcional',
    codigo: 'Carbon Index™',
    tendencia: 'Estable'
  },
  subindices: [
    {
      codigo: 'AGB',
      nombre: 'Above Ground Biomass',
      valor: 73.1,
      color: '#3b82f6'
    },
    {
      codigo: 'SOC',
      nombre: 'Soil Organic Carbon',
      valor: 67.6,
      color: '#06b6d4'
    },
    {
      codigo: 'VEG',
      nombre: 'Vegetation Index',
      valor: 42.7,
      color: '#8b5cf6'
    },
    {
      codigo: 'STR',
      nombre: 'Structural Integrity',
      valor: 23.9,
      color: '#eab308'
    }
  ],
  capitalHidrico: {
    aguaModelo: { porcentaje: 42.7, hectareas: 392.5 },
    humedalesModelo: { porcentaje: 10.1, hectareas: 92.7 }
  },
  persistencia: {
    aguaPermanente: { porcentaje: 10.0, hectareas: 92.3 },
    aguaEstacional: { porcentaje: 12.3, hectareas: 113.5 },
    humedalesSinAgua: { porcentaje: 6.0, hectareas: 54.9 }
  },
  confianza: {
    valor: 0.64,
    fuentesActivas: 6,
    soportePromedioAgua: 0.39
  },
  riesgos: {
    flood: 37.7,
    sed: 40.6,
    dry: 44.5,
    total: 40.9
  }
};

interface CarbonDataConsolidadoProps {
  onNavigate: (view: 'portada' | 'carbon-interpretation' | 'hydro-mapbox-test') => void;
  hideNavigationButton?: boolean;
  inStack?: boolean;
}

export default function CarbonDataConsolidado({ onNavigate, hideNavigationButton = false, inStack = false }: CarbonDataConsolidadoProps) {
  const isMobile = useIsMobile();
  const [isDataOpen, setIsDataOpen] = useState(false);
  const [showTooltip, setShowTooltip] = useState(false);

  return (
    <div className="relative w-full bg-[#0f1220]" style={{ minHeight: inStack ? 'fit-content' : '100vh', overflow: inStack ? 'visible' : 'auto' }}>
      
      <button
        onClick={() => onNavigate('hydro-mapbox-test')}
        className="fixed bg-[#171f33] border border-[#243253] rounded-lg hover:bg-[#1a2540] transition-all group flex items-center gap-2"
        style={isMobile ? {
          top: '16px',
          left: '16px',
          padding: '10px 16px',
          boxShadow: '0 4px 16px rgba(0, 0, 0, 0.4)',
          zIndex: 999
        } : {
          top: 'clamp(14px, 2vh, 32px)',
          left: 'clamp(14px, 2vw, 32px)',
          padding: 'clamp(8px, 1vh, 12px)',
          boxShadow: '0 4px 12px rgba(0, 0, 0, 0.2)',
          zIndex: 50
        }}
        title="Volver a TEST MAPBOX"
      >
        <ArrowLeft 
          className="text-[#7eb88a] group-hover:text-[#8fc497] transition-colors" 
          style={{ 
            width: isMobile ? '20px' : 'clamp(18px, 1.5vw, 22px)', 
            height: isMobile ? '20px' : 'clamp(18px, 1.5vw, 22px)' 
          }} 
        />
        {isMobile && (
          <span className="text-[#7eb88a] group-hover:text-[#8fc497] transition-colors" style={{ fontSize: '14px', fontWeight: 500 }}>
            TEST MAPBOX
          </span>
        )}
      </button>

      <div 
        className="relative z-10 w-full"
        style={isMobile ? {
          display: 'flex',
          flexDirection: 'column',
          gap: 'clamp(12px, 1.5vh, 18px)',
          padding: 'clamp(12px, 1.5vh, 18px)',
          paddingTop: inStack ? '12px' : '70px',
          paddingBottom: 'clamp(120px, 18vh, 200px)',
          maxWidth: '100%',
          minHeight: inStack ? 'auto' : '100vh',
          boxSizing: 'border-box'
        } : {
          display: 'grid',
          gridTemplateColumns: 'clamp(220px, 22vw, 320px) 1fr',
          gap: 'clamp(12px, 1.4vw, 18px)',
          padding: 'clamp(10px, 1.2vh, 14px)',
          paddingLeft: 'clamp(30px, 4vw, 60px)',
          paddingRight: 'clamp(30px, 4vw, 60px)',
          paddingTop: 'clamp(70px, 9vh, 90px)',
          paddingBottom: 'clamp(120px, 18vh, 200px)',
          maxWidth: '1500px',
          margin: '0 auto',
          minHeight: 'auto',
          boxSizing: 'border-box'
        }}
      >
        
        {/* Panel izquierdo: Metadata */}
        <div 
          className="flex flex-col rounded-xl border border-[#222a42]"
          style={{ 
            background: 'linear-gradient(180deg, #141a2a, #1b2235)',
            padding: 'clamp(14px, 1.8vh, 20px)',
            gap: 'clamp(10px, 1.2vh, 14px)',
            height: '100%'
          }}
        >
          
          <div>
            <p 
              className="text-[#e9eef9] m-0"
              style={{ 
                fontSize: 'clamp(0.85rem, 0.8rem + 0.3vw, 1rem)',
                fontWeight: 600,
                marginBottom: 'clamp(2px, 0.3vh, 4px)',
                textTransform: 'uppercase',
                letterSpacing: '1px'
              }}
            >
              Metadata
            </p>
            <p 
              className="text-[#e9eef9] m-0"
              style={{ 
                fontSize: 'clamp(1rem, 0.95rem + 0.4vw, 1.2rem)',
                fontWeight: 700,
                marginBottom: 'clamp(4px, 0.6vh, 8px)'
              }}
              translate="no"
            >
              CARBON INDEX™
            </p>
          </div>

          <div>
            <h2 
              className="text-[#e9eef9] m-0"
              style={{ 
                fontSize: 'clamp(1.1rem, 1.4vw, 1.45rem)',
                letterSpacing: '0.2px'
              }}
            >
              {carbonData.location}
            </h2>
            <p 
              className="text-[#a8b0c6] m-0"
              style={{ fontSize: 'clamp(0.9rem, 1.1vw, 1.15rem)' }}
            >
              {carbonData.ecorregion}
            </p>
          </div>

          <div 
            className="rounded-xl border border-[#222a42]"
            style={{ 
              background: 'linear-gradient(180deg, #141a2a, #1b2235)',
              padding: 'clamp(14px, 1.8vh, 20px)'
            }}
          >
            <div className="flex flex-col items-center gap-[1.2vh]">
              <div
                className="group"
                style={{
                  width: 'clamp(100px, 11vw, 120px)',
                  height: 'clamp(100px, 11vw, 120px)',
                  borderRadius: '50%',
                  background: `conic-gradient(#7eb88a ${carbonData.indice.valor}%, #253053 0), radial-gradient(farthest-side, #0f1220 65%, transparent 66%)`,
                  display: 'grid',
                  placeItems: 'center',
                  border: '1px solid #202845',
                  boxShadow: 'inset 0 0 18px rgba(95, 166, 108, 0.15)',
                  position: 'relative',
                  userSelect: 'none'
                }}
              >
                <div style={{ fontSize: '24px', fontWeight: 700, color: '#e9eef9', userSelect: 'none' }}>
                  {carbonData.indice.valor}
                </div>
              </div>

              {/* Label del índice */}
              <p 
                className="text-[#7eb88a] m-0 text-center"
                style={{ 
                  fontSize: 'clamp(0.85rem, 1vw, 1.1rem)',
                  fontWeight: 600,
                  letterSpacing: '0.3px',
                  marginBottom: 'clamp(14px, 1.8vh, 18px)'
                }}
              >
                Índice de Carbono Integrado
              </p>

              <div className="w-full flex flex-col" style={{ gap: 'clamp(12px, 1.5vh, 16px)' }}>
                <div className="grid grid-cols-2" style={{ gap: 'clamp(6px, 0.8vw, 10px)' }}>
                  <div>
                    <div 
                      className="text-[#c4cfe0] mb-[0.4vh]"
                      style={{ fontSize: 'clamp(0.9rem, 1.05vw, 1.15rem)' }}
                    >
                      AOI
                    </div>
                    <div 
                      className="text-[#5fa66c]"
                      style={{ fontSize: 'clamp(1.2rem, 1.5vw, 1.65rem)', fontWeight: 600 }}
                    >
                      {carbonData.area.aoi.toFixed(0)} ha
                    </div>
                  </div>
                  <div>
                    <div 
                      className="text-[#c4cfe0] mb-[0.4vh]"
                      style={{ fontSize: 'clamp(0.9rem, 1.05vw, 1.15rem)' }}
                    >
                      Zona Húmeda
                    </div>
                    <div 
                      className="text-[#5fa66c]"
                      style={{ fontSize: 'clamp(1.2rem, 1.5vw, 1.65rem)', fontWeight: 600 }}
                    >
                      {(carbonData.area.aguaTotal + carbonData.area.humedales).toFixed(1)} ha
                    </div>
                  </div>
                </div>
                <div className="text-center rounded-lg border border-[#5fa66c]/30" style={{ 
                  padding: 'clamp(6px, 0.8vh, 10px)',
                  background: 'rgba(95, 166, 108, 0.1)'
                }}>
                  <div 
                    className="text-[#e9eef9]"
                    style={{ fontSize: 'clamp(0.85rem, 1vw, 1.1rem)', letterSpacing: '0.5px' }}
                  >
                    {carbonData.indice.categoria}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {isMobile && (
          <button
            onClick={() => setIsDataOpen(!isDataOpen)}
            className="flex items-center justify-between w-full rounded-xl border border-[#7eb88a]/40 hover:border-[#7eb88a]/70 transition-all"
            style={{
              background: 'linear-gradient(to right, rgba(126, 184, 138, 0.15), rgba(143, 196, 151, 0.1))',
              padding: '16px 20px'
            }}
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-[#7eb88a]/30 flex items-center justify-center">
                <span className="text-2xl">🌲</span>
              </div>
              <div className="text-left">
                <p className="text-[#e9eef9] m-0" style={{ fontSize: '1.05rem', fontWeight: 600 }}>
                  Ver Datos Completos
                </p>
                <p className="text-[#a8b0c6] m-0" style={{ fontSize: '0.85rem' }}>
                  {isDataOpen ? 'Ocultar tabla' : 'Capital hídrico, subíndices y riesgos'}
                </p>
              </div>
            </div>
            {isDataOpen ? (
              <ChevronUp className="text-[#7eb88a]" style={{ width: '24px', height: '24px' }} />
            ) : (
              <ChevronDown className="text-[#7eb88a]" style={{ width: '24px', height: '24px' }} />
            )}
          </button>
        )}

        {/* Panel derecho: Datos Carbon */}
        <div 
          className="rounded-xl border border-[#222a42] shadow-2xl"
          style={{
            background: 'linear-gradient(180deg, #141a2a, #1b2235)',
            padding: 'clamp(4px, 0.5vh, 5px)',
            ...(isMobile ? {
              width: '100%',
              maxHeight: isDataOpen ? '3000px' : '0px',
              overflow: 'hidden',
              opacity: isDataOpen ? 1 : 0,
              transition: 'max-height 0.5s ease, opacity 0.5s ease'
            } : {
              height: 'fit-content'
            })
          }}
        >
          <div style={{ display: 'grid', gridTemplateColumns: '1fr', gap: 'clamp(2px, 0.25vh, 3px)' }}>              
            {/* Cabecera Carbon Index */}
            <div 
              className="rounded-lg border border-[#5fa66c]/40"
              style={{ 
                padding: 'clamp(3px, 0.35vh, 4px)',
                background: 'linear-gradient(to right, rgba(95, 166, 108, 0.15), rgba(52, 211, 153, 0.1))',
                gridColumn: 'auto'
              }}
            >
              <div className="flex items-center justify-between" style={{ gap: 'clamp(6px, 0.7vw, 8px)' }}>
                <p 
                  className="text-[#e9eef9] m-0"
                  style={{ 
                    fontSize: 'clamp(0.85rem, 1vw, 1.1rem)',
                    whiteSpace: 'nowrap'
                  }}
                >
                  Carbon Index
                </p>
                <div className="text-center flex-1">
                  <p 
                    className="text-[#5fa66c] m-0"
                    style={{ 
                      fontSize: 'clamp(1.5rem, 2vw, 2.2rem)',
                      fontWeight: 700,
                      lineHeight: '1'
                    }}
                  >
                    {carbonData.indice.valor}
                  </p>
                </div>
                <p 
                  className="text-[#c4cfe0] m-0"
                  style={{ 
                    fontSize: 'clamp(0.8rem, 0.95vw, 1.05rem)',
                    fontWeight: 600,
                    lineHeight: '1.05',
                    textAlign: 'right',
                    whiteSpace: 'nowrap'
                  }}
                >
                  {carbonData.indice.categoria}
                </p>
              </div>
            </div>

            {/* Subíndices */}
            <div 
              className="rounded-lg border border-[#222a42]"
              style={{ 
                padding: 'clamp(3px, 0.35vh, 4px)',
                background: 'rgba(15, 18, 32, 0.4)'
              }}
            >
              <p 
                className="text-[#a8b0c6] m-0"
                style={{ 
                  fontSize: 'clamp(0.8rem, 0.95vw, 1.05rem)',
                  fontWeight: 600,
                  marginBottom: 'clamp(2px, 0.25vh, 3px)',
                  letterSpacing: '0.2px',
                  lineHeight: '1'
                }}
              >
                Subíndices (0-100)
              </p>
              
              <div style={{ display: 'grid', gridTemplateColumns: '1fr', gap: 'clamp(2px, 0.25vh, 3px)' }}>
                {carbonData.subindices.map((sub, idx) => (
                  <div 
                    key={idx}
                    className="rounded border border-[#222a42]/50"
                    style={{ 
                      padding: 'clamp(2px, 0.25vh, 3px) clamp(3px, 0.35vh, 4px)',
                      background: 'rgba(15, 18, 32, 0.3)',
                      display: 'flex',
                      justifyContent: 'space-between',
                      alignItems: 'center',
                      gap: 'clamp(4px, 0.5vw, 6px)'
                    }}
                  >
                    <span 
                      className="text-[#a8b0c6]"
                      style={{ 
                        fontSize: 'clamp(0.7rem, 0.85vw, 0.9rem)',
                        lineHeight: '1'
                      }}
                    >
                      {sub.codigo} – {sub.nombre}
                    </span>
                    <span 
                      className="text-[#e9eef9]"
                      style={{ 
                        fontSize: 'clamp(0.95rem, 1.1vw, 1.2rem)',
                        fontWeight: 700,
                        lineHeight: '1',
                        whiteSpace: 'nowrap'
                      }}
                    >
                      {sub.valor}
                    </span>
                  </div>
                ))}
              </div>
              
              <div 
                style={{ 
                  borderTop: '1px solid rgba(168, 176, 198, 0.3)',
                  margin: 'clamp(2px, 0.25vh, 3px) 0'
                }}
              />
              
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <span 
                  className="text-[#5fa66c]"
                  style={{ 
                    fontSize: 'clamp(0.8rem, 0.95vw, 1.05rem)',
                    fontWeight: 600,
                    lineHeight: '1'
                  }}
                >
                  Total
                </span>
                <span 
                  className="text-[#5fa66c]"
                  style={{ 
                    fontSize: 'clamp(0.95rem, 1.1vw, 1.2rem)',
                    fontWeight: 700,
                    lineHeight: '1'
                  }}
                >
                  {carbonData.indice.valor}
                </span>
              </div>
            </div>

            {/* Capital Hídrico Total */}
            <div 
              className="rounded-lg border border-[#222a42]"
              style={{ 
                padding: 'clamp(3px, 0.35vh, 4px)',
                background: 'rgba(15, 18, 32, 0.4)'
              }}
            >
              <p 
                className="text-[#a8b0c6] m-0"
                style={{ 
                  fontSize: 'clamp(0.8rem, 0.95vw, 1.05rem)',
                  fontWeight: 600,
                  marginBottom: 'clamp(1px, 0.15vh, 2px)',
                  letterSpacing: '0.2px',
                  lineHeight: '1'
                }}
              >
                Capital Hídrico Total
              </p>
              <p 
                className="text-[#a8b0c6]/70 m-0"
                style={{ 
                  fontSize: 'clamp(0.65rem, 0.78vw, 0.83rem)',
                  marginBottom: 'clamp(2px, 0.25vh, 3px)',
                  lineHeight: '1',
                  fontStyle: 'italic'
                }}
              >
                Registrado en 36 meses 2023-2025
              </p>
              
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 'clamp(2px, 0.25vh, 3px)' }}>
                <div 
                  className="rounded border border-[#222a42]/50"
                  style={{ 
                    padding: 'clamp(2px, 0.25vh, 3px)',
                    background: 'rgba(15, 18, 32, 0.3)',
                    display: 'flex',
                    flexDirection: 'column',
                    gap: 'clamp(1px, 0.12vh, 2px)'
                  }}
                >
                  <span className="text-[#a8b0c6]" style={{ fontSize: 'clamp(0.7rem, 0.85vw, 0.9rem)', lineHeight: '1' }}>
                    Agua
                  </span>
                  <span className="text-[#e9eef9]" style={{ fontSize: 'clamp(0.9rem, 1.05vw, 1.15rem)', fontWeight: 600, lineHeight: '1' }}>
                    {carbonData.capitalHidrico.aguaModelo.porcentaje}%
                  </span>
                </div>
                
                <div 
                  className="rounded border border-[#222a42]/50"
                  style={{ 
                    padding: 'clamp(2px, 0.25vh, 3px)',
                    background: 'rgba(15, 18, 32, 0.3)',
                    display: 'flex',
                    flexDirection: 'column',
                    gap: 'clamp(1px, 0.12vh, 2px)'
                  }}
                >
                  <span className="text-[#a8b0c6]" style={{ fontSize: 'clamp(0.7rem, 0.85vw, 0.9rem)', lineHeight: '1' }}>
                    Humedales
                  </span>
                  <span className="text-[#e9eef9]" style={{ fontSize: 'clamp(0.9rem, 1.05vw, 1.15rem)', fontWeight: 600, lineHeight: '1' }}>
                    {carbonData.capitalHidrico.humedalesModelo.porcentaje}%
                  </span>
                </div>
              </div>
              
              <div 
                style={{ 
                  borderTop: '1px solid rgba(168, 176, 198, 0.3)',
                  margin: 'clamp(2px, 0.25vh, 3px) 0'
                }}
              />
              
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <span 
                  className="text-[#5fa66c]"
                  style={{ 
                    fontSize: 'clamp(0.8rem, 0.95vw, 1.05rem)',
                    fontWeight: 600,
                    lineHeight: '1'
                  }}
                >
                  Total
                </span>
                <span 
                  className="text-[#5fa66c]"
                  style={{ 
                    fontSize: 'clamp(0.95rem, 1.1vw, 1.2rem)',
                    fontWeight: 700,
                    lineHeight: '1'
                  }}
                >
                  {(carbonData.capitalHidrico.aguaModelo.porcentaje + carbonData.capitalHidrico.humedalesModelo.porcentaje).toFixed(1)}%
                </span>
              </div>
            </div>

            {/* Agua Persistente */}
            <div 
              className="rounded-lg border border-[#222a42]"
              style={{ 
                padding: 'clamp(3px, 0.35vh, 4px)',
                background: 'rgba(15, 18, 32, 0.4)'
              }}
            >
              <p 
                className="text-[#a8b0c6] m-0"
                style={{ 
                  fontSize: 'clamp(0.8rem, 0.95vw, 1.05rem)',
                  fontWeight: 600,
                  marginBottom: 'clamp(1px, 0.15vh, 2px)',
                  letterSpacing: '0.2px',
                  lineHeight: '1'
                }}
              >
                Agua Persistente
              </p>
              <p 
                className="text-[#a8b0c6]/70 m-0"
                style={{ 
                  fontSize: 'clamp(0.65rem, 0.78vw, 0.83rem)',
                  marginBottom: 'clamp(2px, 0.25vh, 3px)',
                  lineHeight: '1',
                  fontStyle: 'italic'
                }}
              >
                Registrada en 24 meses 2024-2025
              </p>
              
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 'clamp(2px, 0.25vh, 3px)' }}>
                <div 
                  className="rounded border border-[#222a42]/50"
                  style={{ 
                    padding: 'clamp(2px, 0.25vh, 3px)',
                    background: 'rgba(15, 18, 32, 0.3)',
                    display: 'flex',
                    flexDirection: 'column',
                    gap: 'clamp(1px, 0.12vh, 2px)'
                  }}
                >
                  <span className="text-[#a8b0c6]" style={{ fontSize: 'clamp(0.65rem, 0.8vw, 0.85rem)', lineHeight: '1' }}>
                    Permanente
                  </span>
                  <span className="text-[#e9eef9]" style={{ fontSize: 'clamp(0.85rem, 1vw, 1.1rem)', fontWeight: 600, lineHeight: '1' }}>
                    {carbonData.persistencia.aguaPermanente.porcentaje}%
                  </span>
                </div>
                
                <div 
                  className="rounded border border-[#222a42]/50"
                  style={{ 
                    padding: 'clamp(2px, 0.25vh, 3px)',
                    background: 'rgba(15, 18, 32, 0.3)',
                    display: 'flex',
                    flexDirection: 'column',
                    gap: 'clamp(1px, 0.12vh, 2px)'
                  }}
                >
                  <span className="text-[#a8b0c6]" style={{ fontSize: 'clamp(0.65rem, 0.8vw, 0.85rem)', lineHeight: '1' }}>
                    Estacional
                  </span>
                  <span className="text-[#e9eef9]" style={{ fontSize: 'clamp(0.85rem, 1vw, 1.1rem)', fontWeight: 600, lineHeight: '1' }}>
                    {carbonData.persistencia.aguaEstacional.porcentaje}%
                  </span>
                </div>
                
                <div 
                  className="rounded border border-[#222a42]/50"
                  style={{ 
                    padding: 'clamp(2px, 0.25vh, 3px)',
                    background: 'rgba(15, 18, 32, 0.3)',
                    display: 'flex',
                    flexDirection: 'column',
                    gap: 'clamp(1px, 0.12vh, 2px)'
                  }}
                >
                  <span className="text-[#a8b0c6]" style={{ fontSize: 'clamp(0.65rem, 0.8vw, 0.85rem)', lineHeight: '1' }}>
                    Humedales
                  </span>
                  <span className="text-[#e9eef9]" style={{ fontSize: 'clamp(0.85rem, 1vw, 1.1rem)', fontWeight: 600, lineHeight: '1' }}>
                    {carbonData.persistencia.humedalesSinAgua.porcentaje}%
                  </span>
                </div>
              </div>
              
              <div 
                style={{ 
                  borderTop: '1px solid rgba(168, 176, 198, 0.3)',
                  margin: 'clamp(2px, 0.25vh, 3px) 0'
                }}
              />
              
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <span 
                  className="text-[#5fa66c]"
                  style={{ 
                    fontSize: 'clamp(0.8rem, 0.95vw, 1.05rem)',
                    fontWeight: 600,
                    lineHeight: '1'
                  }}
                >
                  Total
                </span>
                <span 
                  className="text-[#5fa66c]"
                  style={{ 
                    fontSize: 'clamp(0.95rem, 1.1vw, 1.2rem)',
                    fontWeight: 700,
                    lineHeight: '1'
                  }}
                >
                  {(carbonData.persistencia.aguaPermanente.porcentaje + carbonData.persistencia.aguaEstacional.porcentaje + carbonData.persistencia.humedalesSinAgua.porcentaje).toFixed(1)}%
                </span>
              </div>
            </div>

            {/* Riesgos */}
            <div 
              className="rounded-lg border border-[#222a42]"
              style={{ 
                padding: 'clamp(3px, 0.35vh, 4px)',
                background: 'rgba(15, 18, 32, 0.4)'
              }}
            >
              <p 
                className="text-[#a8b0c6] m-0"
                style={{ 
                  fontSize: 'clamp(0.8rem, 0.95vw, 1.05rem)',
                  fontWeight: 600,
                  marginBottom: 'clamp(2px, 0.25vh, 3px)',
                  letterSpacing: '0.2px',
                  lineHeight: '1'
                }}
              >
                Riesgos (0-100)
              </p>
              
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 'clamp(2px, 0.25vh, 3px)' }}>
                <div 
                  className="rounded border border-[#222a42]/50"
                  style={{ 
                    padding: 'clamp(2px, 0.25vh, 3px)',
                    background: 'rgba(15, 18, 32, 0.3)',
                    display: 'flex',
                    flexDirection: 'column',
                    gap: 'clamp(1px, 0.12vh, 2px)'
                  }}
                >
                  <span className="text-[#a8b0c6]" style={{ fontSize: 'clamp(0.65rem, 0.8vw, 0.85rem)', lineHeight: '1' }}>
                    Inundación
                  </span>
                  <span className="text-[#e9eef9]" style={{ fontSize: 'clamp(0.85rem, 1vw, 1.1rem)', fontWeight: 600, lineHeight: '1' }}>
                    {carbonData.riesgos.flood}
                  </span>
                </div>
                
                <div 
                  className="rounded border border-[#222a42]/50"
                  style={{ 
                    padding: 'clamp(2px, 0.25vh, 3px)',
                    background: 'rgba(15, 18, 32, 0.3)',
                    display: 'flex',
                    flexDirection: 'column',
                    gap: 'clamp(1px, 0.12vh, 2px)'
                  }}
                >
                  <span className="text-[#a8b0c6]" style={{ fontSize: 'clamp(0.65rem, 0.8vw, 0.85rem)', lineHeight: '1' }}>
                    Sedimentación
                  </span>
                  <span className="text-[#e9eef9]" style={{ fontSize: 'clamp(0.85rem, 1vw, 1.1rem)', fontWeight: 600, lineHeight: '1' }}>
                    {carbonData.riesgos.sed}
                  </span>
                </div>
                
                <div 
                  className="rounded border border-[#222a42]/50"
                  style={{ 
                    padding: 'clamp(2px, 0.25vh, 3px)',
                    background: 'rgba(15, 18, 32, 0.3)',
                    display: 'flex',
                    flexDirection: 'column',
                    gap: 'clamp(1px, 0.12vh, 2px)'
                  }}
                >
                  <span className="text-[#a8b0c6]" style={{ fontSize: 'clamp(0.65rem, 0.8vw, 0.85rem)', lineHeight: '1' }}>
                    Sequía
                  </span>
                  <span className="text-[#e9eef9]" style={{ fontSize: 'clamp(0.85rem, 1vw, 1.1rem)', fontWeight: 600, lineHeight: '1' }}>
                    {carbonData.riesgos.dry}
                  </span>
                </div>
              </div>
              
              <div 
                style={{ 
                  borderTop: '1px solid rgba(239, 68, 68, 0.3)',
                  margin: 'clamp(2px, 0.25vh, 3px) 0'
                }}
              />
              
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <span 
                  className="text-[#ef4444]"
                  style={{ 
                    fontSize: 'clamp(0.8rem, 0.95vw, 1.05rem)',
                    fontWeight: 600,
                    lineHeight: '1'
                  }}
                >
                  Total
                </span>
                <span 
                  className="text-[#ef4444]"
                  style={{ 
                    fontSize: 'clamp(0.95rem, 1.1vw, 1.2rem)',
                    fontWeight: 700,
                    lineHeight: '1'
                  }}
                >
                  {carbonData.riesgos.total}
                </span>
              </div>
            </div>

            {/* Data del Sistema */}
            <div 
              className="rounded-lg border border-[#222a42]"
              style={{ 
                padding: 'clamp(3px, 0.35vh, 4px)',
                background: 'rgba(15, 18, 32, 0.4)',
                gridColumn: 'auto',
                position: 'relative'
              }}
            >
              <p 
                className="text-[#a8b0c6] m-0"
                style={{ 
                  fontSize: 'clamp(0.8rem, 0.95vw, 1.05rem)',
                  fontWeight: 600,
                  marginBottom: 'clamp(2px, 0.25vh, 3px)',
                  letterSpacing: '0.2px',
                  lineHeight: '1'
                }}
              >
                Data del Sistema
              </p>
              
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 'clamp(2px, 0.25vh, 3px)' }}>
                <div 
                  className="rounded border border-[#222a42]/50"
                  style={{ 
                    padding: 'clamp(2px, 0.25vh, 3px)',
                    background: 'rgba(15, 18, 32, 0.3)',
                    display: 'flex',
                    flexDirection: 'column',
                    gap: 'clamp(1px, 0.12vh, 2px)'
                  }}
                >
                  <span className="text-[#a8b0c6]" style={{ fontSize: 'clamp(0.65rem, 0.8vw, 0.85rem)', lineHeight: '1' }}>
                    Confianza Final
                  </span>
                  <span className="text-[#e9eef9]" style={{ fontSize: 'clamp(0.85rem, 1vw, 1.1rem)', fontWeight: 600, lineHeight: '1' }}>
                    {carbonData.confianza.valor}
                  </span>
                </div>
                
                <div 
                  className="rounded border border-[#222a42]/50"
                  style={{ 
                    padding: 'clamp(2px, 0.25vh, 3px)',
                    background: 'rgba(15, 18, 32, 0.3)',
                    display: 'flex',
                    flexDirection: 'column',
                    gap: 'clamp(1px, 0.12vh, 2px)'
                  }}
                >
                  <span className="text-[#a8b0c6]" style={{ fontSize: 'clamp(0.65rem, 0.8vw, 0.85rem)', lineHeight: '1' }}>
                    Fuentes activas
                  </span>
                  <span className="text-[#e9eef9]" style={{ fontSize: 'clamp(0.85rem, 1vw, 1.1rem)', fontWeight: 600, lineHeight: '1' }}>
                    {carbonData.confianza.fuentesActivas}
                  </span>
                </div>
                
                <div 
                  className="rounded border border-[#222a42]/50"
                  style={{ 
                    padding: 'clamp(2px, 0.25vh, 3px)',
                    background: 'rgba(15, 18, 32, 0.3)',
                    display: 'flex',
                    flexDirection: 'column',
                    gap: 'clamp(1px, 0.12vh, 2px)'
                  }}
                >
                  <span className="text-[#a8b0c6]" style={{ fontSize: 'clamp(0.65rem, 0.8vw, 0.85rem)', lineHeight: '1' }}>
                    Soporte promedio
                  </span>
                  <span className="text-[#e9eef9]" style={{ fontSize: 'clamp(0.85rem, 1vw, 1.1rem)', fontWeight: 600, lineHeight: '1' }}>
                    {carbonData.confianza.soportePromedioAgua}
                  </span>
                </div>
              </div>
              
              {/* Separador con margen triple */}
              <div 
                style={{ 
                  borderTop: '1px solid rgba(168, 176, 198, 0.2)',
                  margin: 'clamp(6px, 0.75vh, 9px) 0 clamp(4px, 0.5vh, 6px) 0'
                }}
              />
              
              <p 
                className="text-[#a8b0c6] text-center m-0"
                style={{ 
                  fontSize: 'clamp(0.75rem, 0.9vw, 1rem)',
                  lineHeight: '1.15',
                  marginBottom: 'clamp(1px, 0.12vh, 2px)'
                }}
              >
                <span className="text-[#e9eef9]">Fuentes:</span> Sentinel-2 MSI, MODIS, ERA5-Land, CHIRPS, GSW / <span className="text-[#e9eef9]">Serie Temporal:</span> 2023 - 2025
              </p>
              
              {/* Separador con margen triple */}
              <div 
                style={{ 
                  borderTop: '1px solid rgba(168, 176, 198, 0.2)',
                  margin: 'clamp(6px, 0.75vh, 9px) 0 clamp(4px, 0.5vh, 6px) 0'
                }}
              />
              
              {/* *Valores integrados... en blanco destacado, más grande, con ícono info */}
              <div className="flex items-center justify-center gap-[6px] relative">
                <p 
                  className="text-[#e9eef9] text-center m-0"
                  style={{ 
                    fontSize: 'clamp(0.7rem, 0.85vw, 0.9rem)',
                    fontWeight: 600,
                    lineHeight: '1',
                    letterSpacing: '0.2px'
                  }}
                >
                  *Valores integrados a escala píxel
                </p>
                
                {/* Ícono de información con tooltip */}
                <div 
                  className="relative"
                  onMouseEnter={() => setShowTooltip(true)}
                  onMouseLeave={() => setShowTooltip(false)}
                >
                  <Info 
                    className="text-[#7eb88a] cursor-help" 
                    style={{ 
                      width: 'clamp(12px, 0.95vw, 14px)', 
                      height: 'clamp(12px, 0.95vw, 14px)',
                      flexShrink: 0
                    }} 
                  />
                  
                  {/* Tooltip */}
                  {showTooltip && (
                    <div 
                      className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 rounded-lg border border-[#7eb88a]/50 shadow-xl"
                      style={{
                        background: 'linear-gradient(180deg, #1a2540, #141a2a)',
                        padding: 'clamp(12px, 1.4vh, 16px)',
                        minWidth: '400px',
                        maxWidth: '480px',
                        zIndex: 100
                      }}
                    >
                      <p className="text-[#e9eef9] m-0" style={{ fontSize: 'clamp(0.95rem, 1.1vw, 1.15rem)', lineHeight: '1.4', marginBottom: '8px', fontWeight: 600 }}>
                        Metodología de Integración
                      </p>
                      <p className="text-[#a8b0c6] m-0" style={{ fontSize: 'clamp(0.9rem, 1.05vw, 1.1rem)', lineHeight: '1.4' }}>
                        Los valores se derivan de la integración de píxeles dentro del área de análisis, según la resolución espacial nativa de cada fuente de datos. Las variaciones responden a la discretización espacial y a la superficie efectivamente cubierta por los píxeles.
                      </p>
                      {/* Flecha del tooltip */}
                      <div 
                        className="absolute top-full left-1/2 transform -translate-x-1/2"
                        style={{
                          width: 0,
                          height: 0,
                          borderLeft: '8px solid transparent',
                          borderRight: '8px solid transparent',
                          borderTop: '8px solid #1a2540'
                        }}
                      />
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}