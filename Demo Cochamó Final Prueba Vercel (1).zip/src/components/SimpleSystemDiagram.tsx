import { useLanguage } from '../contexts/LanguageContext';

export default function SimpleSystemDiagram() {
  const { language } = useLanguage();

  const content = {
    es: {
      title: 'Arquitectura del Sistema',
      layers: [
        { name: 'Fuentes Satelitales', desc: 'Sentinel-2, Landsat, MODIS, CHIRPS' },
        { name: 'Procesamiento Multi-anual', desc: 'Ventanas 5 años, métricas espaciales' },
        { name: 'Índices Propietarios', desc: 'Hydro®, ESI®, Carbon™, Risk®' },
        { name: 'Monitoreo Continuo', desc: 'Actualización automática, alertas' },
        { name: 'Dashboard Interactivo', desc: 'Visualización, reportes, análisis' }
      ]
    },
    en: {
      title: 'System Architecture',
      layers: [
        { name: 'Satellite Sources', desc: 'Sentinel-2, Landsat, MODIS, CHIRPS' },
        { name: 'Multi-year Processing', desc: '5-year windows, spatial metrics' },
        { name: 'Proprietary Indices', desc: 'Hydro®, ESI®, Carbon™, Risk®' },
        { name: 'Continuous Monitoring', desc: 'Auto updates, alerts' },
        { name: 'Interactive Dashboard', desc: 'Visualization, reports, analysis' }
      ]
    }
  };

  const t = content[language];

  return (
    <div className="mb-8">
      <h2 className="text-xl font-medium text-[#e9eef9] mb-6 pb-2 border-b border-[#1a2540]">
        {t.title}
      </h2>
      
      <div className="relative">
        {/* Línea vertical conectora */}
        <div className="absolute left-[19px] top-8 bottom-8 w-[2px] bg-gradient-to-b from-[#06b6d4] via-[#0ea5e9] to-[#06b6d4] opacity-30" />
        
        {/* Capas del sistema */}
        <div className="space-y-4">
          {t.layers.map((layer, idx) => (
            <div key={idx} className="flex items-start gap-4 relative">
              {/* Número de capa */}
              <div className="relative z-10 w-10 h-10 rounded-full bg-[#171f33] border-2 border-[#06b6d4] flex items-center justify-center flex-shrink-0">
                <span className="text-sm font-semibold text-[#06b6d4]">{idx + 1}</span>
              </div>
              
              {/* Contenido de la capa */}
              <div className="flex-1 bg-[#171f33] border border-[#243253] rounded-lg p-4 mt-1">
                <div className="text-base font-medium text-[#e9eef9] mb-1">
                  {layer.name}
                </div>
                <div className="text-sm text-[#8a94a8]">
                  {layer.desc}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
