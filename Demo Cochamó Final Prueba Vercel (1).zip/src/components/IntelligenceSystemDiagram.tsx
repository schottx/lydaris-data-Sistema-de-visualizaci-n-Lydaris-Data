import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Database, TrendingUp, Shield, BarChart3, Eye, Award, Droplets, Trees, AlertTriangle } from 'lucide-react';

interface Layer {
  id: string;
  name: string;
  description: string;
  color: string;
  icon?: any;
  details?: string[];
  relatedTo?: string[];
}

export default function IntelligenceSystemDiagram() {
  const [hoveredLayer, setHoveredLayer] = useState<string | null>(null);
  const [tooltipPosition, setTooltipPosition] = useState({ x: 0, y: 0 });

  // Define relationships between indices and capabilities
  const coreIndices: Layer[] = [
    { 
      id: 'hydro', 
      name: 'Hydro Index®', 
      description: 'Sistema hídrico funcional',
      color: '#06b6d4',
      icon: Droplets,
      details: [
        'Conectividad hídrica',
        'Regulación y retención',
        'Amortiguación climática'
      ],
      relatedTo: ['monitoring', 'predictive', 'dashboard', 'traceability']
    },
    { 
      id: 'esi', 
      name: 'ESI®', 
      description: 'Integridad estructural ecosistémica',
      color: '#10b981',
      icon: Trees,
      details: [
        'Continuidad ecológica',
        'Conectividad estructural',
        'Vigor ecosistémico'
      ],
      relatedTo: ['monitoring', 'benchmark', 'value', 'traceability']
    },
    { 
      id: 'risk', 
      name: 'Risk Index®', 
      description: 'Perfil de riesgo ambiental',
      color: '#f59e0b',
      icon: AlertTriangle,
      details: [
        'Riesgo erosivo',
        'Stress climático',
        'Fragmentación'
      ],
      relatedTo: ['monitoring', 'predictive', 'dashboard', 'benchmark']
    }
  ];

  const capabilities: Layer[] = [
    { 
      id: 'monitoring', 
      name: 'Monitoreo', 
      description: 'Actualización automática satelital no invasiva',
      color: '#8b5cf6',
      icon: Eye,
      details: [
        'Actualización periódica',
        'Detección temprana',
        'Alertas automáticas'
      ],
      relatedTo: ['hydro', 'esi', 'risk']
    },
    { 
      id: 'traceability', 
      name: 'Trazabilidad', 
      description: 'Verificabilidad digital completa',
      color: '#3b82f6',
      icon: Database,
      details: [
        'Fuente verificable',
        'Auditoría completa',
        'Certificación digital'
      ],
      relatedTo: ['hydro', 'esi']
    },
    { 
      id: 'benchmark', 
      name: 'Benchmarking', 
      description: 'Comparación regional automatizada',
      color: '#06b6d4',
      icon: BarChart3,
      details: [
        'Comparación regional',
        'Ranking de integridad',
        'Mejores prácticas'
      ],
      relatedTo: ['esi', 'risk']
    },
    { 
      id: 'predictive', 
      name: 'Predictiva', 
      description: 'Escenarios y proyecciones',
      color: '#10b981',
      icon: TrendingUp,
      details: [
        'Proyección temporal',
        'Escenarios climáticos',
        'Análisis de tendencias'
      ],
      relatedTo: ['hydro', 'risk']
    },
    { 
      id: 'dashboard', 
      name: 'Dashboard', 
      description: 'Visualización dinámica decisional',
      color: '#f59e0b',
      icon: Shield,
      details: [
        'Métricas en tiempo real',
        'Reportes automáticos',
        'Integración sistemas'
      ],
      relatedTo: ['hydro', 'risk']
    },
    { 
      id: 'value', 
      name: 'Valor Digital', 
      description: 'Pasaporte patrimonial trazable',
      color: '#ec4899',
      icon: Award,
      details: [
        'Histórico trazable',
        'Due diligence técnico',
        'Valorización patrimonial'
      ],
      relatedTo: ['esi']
    }
  ];

  const allElements = [...coreIndices, ...capabilities];

  const isRelated = (elementId: string) => {
    if (!hoveredLayer) return false;
    
    const hoveredElement = allElements.find(e => e.id === hoveredLayer);
    if (!hoveredElement) return false;

    // Check if the current element is related to the hovered one
    return hoveredElement.relatedTo?.includes(elementId) || false;
  };

  const handleMouseEnter = (id: string, event: React.MouseEvent) => {
    setHoveredLayer(id);
    const rect = event.currentTarget.getBoundingClientRect();
    setTooltipPosition({
      x: rect.left + rect.width / 2,
      y: rect.top
    });
  };

  const hoveredElement = allElements.find(e => e.id === hoveredLayer);

  return (
    <div className="w-full bg-gradient-to-br from-[#0a0e1a] to-[#0f1729] rounded-2xl p-8 print:bg-white print:border print:border-gray-300 relative print:page-break-before-always">
      <h3 className="text-xl font-semibold text-[#e9eef9] mb-6 text-center print:text-black print:text-lg">
        Arquitectura del Sistema de Inteligencia Ambiental Continua
      </h3>

      {/* Floating Tooltip */}
      <AnimatePresence>
        {hoveredLayer && hoveredElement && (
          <motion.div
            initial={{ opacity: 0, y: 10, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 10, scale: 0.9 }}
            transition={{ duration: 0.2 }}
            className="fixed z-50 pointer-events-none print:hidden"
            style={{
              left: `${tooltipPosition.x}px`,
              top: `${tooltipPosition.y - 20}px`,
              transform: 'translate(-50%, -100%)'
            }}
          >
            <div className="bg-[#1a2540] border-2 border-[#243253] rounded-xl shadow-2xl p-4 min-w-[280px] backdrop-blur-sm">
              {/* Header */}
              <div className="flex items-center gap-3 mb-3 pb-3 border-b border-[#243253]">
                {hoveredElement.icon && (
                  <div 
                    className="p-2 rounded-lg"
                    style={{ backgroundColor: `${hoveredElement.color}20` }}
                  >
                    <hoveredElement.icon 
                      className="w-5 h-5" 
                      style={{ color: hoveredElement.color }}
                    />
                  </div>
                )}
                <div>
                  <div 
                    className="font-bold text-base"
                    style={{ color: hoveredElement.color }}
                  >
                    {hoveredElement.name}
                  </div>
                  <div className="text-xs text-[#8a94a8]">
                    {hoveredElement.description}
                  </div>
                </div>
              </div>

              {/* Details */}
              {hoveredElement.details && (
                <div className="space-y-1.5">
                  {hoveredElement.details.map((detail, idx) => (
                    <div key={idx} className="flex items-start gap-2 text-xs text-[#c4cfe0]">
                      <div 
                        className="w-1.5 h-1.5 rounded-full mt-1.5 flex-shrink-0"
                        style={{ backgroundColor: hoveredElement.color }}
                      />
                      <span>{detail}</span>
                    </div>
                  ))}
                </div>
              )}

              {/* Related elements count */}
              {hoveredElement.relatedTo && hoveredElement.relatedTo.length > 0 && (
                <div className="mt-3 pt-3 border-t border-[#243253]">
                  <div className="text-xs text-[#8a94a8]">
                    Conectado con{' '}
                    <span className="text-[#06b6d4] font-semibold">
                      {hoveredElement.relatedTo.length}
                    </span>
                    {' '}elemento{hoveredElement.relatedTo.length !== 1 ? 's' : ''}
                  </div>
                </div>
              )}

              {/* Arrow pointer */}
              <div 
                className="absolute bottom-0 left-1/2 transform -translate-x-1/2 translate-y-full"
                style={{
                  width: 0,
                  height: 0,
                  borderLeft: '8px solid transparent',
                  borderRight: '8px solid transparent',
                  borderTop: '8px solid #243253'
                }}
              />
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="relative w-full max-w-3xl mx-auto" style={{ aspectRatio: '1/1' }}>
        <svg viewBox="0 0 400 400" className="w-full h-full">
          {/* Background circles */}
          <circle cx="200" cy="200" r="180" fill="none" stroke="#1a2540" strokeWidth="1" opacity="0.3" />
          <circle cx="200" cy="200" r="130" fill="none" stroke="#1a2540" strokeWidth="1" opacity="0.3" />
          <circle cx="200" cy="200" r="80" fill="none" stroke="#1a2540" strokeWidth="1" opacity="0.3" />

          {/* Outer layer - Capabilities */}
          {capabilities.map((cap, idx) => {
            const angle = (idx * 60 - 90) * (Math.PI / 180);
            const x = 200 + 150 * Math.cos(angle);
            const y = 200 + 150 * Math.sin(angle);
            const Icon = cap.icon;
            const isHighlighted = hoveredLayer === cap.id || isRelated(cap.id);

            return (
              <g key={cap.id}>
                {/* Connection line to center */}
                <motion.line
                  x1="200"
                  y1="200"
                  x2={x}
                  y2={y}
                  stroke={cap.color}
                  strokeWidth={isHighlighted ? "2.5" : "1.5"}
                  opacity={isHighlighted ? 0.8 : 0.2}
                  initial={{ pathLength: 0 }}
                  animate={{ pathLength: 1 }}
                  transition={{ duration: 1.5, delay: idx * 0.1 }}
                  className="print:opacity-40"
                />

                {/* Capability node */}
                <motion.circle
                  cx={x}
                  cy={y}
                  r={isHighlighted ? 28 : 24}
                  fill={cap.color}
                  opacity={isHighlighted ? 1 : (hoveredLayer ? 0.4 : 0.85)}
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ 
                    type: "spring",
                    stiffness: 260,
                    damping: 20,
                    delay: idx * 0.15 
                  }}
                  onMouseEnter={(e: any) => handleMouseEnter(cap.id, e)}
                  onMouseLeave={() => setHoveredLayer(null)}
                  className="cursor-pointer print:opacity-100"
                  style={{
                    filter: isHighlighted ? 'drop-shadow(0 0 8px rgba(6, 182, 212, 0.6))' : 'none'
                  }}
                />

                {/* Icon placeholder */}
                <circle
                  cx={x}
                  cy={y}
                  r="8"
                  fill="white"
                  opacity={isHighlighted ? "1" : "0.9"}
                />
              </g>
            );
          })}

          {/* Middle layer - Core Indices */}
          {coreIndices.map((index, idx) => {
            const angle = (idx * 120 - 90) * (Math.PI / 180);
            const x = 200 + 100 * Math.cos(angle);
            const y = 200 + 100 * Math.sin(angle);
            const isHighlighted = hoveredLayer === index.id || isRelated(index.id);

            return (
              <g key={index.id}>
                {/* Index node */}
                <motion.circle
                  cx={x}
                  cy={y}
                  r={isHighlighted ? 22 : 18}
                  fill={index.color}
                  opacity={isHighlighted ? 1 : (hoveredLayer ? 0.4 : 0.9)}
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ 
                    type: "spring",
                    stiffness: 260,
                    damping: 20,
                    delay: 0.8 + idx * 0.1 
                  }}
                  onMouseEnter={(e: any) => handleMouseEnter(index.id, e)}
                  onMouseLeave={() => setHoveredLayer(null)}
                  className="cursor-pointer print:opacity-100"
                  style={{
                    filter: isHighlighted ? 'drop-shadow(0 0 8px rgba(6, 182, 212, 0.6))' : 'none'
                  }}
                />

                {/* Index label */}
                <text
                  x={x}
                  y={y + 35}
                  textAnchor="middle"
                  fill={isHighlighted ? "#06b6d4" : "#e9eef9"}
                  fontSize="10"
                  fontWeight={isHighlighted ? "700" : "600"}
                  className="print:fill-black pointer-events-none"
                >
                  {index.name}
                </text>
              </g>
            );
          })}

          {/* Center - Platform core */}
          <motion.circle
            cx="200"
            cy="200"
            r="50"
            fill="url(#centerGradient)"
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ 
              type: "spring",
              stiffness: 260,
              damping: 20,
              delay: 1.2
            }}
            className="print:fill-cyan-600"
          />

          {/* Gradient definition */}
          <defs>
            <radialGradient id="centerGradient">
              <stop offset="0%" stopColor="#06b6d4" />
              <stop offset="100%" stopColor="#0891b2" />
            </radialGradient>
          </defs>

          {/* Center text */}
          <text
            x="200"
            y="195"
            textAnchor="middle"
            fill="white"
            fontSize="14"
            fontWeight="700"
          >
            Lydaris
          </text>
          <text
            x="200"
            y="210"
            textAnchor="middle"
            fill="white"
            fontSize="10"
            fontWeight="500"
            opacity="0.9"
          >
            Intelligence
          </text>
        </svg>

        {/* Capability labels outside the circle */}
        <div className="absolute inset-0 pointer-events-none">
          {capabilities.map((cap, idx) => {
            const angle = (idx * 60 - 90) * (Math.PI / 180);
            const radius = 185;
            const x = 50 + (radius * Math.cos(angle) / 400) * 100;
            const y = 50 + (radius * Math.sin(angle) / 400) * 100;
            const isHighlighted = hoveredLayer === cap.id || isRelated(cap.id);

            return (
              <motion.div
                key={`label-${cap.id}`}
                className="absolute text-center pointer-events-auto cursor-pointer"
                style={{
                  left: `${x}%`,
                  top: `${y}%`,
                  transform: 'translate(-50%, -50%)',
                  width: '80px'
                }}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 1.5 + idx * 0.1 }}
                onMouseEnter={(e) => handleMouseEnter(cap.id, e)}
                onMouseLeave={() => setHoveredLayer(null)}
              >
                <div className={`text-xs font-semibold transition-all duration-300 ${
                  isHighlighted ? 'text-[#06b6d4] scale-110' : (hoveredLayer ? 'text-[#4a5568]' : 'text-[#8a94a8]')
                } print:text-gray-700`}>
                  {cap.name}
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>

      {/* Legend/Description box */}
      <motion.div
        className="mt-8 bg-[#1a2540]/50 rounded-lg p-4 border border-[#243253] print:bg-gray-50 print:border-gray-300"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 2 }}
      >
        {hoveredLayer && hoveredElement ? (
          <div className="text-center">
            <div className="text-sm font-semibold text-[#06b6d4] mb-1 print:text-cyan-700">
              {hoveredElement.name}
            </div>
            <div className="text-xs text-[#c4cfe0] print:text-gray-700">
              {hoveredElement.relatedTo && hoveredElement.relatedTo.length > 0 && (
                <span className="opacity-75">
                  Integrado con: {hoveredElement.relatedTo.map(id => 
                    allElements.find(e => e.id === id)?.name
                  ).join(', ')}
                </span>
              )}
            </div>
          </div>
        ) : (
          <div className="text-center text-xs text-[#8a94a8] print:text-gray-600">
            Pasa el cursor sobre los elementos del diagrama para ver detalles y relaciones
          </div>
        )}
      </motion.div>

      {/* Key metrics footer */}
      <div className="mt-6 grid grid-cols-3 gap-4 print:gap-2">
        <div className="text-center p-3 bg-[#1a2540]/30 rounded-lg print:bg-gray-50">
          <div className="text-2xl font-bold text-[#06b6d4] print:text-cyan-700">3</div>
          <div className="text-xs text-[#8a94a8] mt-1 print:text-gray-600">Índices Core</div>
        </div>
        <div className="text-center p-3 bg-[#1a2540]/30 rounded-lg print:bg-gray-50">
          <div className="text-2xl font-bold text-[#10b981] print:text-green-700">6</div>
          <div className="text-xs text-[#8a94a8] mt-1 print:text-gray-600">Capacidades</div>
        </div>
        <div className="text-center p-3 bg-[#1a2540]/30 rounded-lg print:bg-gray-50">
          <div className="text-2xl font-bold text-[#f59e0b] print:text-amber-700">∞</div>
          <div className="text-xs text-[#8a94a8] mt-1 print:text-gray-600">Monitoreo continuo</div>
        </div>
      </div>
    </div>
  );
}