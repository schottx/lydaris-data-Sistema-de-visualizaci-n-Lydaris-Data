/*
 * ==============================================
 * LYDARIS TOUR 360° - VERSIÓN SIMPLIFICADA
 * ==============================================
 */

import React, { useRef, useEffect, useState } from 'react';
import mapboxgl from 'mapbox-gl';
import 'mapbox-gl/dist/mapbox-gl.css';
import { X, Play, Pause, Volume2, VolumeX, Satellite } from 'lucide-react';
import { MAPBOX_CONFIG, TILE_SOURCES, DEFAULT_LOCATION, VECTOR_SOURCES } from '../config/data-sources';
import { reservaCochamoCoordinates } from '../data/aoi_cochamo';
import { riverGeoJSON } from '../data/river';
import { waterClassificationGeoJSON } from '../data/water-classification';

interface Tour360Props {
  isOpen: boolean;
  onClose: () => void;
  language: 'es' | 'en';
}

interface Waypoint {
  time: number;
  text: { es: string; en: string };
  audioText?: { es: string; en: string }; // 🎤 TEXTO ALTERNATIVO SOLO PARA AUDIO (pronunciación fonética)
  camera: { center: [number, number]; bearing: number; pitch: number; zoom: number };
  duration: number;
}

const WAYPOINTS: Waypoint[] = [
  {
    time: 0,
    text: { 
      es: 'Reserva Cochamó, ubicada en uno de los territorios más prístinos de la Patagonia andina norte, forma parte de un sistema binacional de conservación de más de un millón seiscientas mil hectáreas.',
      en: 'Cochamó Reserve, located in one of the most pristine territories of northern Andean Patagonia, is part of a binational conservation system of over one million six hundred thousand hectares.'
    },
    camera: { center: [-72.217, -41.416], bearing: 0, pitch: 30, zoom: 12.3 }, // 🎬 ZOOM INICIAL: 12.3 (más alejado que antes)
    duration: 25000,
  },
  {
    time: 26,
    text: { 
      es: 'Se define como un refugio climático de montaña, con alta funcionalidad ecológica y valor estratégico para conservación y monitoreo de largo plazo. Presenta muy alto potencial como laboratorio natural de resiliencia ecosistémica.',
      en: 'It is defined as a mountain climate refuge, with high ecological functionality and strategic value for long-term conservation and monitoring. It presents very high potential as a natural laboratory for ecosystem resilience.'
    },
    camera: { center: [-72.217, -41.417], bearing: 2, pitch: 28, zoom: 12.05 }, // 🎬 ULTRA SUAVIZADO: posición casi idéntica al final del WP0 (center muy cerca, bearing 2, pitch 28, zoom 12.05)
    duration: 28000,
  },
  {
    time: 55,
    text: { 
      es: 'El análisis hídrico muestra un territorio donde el agua no se concentra en ejes aislados, sino que se distribuye y regula a través de una red densa y continua. La combinación entre topografía, cobertura vegetal, humedales y drenaje superficial sostiene una persistencia hídrica estable, incluso en escenarios de variabilidad climática.',
      en: 'Hydrological analysis shows a territory where water does not concentrate in isolated axes, but distributes and regulates through a dense and continuous network. The combination of topography, vegetation cover, wetlands and surface drainage sustains stable water persistence, even under climate variability scenarios.'
    },
    camera: { center: [-72.222, -41.428], bearing: 75, pitch: 32, zoom: 12.6 }, // 🎬 AJUSTADO: zoom 12.6 (más cerca para protagonismo de capa de agua), centro ajustado
    duration: 32000,
  },
  {
    time: 88,
    text: { 
      es: 'La altitud del sistema juega un rol clave: mantiene isotermas bajas que favorecen aportes nivales estacionales, recarga hídrica progresiva y una pluviometría que, pese a las tendencias de cambio climático, se conserva en altura como factor regulador del sistema.',
      en: 'System altitude plays a key role: it maintains low isotherms that favor seasonal snow contributions, progressive water recharge and precipitation that, despite climate change trends, is preserved at elevation as a regulatory factor of the system.'
    },
    camera: { center: [-72.235, -41.432], bearing: 80, pitch: 32, zoom: 12.6 }, // 🎬 SUAVIZADO: bearing 80 (más cerca del 75 anterior), pitch 32, zoom 12.6 (igual que anterior)
    duration: 28000,
  },
  {
    time: 117,
    text: { 
      es: 'Desde la dimensión eco-estructural, la reserva presenta un alto nivel de integridad y nula presión antrópica. La continuidad del paisaje, la baja fragmentación, el alto vigor vegetacional y la coherencia entre relieve, suelo y vegetación permiten que los procesos ecológicos operen de forma funcional a escala de cuenca.',
      en: 'From an eco-structural dimension, the reserve presents a high level of integrity and zero anthropic pressure. Landscape continuity, low fragmentation, high vegetational vigor and coherence between relief, soil and vegetation allow ecological processes to operate functionally at watershed scale.'
    },
    camera: { center: [-72.233, -41.427], bearing: 105, pitch: 52, zoom: 12.8 }, // 🎬 SUAVIZADO: bearing 105 (cerca del 110 final del WP3), pitch 52 (cerca del 55 final), zoom 12.8 (igual que final WP3)
    duration: 30000,
  },
  {
    time: 148,
    text: { 
      es: 'La geomorfología define el carácter del territorio. Pendientes marcadas, valles profundos y macizos rocosos gobiernan su dinámica natural. Los análisis históricos no registran eventos relevantes de remoción en las últimas cuatro décadas, confirmando una condición de estabilidad estructural bajo el régimen climático observado.',
      en: 'Geomorphology defines the territory\'s character. Steep slopes, deep valleys and rocky massifs govern its natural dynamics. Historical analyses record no significant removal events in the last four decades, confirming a condition of structural stability under the observed climate regime.'
    },
    camera: { center: [-72.225, -41.420], bearing: 85, pitch: 40, zoom: 12.7 }, // 🎬 ULTRA SUAVIZADO: bearing 85 (igual que final del WP4), pitch 40 (igual que final), zoom 12.7 (igual que final WP4)
    duration: 30000,
  },
  {
    time: 179,
    text: { 
      es: 'Frente a escenarios futuros de eventos hidrometeorológicos exacerbados, se identifican zonas puntuales donde podrían activarse procesos superficiales dependientes del evento, sin constituir una condición permanente del sistema.',
      en: 'Facing future scenarios of exacerbated hydrometeorological events, specific zones are identified where surface processes dependent on the event could activate, without constituting a permanent condition of the system.'
    },
    camera: { center: [-72.217, -41.418], bearing: 28, pitch: 37, zoom: 12.6 }, // 🎬 ULTRA SUAVIZADO: bearing 28 (cerca del 30 final del WP5), pitch 37 (cerca del 38 final), zoom 12.6
    duration: 26000,
  },
  {
    time: 206,
    text: { 
      es: 'Explore en mayor profundidad cada aspecto en el menú lateral del dashboard, donde cada índice activa sus capas especializadas y paneles de datos asociados, permitiendo una comprensión detallada de los procesos que estructuran la reserva.',
      en: 'Explore each aspect in greater depth in the dashboard side menu, where each index activates its specialized layers and associated data panels, allowing detailed understanding of the processes that structure the reserve.'
    },
    camera: { center: [-72.215, -41.419], bearing: -10, pitch: 34, zoom: 12.3 }, // 🎬 SUAVIZADO: bearing -10 (reducido de -35), zoom 12.3 (más cercano, reducido de 11.8), pitch 34
    duration: 24000,
  },
  {
    time: 231,
    text: { 
      es: 'Por ejemplo, podrá visualizar diferentes tipologías de aguas detectadas: desde aguas abiertas permanentes y aguas estacionales, hasta sistemas subsuperficiales que constituyen la base estructural de la red hídrica del territorio.',
      en: 'For example, you will be able to visualize different typologies of detected waters: from permanent open waters and seasonal waters, to subsurface systems that constitute the structural base of the territory\'s water network.'
    },
    camera: { center: [-72.218, -41.425], bearing: 5, pitch: 33, zoom: 12.4 }, // 🎬 SUTIL: bearing 5, zoom 12.4 (más cerca), pitch 33
    duration: 26000,
  },
  {
    time: 258,
    text: { 
      es: 'Asimismo, podrá revisar capas de vigor ecosistémico, mapas de pendientes, humedad y susceptibilidad en laderas como factores de evaluación de riesgo.',
      en: 'Likewise, you will be able to review ecosystem vigor layers, slope maps, humidity and hillside susceptibility as risk assessment factors.'
    },
    camera: { center: [-72.220, -41.428], bearing: -5, pitch: 32, zoom: 12.2 }, // 🎬 SUTIL: bearing -5 (muy suave), zoom 12.2 (NO alejarse tanto), pitch 32
    duration: 24000,
  },
  {
    time: 289,
    text: { 
      es: 'Bienvenidos a la nueva generación de analítica geo ambiental de Lydaris Data Intelligence.',
      en: 'Welcome to the new generation of geo-environmental analytics from Lydaris Data Intelligence.'
    },
    audioText: {
      es: 'Bienvenidos a la nueva generación de analítica geo ambiental de Lídaris Data Inteliyens.',
      en: 'Welcome to the new generation of geo-environmental analytics from Lydaris Data Intelligence.'
    },
    camera: { center: [-72.217, -41.425], bearing: 0, pitch: 32, zoom: 12.4 }, // 🎬 ZOOM FINAL: 12.4 (más cerca del AOI), pitch 32, center ajustado
    duration: 14000,
  },
];

const TOTAL_DURATION = 180; // ⏱️ DURACIÓN TOTAL DEL VIDEO: 180 segundos

export function Tour360({ isOpen, onClose, language }: Tour360Props) {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<mapboxgl.Map | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [isMuted, setIsMuted] = useState(false);
  const [displayText, setDisplayText] = useState('');
  const [currentWaypointIndex, setCurrentWaypointIndex] = useState(-1);
  const [availableVoices, setAvailableVoices] = useState<SpeechSynthesisVoice[]>([]);
  const animationRef = useRef<number | null>(null);
  const startTimeRef = useRef<number | null>(null);
  const typewriterRef = useRef<number | null>(null);
  const currentUtteranceRef = useRef<SpeechSynthesisUtterance | null>(null); // 🎤 REFERENCIA AL UTTERANCE ACTUAL
  const isCleaningUpAudioRef = useRef<boolean>(false); // 🎤 FLAG PARA IGNORAR ERRORES DE LIMPIEZA

  // 🌐 USAR EL IDIOMA DEL PROP (sincronizado con el idioma global)
  const [currentLanguage, setCurrentLanguage] = useState<'es' | 'en'>(language);

  // 🌐 SINCRONIZAR IDIOMA CUANDO CAMBIA EL PROP
  useEffect(() => {
    setCurrentLanguage(language);
  }, [language]);

  // Cargar voces disponibles
  useEffect(() => {
    const loadVoices = () => {
      const voices = window.speechSynthesis.getVoices();
      setAvailableVoices(voices);
      console.log('🎤 Tour360: Voces cargadas:', voices.length);
    };

    loadVoices();

    if (window.speechSynthesis.onvoiceschanged !== undefined) {
      window.speechSynthesis.onvoiceschanged = loadVoices;
    }

    return () => {
      window.speechSynthesis.onvoiceschanged = null;
    };
  }, []);

  // 🎤 FUNCIÓN DE LIMPIEZA DE AUDIO (sin disparar errores)
  const cleanupAudio = () => {
    // Marcar que estamos limpiando para que los eventos del utterance anterior no hagan nada
    if (typewriterRef.current) {
      clearInterval(typewriterRef.current);
      typewriterRef.current = null;
    }
    
    // Si hay un utterance actual, limpiar sus eventos antes de cancelar
    if (currentUtteranceRef.current) {
      currentUtteranceRef.current.onstart = null;
      currentUtteranceRef.current.onend = null;
      currentUtteranceRef.current.onerror = null;
      currentUtteranceRef.current = null;
    }
    
    // Cancelar todo el audio - CRÍTICO para limpiar la cola del motor TTS
    try {
      window.speechSynthesis?.cancel();
    } catch (e) {
      // Ignorar errores de cancelación
    }
  };

  // 🚀 PRE-WARMING del motor TTS para reducir latencia inicial
  useEffect(() => {
    if (!isOpen) return;

    // Técnica de "pre-warming": hacer una llamada dummy para inicializar el motor TTS
    const prewarmTTS = () => {
      try {
        const dummyUtterance = new SpeechSynthesisUtterance('');
        dummyUtterance.volume = 0; // Silencioso
        dummyUtterance.rate = 10; // Lo más rápido posible
        window.speechSynthesis.speak(dummyUtterance);
        
        // Cancelar inmediatamente después de inicializar
        setTimeout(() => {
          window.speechSynthesis.cancel();
        }, 10);
        
        console.log('🚀 Motor TTS pre-calentado para reducir latencia inicial');
      } catch (error) {
        console.warn('⚠️ Pre-warming TTS fallido (no crítico):', error);
      }
    };

    // Ejecutar pre-warming con pequeño delay para que el modal esté completamente abierto
    const timer = setTimeout(prewarmTTS, 300);

    return () => {
      clearTimeout(timer);
    };
  }, [isOpen]);

  // Inicializar mapa
  useEffect(() => {
    if (!isOpen || !mapContainerRef.current || mapRef.current) return;

    mapboxgl.accessToken = MAPBOX_CONFIG.token;

    const map = new mapboxgl.Map({
      container: mapContainerRef.current,
      style: MAPBOX_CONFIG.styles.satellite,
      center: WAYPOINTS[0].camera.center,
      zoom: WAYPOINTS[0].camera.zoom,
      pitch: WAYPOINTS[0].camera.pitch,
      bearing: WAYPOINTS[0].camera.bearing,
      interactive: false,
      antialias: true,
    });
    
    // Agregar control de atribución con logo en bottom-right
    map.addControl(new mapboxgl.AttributionControl({
      compact: false
    }), 'bottom-right');

    map.on('style.load', () => {
      // Terreno 3D
      map.addSource('mapbox-dem', {
        type: 'raster-dem',
        url: MAPBOX_CONFIG.dem.url,
        tileSize: MAPBOX_CONFIG.dem.tileSize,
        maxzoom: MAPBOX_CONFIG.dem.maxzoom,
      });
      map.setTerrain({ source: 'mapbox-dem', exaggeration: 0.9 });

      // Sky
      map.addLayer({
        id: 'sky',
        type: 'sky',
        paint: {
          'sky-type': 'atmosphere',
          'sky-atmosphere-sun': [0.0, 90.0],
          'sky-atmosphere-sun-intensity': 15,
        },
      });

      // AOI
      map.addSource('aoi-source', {
        type: 'geojson',
        data: {
          type: 'Feature',
          properties: {},
          geometry: { type: 'Polygon', coordinates: [reservaCochamoCoordinates] },
        },
      });

      map.addLayer({
        id: 'aoi-fill',
        type: 'fill',
        source: 'aoi-source',
        paint: { 'fill-color': '#06b6d4', 'fill-opacity': 0.12 },
      });

      map.addLayer({
        id: 'aoi-outline',
        type: 'line',
        source: 'aoi-source',
        paint: { 'line-color': '#06b6d4', 'line-width': 2.5, 'line-opacity': 0.8 },
      });

      // Río
      map.addSource('river-source', { type: 'geojson', data: riverGeoJSON });
      map.addLayer({
        id: 'river-layer',
        type: 'line',
        source: 'river-source',
        paint: { 'line-color': '#38bdf8', 'line-width': 3, 'line-opacity': 0.85 },
      });

      // 🌊 AGUA VECTORIAL (misma que funciona en el dashboard)
      console.log('[Tour360] 🔄 Cargando agua vectorial...');
      fetch(VECTOR_SOURCES.waterClassification)
        .then(res => res.json())
        .then(geojson => {
          console.log(`[Tour360] ✅ ${geojson.features.length} features de agua cargadas`);
          
          map.addSource('water-source', { type: 'geojson', data: geojson });

          // Las 3 clases (INVISIBLES al inicio)
          map.addLayer({
            id: 'water-class-3',
            type: 'fill',
            source: 'water-source',
            filter: ['==', ['get', 'class'], 3],
            paint: { 'fill-color': '#4ade80', 'fill-opacity': 0 }, // 🟢 VERDE para humedales
          });

          map.addLayer({
            id: 'water-class-2',
            type: 'fill',
            source: 'water-source',
            filter: ['==', ['get', 'class'], 2],
            paint: { 'fill-color': '#38bdf8', 'fill-opacity': 0 }, // 🔵 Azul medio para agua permanente
          });

          map.addLayer({
            id: 'water-class-1',
            type: 'fill',
            source: 'water-source',
            filter: ['==', ['get', 'class'], 1],
            paint: { 'fill-color': '#7dd3fc', 'fill-opacity': 0 }, // 🔵 Azul claro para agua estacional
          });

          console.log('[Tour360] ✅ Capas de agua listas (invisibles)');
        })
        .catch(err => {
          console.error('[Tour360] ❌ Error:', err);
          console.log('[Tour360] 🔄 Usando datos locales de fallback...');
          
          map.addSource('water-source', { type: 'geojson', data: waterClassificationGeoJSON });
          
          map.addLayer({
            id: 'water-class-3',
            type: 'fill',
            source: 'water-source',
            filter: ['==', ['get', 'class'], 3],
            paint: { 'fill-color': '#4ade80', 'fill-opacity': 0 },
          });
          
          map.addLayer({
            id: 'water-class-2',
            type: 'fill',
            source: 'water-source',
            filter: ['==', ['get', 'class'], 2],
            paint: { 'fill-color': '#38bdf8', 'fill-opacity': 0 },
          });
          
          map.addLayer({
            id: 'water-class-1',
            type: 'fill',
            source: 'water-source',
            filter: ['==', ['get', 'class'], 1],
            paint: { 'fill-color': '#7dd3fc', 'fill-opacity': 0 },
          });
          
          console.log('[Tour360] ✅ Fallback local cargado');
        });

      // 🔥 REMOVAL RISK (LSI) - TILES RASTER CON ESQUEMA TMS
      console.log('[Tour360] 🔄 Agregando capa LSI (Removal Risk - TMS)...');
      map.addSource('lsi-tiles', {
        type: 'raster',
        tiles: [TILE_SOURCES.lsi2025],
        tileSize: 256,
        scheme: 'tms', // ⚡ ESQUEMA TMS
        minzoom: 10,
        maxzoom: 14,
      });

      map.addLayer({
        id: 'lsi-layer',
        type: 'raster',
        source: 'lsi-tiles',
        paint: { 'raster-opacity': 0 }, // INVISIBLE al inicio
      });

      console.log('[Tour360] ✅ Capa LSI agregada (invisible al inicio, esquema TMS)');

      // ⛰️ SLOPE (PENDIENTE) - TILES RASTER CON ESQUEMA TMS
      console.log('[Tour360] 🔄 Agregando capa SLOPE (Pendiente - TMS)...');
      map.addSource('slope-tiles', {
        type: 'raster',
        tiles: ['https://data.lydarisdata.eu/tiles/tiles_SLOPE_5clases_visRGBA/{z}/{x}/{y}.png'],
        tileSize: 256,
        scheme: 'tms', // ⚡ ESQUEMA TMS
        minzoom: 10,
        maxzoom: 14,
      });

      map.addLayer({
        id: 'slope-layer',
        type: 'raster',
        source: 'slope-tiles',
        paint: { 'raster-opacity': 0 }, // INVISIBLE al inicio
      });

      console.log('[Tour360] ✅ Capa SLOPE agregada (invisible al inicio, esquema TMS)');

      // 🌿 VIGOR ECOSISTÉMICO (EV) - TILES RASTER CON ESQUEMA TMS
      console.log('[Tour360] 🔄 Agregando capa EV (Vigor Ecosistémico - TMS)...');
      map.addSource('ev-tiles', {
        type: 'raster',
        tiles: [TILE_SOURCES.ev2025],
        tileSize: 256,
        scheme: 'tms', // ⚡ ESQUEMA TMS
        minzoom: 10,
        maxzoom: 14,
      });

      map.addLayer({
        id: 'ev-layer',
        type: 'raster',
        source: 'ev-tiles',
        paint: { 'raster-opacity': 0 }, // INVISIBLE al inicio
      });

      console.log('[Tour360] ✅ Capa EV agregada (invisible al inicio, esquema TMS)');

      console.log('✅ Mapa listo con terreno 3D desde el inicio');
      
      // Forzar visibilidad del logo de Mapbox
      setTimeout(() => {
        const container = mapContainerRef.current;
        if (container) {
          const logo = container.querySelector('.mapboxgl-ctrl-logo');
          if (logo) {
            (logo as HTMLElement).style.display = 'block';
            (logo as HTMLElement).style.visibility = 'visible';
            (logo as HTMLElement).style.opacity = '1';
            console.log('✅ Logo de Mapbox visible');
          }
        }
      }, 200);
    });

    mapRef.current = map;

    return () => {
      map.remove();
      mapRef.current = null; // 🔧 CRÍTICO: Limpiar referencia para que se pueda crear nuevo mapa al reabrir
      if (typewriterRef.current) clearInterval(typewriterRef.current);
      cleanupAudio();
    };
  }, [isOpen]);

  // Ejecutar waypoint
  const executeWaypoint = (index: number) => {
    if (!mapRef.current || index < 0 || index >= WAYPOINTS.length) return;

    const wp = WAYPOINTS[index];
    const text = wp.text[currentLanguage];
    const audioText = wp.audioText ? wp.audioText[currentLanguage] : text; // 🎤 USAR AUDIO FONÉTICO SI EXISTE

    console.log(`🎬 Waypoint ${index}: ${text.substring(0, 50)}...`);
    if (wp.audioText) {
      console.log(`🎤 Audio fonético: ${audioText.substring(0, 50)}...`);
    }

    // Limpiar anterior
    if (typewriterRef.current) {
      clearInterval(typewriterRef.current);
      typewriterRef.current = null;
    }
    cleanupAudio();
    setDisplayText('');

    // 🎯 CALCULAR DURACIÓN ESTIMADA DEL AUDIO
    const charsPerSecond = currentLanguage === 'es' ? 12 : 14;
    const estimatedAudioDuration = (audioText.length / charsPerSecond) * 1000; // en milisegundos
    
    console.log(`⏱️ Duración estimada del audio: ${(estimatedAudioDuration / 1000).toFixed(1)}s (${audioText.length} caracteres)`);

    // 🎬 FUNCIÓN PARA INICIAR TRANSICIÓN DE CÁMARA AL SIGUIENTE WAYPOINT
    const startCameraTransition = () => {
      const nextIndex = index + 1;
      if (nextIndex >= WAYPOINTS.length || !mapRef.current) {
        console.log('🏁 Tour completado (último waypoint)');
        
        // 🚁 EJECUTAR ALEJAMIENTO FINAL si estamos en WP10
        if (index === 10 && mapRef.current) {
          console.log('🚁 Ejecutando alejamiento épico final (12s)');
          mapRef.current.easeTo({
            center: [-72.217, -41.425],
            bearing: 0,
            pitch: 45,
            zoom: 11.5,
            duration: 12000,
            easing: (t) => 1 - Math.pow(1 - t, 3)
          });
          
          // 🎬 TOUR FINALIZADO - Se queda en el espacio (sin cerrar automáticamente)
          console.log('🏁 Tour finalizado - Permanece en el espacio para que el cliente pueda verlo de nuevo');
        }
        
        return;
      }

      const nextWp = WAYPOINTS[nextIndex];
      const transitionDuration = (nextWp.time - wp.time) * 1000 - estimatedAudioDuration;
      
      console.log(`🎬 Iniciando transición de cámara al waypoint ${nextIndex} (duración: ${(transitionDuration / 1000).toFixed(1)}s)`);

      // 🎯 ACTUALIZAR WAYPOINT INDEX INMEDIATAMENTE
      setCurrentWaypointIndex(nextIndex);

      // 🎬 INICIAR GIRO DE CÁMARA
      mapRef.current.easeTo({
        center: nextWp.camera.center,
        bearing: nextWp.camera.bearing,
        pitch: nextWp.camera.pitch,
        zoom: nextWp.camera.zoom,
        duration: transitionDuration * 1.8, // 🎯 80% más lento para giro MÁS suave
        easing: (t) => t * t * (3 - 2 * t), // 🎯 SMOOTHSTEP (suave todo el recorrido)
      });

      // 🎤 EJECUTAR SIGUIENTE WAYPOINT INMEDIATAMENTE (audio + texto mientras gira)
      setTimeout(() => {
        executeWaypoint(nextIndex);
      }, 50); // Delay reducido para transición más fluida
    };

    // Audio con sincronización
    if (!isMuted) {
      const utterance = new SpeechSynthesisUtterance(audioText);
      utterance.lang = currentLanguage === 'es' ? 'es-ES' : 'en-US';
      utterance.rate = 0.9;
      utterance.pitch = 1.0;
      utterance.volume = 1.0;

      // Seleccionar voz específica según idioma
      if (availableVoices.length > 0) {
        let selectedVoice: SpeechSynthesisVoice | undefined;
        
        if (currentLanguage === 'es') {
          selectedVoice = availableVoices.find(v => v.name.includes('Sabina')) ||
                         availableVoices.find(v => v.name.includes('Google español') && v.lang === 'es-ES') ||
                         availableVoices.find(v => v.lang.startsWith('es'));
          console.log('🔊 Voz seleccionada ES (Tour360):', selectedVoice?.name || 'predeterminada');
        } else {
          selectedVoice = availableVoices.find(v => v.name.includes('Google UK English Female')) ||
                         availableVoices.find(v => v.name.includes('Female') && v.lang.startsWith('en')) ||
                         availableVoices.find(v => v.name.includes('Google US English')) ||
                         availableVoices.find(v => v.lang.startsWith('en'));
          console.log('🔊 Voz seleccionada EN (Tour360):', selectedVoice?.name || 'predeterminada');
        }
        
        if (selectedVoice) {
          utterance.voice = selectedVoice;
        }
      }

      // 🎯 EVENTO: Cuando el audio EMPIEZA, iniciar typewriter sincronizado
      utterance.onstart = () => {
        console.log('🎤 Audio iniciado, comenzando typewriter sincronizado...');
        
        const chars = text.split('');
        const delay = (estimatedAudioDuration / chars.length) / 1.5; // ⚡ ACELERADO 1.5x para que el texto aparezca más rápido
        let i = 0;

        typewriterRef.current = window.setInterval(() => {
          if (i < chars.length) {
            setDisplayText(chars.slice(0, i + 1).join(''));
            i++;
          } else {
            if (typewriterRef.current) {
              clearInterval(typewriterRef.current);
              typewriterRef.current = null;
            }
          }
        }, delay);
      };

      // 🎯 EVENTO: Cuando el audio TERMINA → INICIAR TRANSICIÓN DE CÁMARA INMEDIATAMENTE
      utterance.onend = () => {
        console.log('🎤 Audio terminado → Iniciando transición de cámara');
        setDisplayText(text);
        if (typewriterRef.current) {
          clearInterval(typewriterRef.current);
          typewriterRef.current = null;
        }
        
        // 🎬 INICIAR TRANSICIÓN DE CÁMARA INMEDIATAMENTE
        startCameraTransition();
      };

      // 🎯 EVENTO: Si hay error en el audio
      utterance.onerror = (event) => {
        console.warn('⚠️ Error en audio (ignorado, completando texto):', event.error || 'unknown');
        
        const chars = text.split('');
        const delay = estimatedAudioDuration / chars.length;
        let i = 0;

        if (typewriterRef.current) {
          clearInterval(typewriterRef.current);
        }

        typewriterRef.current = window.setInterval(() => {
          if (i < chars.length) {
            setDisplayText(chars.slice(0, i + 1).join(''));
            i++;
          } else {
            if (typewriterRef.current) {
              clearInterval(typewriterRef.current);
              typewriterRef.current = null;
            }
            // 🎬 INICIAR TRANSICIÓN DESPUÉS DEL TYPEWRITER
            startCameraTransition();
          }
        }, delay);
      };

      // 🔊 HABLAR CON MANEJO DE ERRORES Y OPTIMIZACIÓN DE LATENCIA
      try {
        cleanupAudio();
        
        // 🚀 OPTIMIZACIÓN: Asegurar que el motor esté limpio antes de hablar
        window.speechSynthesis.cancel();
        
        // Iniciar reproducción inmediatamente
        window.speechSynthesis.speak(utterance);
        currentUtteranceRef.current = utterance;
      } catch (error) {
        console.warn('⚠️ Error iniciando audio (usando fallback mudo):', error);
        
        const chars = text.split('');
        const delay = estimatedAudioDuration / chars.length;
        let i = 0;

        typewriterRef.current = window.setInterval(() => {
          if (i < chars.length) {
            setDisplayText(chars.slice(0, i + 1).join(''));
            i++;
          } else {
            if (typewriterRef.current) {
              clearInterval(typewriterRef.current);
              typewriterRef.current = null;
            }
            // 🎬 INICIAR TRANSICIÓN DESPUÉS DEL TYPEWRITER
            startCameraTransition();
          }
        }, delay);
      }
    } else {
      // 🔇 Si está en mudo, usar la duración estimada
      console.log('🔇 Modo mudo: usando duración estimada para typewriter');
      const chars = text.split('');
      const delay = estimatedAudioDuration / chars.length;
      let i = 0;

      typewriterRef.current = window.setInterval(() => {
        if (i < chars.length) {
          setDisplayText(chars.slice(0, i + 1).join(''));
          i++;
        } else {
          if (typewriterRef.current) {
            clearInterval(typewriterRef.current);
            typewriterRef.current = null;
          }
          // 🎬 INICIAR TRANSICIÓN DESPUÉS DEL TYPEWRITER
          startCameraTransition();
        }
      }, delay);
    }

    // 🌊 ACTIVAR CAPA DE AGUA EN WAYPOINT 2 (Análisis Hídrico)
    if (index === 2) {
      console.log('🌊 Activando agua vectorial - Waypoint 2');
      
      // Activar después de un pequeño delay para asegurar que las capas están cargadas
      setTimeout(() => {
        if (!mapRef.current || !mapRef.current.getStyle()) {
          console.warn('⏳ Mapa o estilo no disponible, omitiendo activación de agua');
          return;
        }

        try {
          const c1 = mapRef.current.getLayer('water-class-1');
          const c2 = mapRef.current.getLayer('water-class-2');
          const c3 = mapRef.current.getLayer('water-class-3');
          
          if (c1 && c2 && c3) {
            mapRef.current.setPaintProperty('water-class-1', 'fill-opacity', 0.5);
            mapRef.current.setPaintProperty('water-class-2', 'fill-opacity', 0.65);
            mapRef.current.setPaintProperty('water-class-3', 'fill-opacity', 0.8);
            console.log('✅ AGUA ACTIVADA: Clase 1=0.5, Clase 2=0.65, Clase 3=0.8');
          } else {
            console.warn('⏳ Capas de agua aún cargando...');
          }
        } catch (error) {
          console.warn('⚠️ Error activando agua:', error);
        }
      }, 500);
    }

    // 🎬 MOVIMIENTO DE CÁMARA ESPECIAL DURANTE WP 0 (SUBIDA GRADUAL)
    if (index === 0) {
      console.log('🎬 WP 0: Iniciando movimiento de \"subida\" durante el audio (zoom 12.3 → 12.0)');
      
      // Esperar un poco para que el audio y el mapa estén listos
      setTimeout(() => {
        if (!mapRef.current) return;
        
        // Movimiento de cámara: SUBE durante el audio (zoom disminuye ligeramente, pitch disminuye)
        mapRef.current.easeTo({
          center: [-72.217, -41.416], // 🎬 MISMO CENTER QUE WP 0
          bearing: 0,
          pitch: 28, // 🎬 SUBE POCO: de 30° a 28°
          zoom: 12.0, // 🎬 SE ALEJA POCO: de 12.3 a 12.0
          duration: estimatedAudioDuration, // Dura lo mismo que el audio
          easing: (t) => t, // LINEAR para que sea suave
        });
        
        console.log(`🎬 WP 0: Movimiento de subida iniciado (duración: ${(estimatedAudioDuration / 1000).toFixed(1)}s)`);
      }, 500);
    }

    // 🎬 MOVIMIENTO CINEMATOGRÁFICO DURANTE WP 1: Transición suave hacia posición final
    if (index === 1) {
      console.log('🎬 WP 1: Movimiento cinematográfico suave hacia posición de enfoque');
      
      setTimeout(() => {
        if (!mapRef.current) return;
        
        // Calcular duración del audio
        const audioText = wp.audioText ? wp.audioText[currentLanguage] : wp.text[currentLanguage];
        const charsPerSecond = currentLanguage === 'es' ? 12 : 14;
        const estimatedAudioDuration = (audioText.length / charsPerSecond) * 1000;
        
        // Movimiento gradual hacia posición final durante todo el audio
        // Movimiento gradual hacia posición final durante todo el audio
        mapRef.current.easeTo({
          center: [-72.218, -41.425], // 🎬 Movimiento hacia el sur (enfoque en la reserva)
          bearing: 15, // 🎬 Giro suave hacia el este
          pitch: 29, // 🎬 Ligero ajuste de pitch
          zoom: 12.4, // 🎬 Acercamiento gradual
          duration: estimatedAudioDuration,
          easing: (t) => t * t * (3 - 2 * t), // SMOOTHSTEP (muy suave)
        });
        
        console.log(`🎬 WP 1: Movimiento suave iniciado (duración: ${(estimatedAudioDuration / 1000).toFixed(1)}s)`);
        
      }, 100); // 🔧 DELAY REDUCIDO: 100ms para eliminar "corta circuito" en inicio de WP1
    }

    // 🏔️ MOVIMIENTO CINEMATOGRÁFICO DURANTE WP 3 (ALTITUD): Enfatizar elevación del terreno
    if (index === 3) {
      console.log('🏔️ WP 3 (ALTITUD): Movimiento cinematográfico de elevación (pitch bajo → alto)');
      
      setTimeout(() => {
        if (!mapRef.current) return;
        
        // Calcular duración del audio
        const audioText = wp.audioText ? wp.audioText[currentLanguage] : wp.text[currentLanguage];
        const charsPerSecond = currentLanguage === 'es' ? 12 : 14;
        const estimatedAudioDuration = (audioText.length / charsPerSecond) * 1000;
        
        // Movimiento de elevación: pitch aumenta gradualmente para enfatizar la altitud
        mapRef.current.easeTo({
          center: [-72.235, -41.432],
          bearing: 110,
          pitch: 55, // 🏔️ AUMENTAR PITCH: de 32° a 55° (MÁS DRAMÁTICO para enfatizar elevación)
          zoom: 12.8, // 🏔️ ACERCAR MÁS: de 12.6 a 12.8 (mucho mejor visualización del relieve)
          duration: estimatedAudioDuration,
          easing: (t) => 1 - Math.pow(1 - t, 3), // EASE OUT CUBIC (desaceleración suave)
        });
        
        console.log(`🏔️ WP 3: Movimiento de elevación iniciado (bearing 80°→110°, pitch 32°→55°, zoom 12.6→12.8, duración: ${(estimatedAudioDuration / 1000).toFixed(1)}s)`);
      }, 800);
    }

    // 🌿 MOVIMIENTO CINEMATOGRÁFICO DURANTE WP 4 (ECO-STRUCTURAL): Giro panorámico prolongado
    if (index === 4) {
      console.log('🌿 WP 4 (ECO-STRUCTURAL): Activando capa EV (Vigor Ecosistémico)');
      
      // 🌿 ACTIVAR CAPA EV (Vigor Ecosistémico)
      setTimeout(() => {
        if (!mapRef.current || !mapRef.current.getStyle()) {
          console.warn('⏳ Mapa o estilo no disponible, omitiendo activación de EV');
          return;
        }

        try {
          const evLayer = mapRef.current.getLayer('ev-layer');
          const c1 = mapRef.current.getLayer('water-class-1');
          const c2 = mapRef.current.getLayer('water-class-2');
          const c3 = mapRef.current.getLayer('water-class-3');
          
          // 🚫 OCULTAR TODAS LAS CAPAS DE AGUA
          if (c1 && c2 && c3) {
            mapRef.current.setPaintProperty('water-class-1', 'fill-opacity', 0);
            mapRef.current.setPaintProperty('water-class-2', 'fill-opacity', 0);
            mapRef.current.setPaintProperty('water-class-3', 'fill-opacity', 0);
            console.log('✅ CAPAS DE AGUA OCULTAS para mostrar EV');
          }
          
          // 🌿 ACTIVAR EV
          if (evLayer) {
            mapRef.current.setPaintProperty('ev-layer', 'raster-opacity', 0.7);
            console.log('✅ CAPA EV ACTIVADA: opacidad 0.7');
          } else {
            console.warn('⏳ Capa EV aún cargando...');
          }
        } catch (error) {
          console.warn('⚠️ Error activando EV:', error);
        }
      }, 500);
      
      console.log('🌿 WP 4 (ECO-STRUCTURAL): Movimiento cinematográfico de giro panorámico');
      
      setTimeout(() => {
        if (!mapRef.current) return;
        
        // Calcular duración del audio
        const audioText = wp.audioText ? wp.audioText[currentLanguage] : wp.text[currentLanguage];
        const charsPerSecond = currentLanguage === 'es' ? 12 : 14;
        const estimatedAudioDuration = (audioText.length / charsPerSecond) * 1000;
        
        // Movimiento panorámico: bearing cambia gradualmente para mostrar continuidad del paisaje
        mapRef.current.easeTo({
          center: [-72.228, -41.423], // 🌿 CENTRO LIGERAMENTE AJUSTADO
          bearing: 85, // 🌿 GIRO PANORÁMICO SUAVE: de 105° a 85° (-20°)
          pitch: 40, // 🌿 PITCH SUAVE: de 52° a 40° (-12°)
          zoom: 12.7, // 🌿 ZOOM SUAVE: de 12.8 a 12.7 (-0.1)
          duration: estimatedAudioDuration,
          easing: (t) => 1 - Math.pow(1 - t, 3), // EASE OUT CUBIC (desaceleración suave)
        });
        
        console.log(`🌿 WP 4: Movimiento panorámico iniciado (bearing 105°→85°, pitch 52°→40°, zoom 12.8→12.7, duración: ${(estimatedAudioDuration / 1000).toFixed(1)}s)`);
      }, 800);
    }

    // ⛰️ ACTIVAR CAPA SLOPE EN WAYPOINT 5 (Geomorfología)
    if (index === 5) {
      console.log('⛰️ Activando capa SLOPE (Pendiente) - Waypoint 5');
      
      setTimeout(() => {
        if (!mapRef.current || !mapRef.current.getStyle()) {
          console.warn('⏳ Mapa o estilo no disponible, omitiendo activación de SLOPE');
          return;
        }

        try {
          const slopeLayer = mapRef.current.getLayer('slope-layer');
          const evLayer = mapRef.current.getLayer('ev-layer');
          const c1 = mapRef.current.getLayer('water-class-1');
          const c2 = mapRef.current.getLayer('water-class-2');
          const c3 = mapRef.current.getLayer('water-class-3');
          
          // 🚫 OCULTAR TODAS LAS CAPAS (EV + AGUA)
          if (evLayer) {
            mapRef.current.setPaintProperty('ev-layer', 'raster-opacity', 0);
            console.log('✅ CAPA EV OCULTA para mostrar SLOPE');
          }
          
          if (c1 && c2 && c3) {
            mapRef.current.setPaintProperty('water-class-1', 'fill-opacity', 0);
            mapRef.current.setPaintProperty('water-class-2', 'fill-opacity', 0);
            mapRef.current.setPaintProperty('water-class-3', 'fill-opacity', 0);
            console.log('✅ CAPAS DE AGUA OCULTAS para mostrar SLOPE');
          }
          
          // ⛰️ ACTIVAR SLOPE
          if (slopeLayer) {
            mapRef.current.setPaintProperty('slope-layer', 'raster-opacity', 0.65);
            console.log('✅ CAPA SLOPE ACTIVADA: opacidad 0.65');
          } else {
            console.warn('⏳ Capa SLOPE aún cargando...');
          }
        } catch (error) {
          console.warn('⚠️ Error activando SLOPE:', error);
        }
      }, 600);

      // 🎬 MOVIMIENTO CINEMATOGRÁFICO DURANTE WP 5: Acercar y luego alejarse suavemente
      console.log('🎬 WP 5 (SLOPE): Movimiento cinematográfico (acercar → alejar para transición)');
      
      setTimeout(() => {
        if (!mapRef.current) return;
        
        // Calcular duración del audio
        const audioText = wp.audioText ? wp.audioText[currentLanguage] : wp.text[currentLanguage];
        const charsPerSecond = currentLanguage === 'es' ? 12 : 14;
        const estimatedAudioDuration = (audioText.length / charsPerSecond) * 1000;
        
        // FASE 1: Acercarse más durante los primeros 55% del audio (enfatizar pendientes) - MÁS LENTO
        const phase1Duration = estimatedAudioDuration * 0.55;
        
        mapRef.current.easeTo({
          center: [-72.225, -41.420],
          bearing: 40, // 🎬 GIRO MÁS SUAVE: de 85° a 40° (45° en lugar de 50°)
          pitch: 46, // 🎬 PITCH MÁS SUAVE: de 40° a 46° (6° en lugar de 8°)
          zoom: 13.0, // 🎬 ACERCAMIENTO MÁS SUAVE a 13.0 (en lugar de 13.1)
          duration: phase1Duration,
          easing: (t) => t * t * (3 - 2 * t), // SMOOTHSTEP (muy suave, sin aceleraciones bruscas)
        });
        
        console.log(`🎬 WP 5 FASE 1: Acercamiento suave (bearing 85°→40°, pitch 40°→46°, zoom 12.7→13.0, duración: ${(phase1Duration / 1000).toFixed(1)}s)`);
        
        // FASE 2: Alejarse suavemente durante los últimos 45% del audio (preparar transición) - MÁS LENTO
        setTimeout(() => {
          if (!mapRef.current) return;
          
          const phase2Duration = estimatedAudioDuration * 0.45;
          
          mapRef.current.easeTo({
            center: [-72.222, -41.419], // 🎬 Centro ajustado para transición
            bearing: 30, // 🎬 Bearing más gradual (40°→30° en lugar de 25°)
            pitch: 38, // 🎬 Pitch más gradual (46°→38°)
            zoom: 12.6, // 🎬 ALEJAMIENTO MÁS SUAVE a 12.6 (en lugar de 12.5)
            duration: phase2Duration,
            easing: (t) => t * t * (3 - 2 * t), // SMOOTHSTEP (muy suave, sin aceleraciones bruscas)
          });
          
          console.log(`🎬 WP 5 FASE 2: Alejamiento suave (bearing 40°→30°, pitch 46°→38°, zoom 13.0→12.6, duración: ${(phase2Duration / 1000).toFixed(1)}s)`);
        }, phase1Duration);
        
      }, 1000); // Delay aumentado a 1s para dar tiempo a que la capa se active completamente
    }

    // 🔥 ACTIVAR CAPA LSI EN WAYPOINT 6 (Eventos Hidrometeorológicos / Removal Risk)
    if (index === 6) {
      console.log('🔥 Activando capa LSI (Removal Risk) - Waypoint 6');
      
      setTimeout(() => {
        if (!mapRef.current || !mapRef.current.getStyle()) {
          console.warn('⏳ Mapa o estilo no disponible, omitiendo activación de LSI');
          return;
        }

        try {
          const lsiLayer = mapRef.current.getLayer('lsi-layer');
          const slopeLayer = mapRef.current.getLayer('slope-layer');
          const c1 = mapRef.current.getLayer('water-class-1');
          const c2 = mapRef.current.getLayer('water-class-2');
          const c3 = mapRef.current.getLayer('water-class-3');
          
          // 🚫 OCULTAR TODAS LAS CAPAS (SLOPE + AGUA)
          if (slopeLayer) {
            mapRef.current.setPaintProperty('slope-layer', 'raster-opacity', 0);
            console.log('✅ CAPA SLOPE OCULTA para mostrar LSI');
          }
          
          if (c1 && c2 && c3) {
            mapRef.current.setPaintProperty('water-class-1', 'fill-opacity', 0);
            mapRef.current.setPaintProperty('water-class-2', 'fill-opacity', 0);
            mapRef.current.setPaintProperty('water-class-3', 'fill-opacity', 0);
            console.log('✅ CAPAS DE AGUA OCULTAS para mostrar LSI');
          }
          
          // 🔥 ACTIVAR LSI CON COLORES ATENUADOS (opacidad 0.55)
          if (lsiLayer) {
            mapRef.current.setPaintProperty('lsi-layer', 'raster-opacity', 0.55);
            console.log('✅ CAPA LSI ACTIVADA: opacidad 0.55 (colores atenuados)');
          } else {
            console.warn('⏳ Capa LSI aún cargando...');
          }
        } catch (error) {
          console.warn('⚠️ Error activando LSI:', error);
        }
      }, 800);

      // 🎬 MOVIMIENTO CINEMATOGRÁFICO DURANTE WP 6: Giro suave hacia el norte
      console.log('🎬 WP 6 (LSI): Movimiento cinematográfico suave hacia el norte');
      
      setTimeout(() => {
        if (!mapRef.current) return;
        
        // Calcular duración del audio
        const audioText = wp.audioText ? wp.audioText[currentLanguage] : wp.text[currentLanguage];
        const charsPerSecond = currentLanguage === 'es' ? 12 : 14;
        const estimatedAudioDuration = (audioText.length / charsPerSecond) * 1000;
        
        // Movimiento gradual hacia el norte durante todo el audio
        mapRef.current.easeTo({
          center: [-72.217, -41.418],
          bearing: 0, // 🎬 GIRO SUAVE: de 28° a 0° (giro gradual hacia el norte)
          pitch: 35, // 🎬 PITCH SUAVE: de 37° a 35° (ligera reducción)
          zoom: 12.6, // 🎬 Mantener zoom
          duration: estimatedAudioDuration,
          easing: (t) => t * t * (3 - 2 * t), // SMOOTHSTEP (muy suave)
        });
        
        console.log(`🎬 WP 6: Giro suave hacia el norte (bearing 28°→0°, pitch 37°→35°, duración: ${(estimatedAudioDuration / 1000).toFixed(1)}s)`);
        
      }, 1200); // Delay de 1.2s para que la capa se active completamente
    }

    // 🔄 DESACTIVAR CAPA LSI EN WAYPOINT 7 (Último texto - Exploración)
    if (index === 7) {
      console.log('🔄 MANTENER LSI activa - Waypoint 7 (Exploración)');
      // 🔥 No hacer nada - mantener LSI activa desde WP 6
    }

    // 🌊 MOSTRAR SOLO CAPAS DE AGUA EN WAYPOINT 8 - OCULTAR LSI
    if (index === 8) {
      console.log('🌊 WP8: Mostrando SOLO capas de agua (desactivando LSI)');
      
      setTimeout(() => {
        if (!mapRef.current || !mapRef.current.getStyle()) {
          console.warn('⏳ Mapa o estilo no disponible, omitiendo cambio de capas');
          return;
        }

        try {
          const lsiLayer = mapRef.current.getLayer('lsi-layer');
          const c1 = mapRef.current.getLayer('water-class-1');
          const c2 = mapRef.current.getLayer('water-class-2');
          const c3 = mapRef.current.getLayer('water-class-3');
          
          // 🚫 DESACTIVAR LSI
          if (lsiLayer) {
            mapRef.current.setPaintProperty('lsi-layer', 'raster-opacity', 0);
            console.log('✅ CAPA LSI DESACTIVADA');
          }
          
          // 🌊 ACTIVAR TODAS LAS CAPAS DE AGUA
          if (c1 && c2 && c3) {
            mapRef.current.setPaintProperty('water-class-1', 'fill-opacity', 0.5); // 🔵 Agua estacional
            mapRef.current.setPaintProperty('water-class-2', 'fill-opacity', 0.65); // 🔵 Agua permanente
            mapRef.current.setPaintProperty('water-class-3', 'fill-opacity', 0.8); // 🟢 Humedales
            console.log('✅ CAPAS DE AGUA ACTIVADAS: Clase 1=0.5, Clase 2=0.65, Clase 3=0.8');
          }
        } catch (error) {
          console.warn('⚠️ Error cambiando capas:', error);
        }
      }, 500);
    }

    // 🛰️ EFECTO ESPECIAL "DESCARGA DESDE EL SATÉLITE" EN WAYPOINT 9 ("Likewise...")
    if (index === 9) {
      console.log('🛰️ WP9 (LIKEWISE - Enumeración de capas): Activando efecto de "capas descendiendo desde el satélite"');
      
      // PASO 1: OCULTAR TODAS LAS CAPAS INMEDIATAMENTE
      setTimeout(() => {
        if (!mapRef.current || !mapRef.current.getStyle()) {
          console.warn('⏳ Mapa o estilo no disponible, omitiendo efecto de capas satelitales');
          return;
        }

        try {
          // 🚫 OCULTAR TODAS LAS CAPAS PRIMERO (ya están ocultas desde WP8, pero por seguridad)
          const c1 = mapRef.current.getLayer('water-class-1');
          const c2 = mapRef.current.getLayer('water-class-2');
          const c3 = mapRef.current.getLayer('water-class-3');
          const lsiLayer = mapRef.current.getLayer('lsi-layer');
          const slopeLayer = mapRef.current.getLayer('slope-layer');
          const evLayer = mapRef.current.getLayer('ev-layer');
          
          if (c1 && c2 && c3) {
            mapRef.current.setPaintProperty('water-class-1', 'fill-opacity', 0);
            mapRef.current.setPaintProperty('water-class-2', 'fill-opacity', 0);
            mapRef.current.setPaintProperty('water-class-3', 'fill-opacity', 0);
          }
          if (lsiLayer) mapRef.current.setPaintProperty('lsi-layer', 'raster-opacity', 0);
          if (slopeLayer) mapRef.current.setPaintProperty('slope-layer', 'raster-opacity', 0);
          if (evLayer) mapRef.current.setPaintProperty('ev-layer', 'raster-opacity', 0);
          
          console.log('🚫 Todas las capas ocultas - Preparando descenso satelital...');

          // 🎯 FUNCIÓN HELPER: Materialización Holográfica - Raster Layers
          const animateRasterDescent = (layerId: string, finalOpacity: number) => {
            const layer = mapRef.current?.getLayer(layerId);
            if (!layer || !mapRef.current) return;
            const steps = 90;
            let currentStep = 0;
            const startZoom = mapRef.current.getZoom();
            const targetZoom = startZoom + 0.10;
            const animate = () => {
              if (!mapRef.current || currentStep >= steps) {
                if (mapRef.current && mapRef.current.getLayer(layerId)) {
                  mapRef.current.setPaintProperty(layerId, 'raster-saturation', 0);
                  mapRef.current.setPaintProperty(layerId, 'raster-contrast', 0);
                }
                return;
              }
              const progress = currentStep / steps;
              const easeProgress = progress < 0.5 ? 2 * progress * progress : 1 - Math.pow(-2 * progress + 2, 2) / 2;
              const currentOpacity = finalOpacity * easeProgress;
              mapRef.current.setPaintProperty(layerId, 'raster-opacity', currentOpacity);
              const saturation = -0.8 + (0.8 * easeProgress);
              const contrast = 0.4 * (1 - easeProgress);
              mapRef.current.setPaintProperty(layerId, 'raster-saturation', saturation);
              mapRef.current.setPaintProperty(layerId, 'raster-contrast', contrast);
              const currentZoom = startZoom + (targetZoom - startZoom) * easeProgress;
              mapRef.current.setZoom(currentZoom);
              currentStep++;
              if (currentStep < steps) requestAnimationFrame(animate);
            };
            animate();
          };

          // 🎯 FUNCIÓN HELPER: Materialización Holográfica - Vector Layers
          const animateVectorDescent = (layerIds: string[], finalOpacities: number[]) => {
            const steps = 90;
            let currentStep = 0;
            const startZoom = mapRef.current?.getZoom() || 12.2;
            const targetZoom = startZoom + 0.10;
            const animate = () => {
              if (!mapRef.current || currentStep >= steps) return;
              const progress = currentStep / steps;
              const easeProgress = progress < 0.5 ? 2 * progress * progress : 1 - Math.pow(-2 * progress + 2, 2) / 2;
              layerIds.forEach((layerId, idx) => {
                const layer = mapRef.current?.getLayer(layerId);
                if (layer) {
                  const currentOpacity = finalOpacities[idx] * easeProgress;
                  mapRef.current.setPaintProperty(layerId, 'fill-opacity', currentOpacity);
                }
              });
              const currentZoom = startZoom + (targetZoom - startZoom) * easeProgress;
              mapRef.current.setZoom(currentZoom);
              currentStep++;
              if (currentStep < steps) requestAnimationFrame(animate);
            };
            animate();
          };

          // FUNCIÓN HELPER: Ocultar capa
          const hideLayer = (layerId: string, isVector: boolean = false) => {
            const layer = mapRef.current?.getLayer(layerId);
            if (!layer || !mapRef.current) return;
            const opacityProp = isVector ? 'fill-opacity' : 'raster-opacity';
            mapRef.current.setPaintProperty(layerId, opacityProp, 0);
          };

          // PASO 2: SECUENCIA - UNA CAPA A LA VEZ
          setTimeout(() => {
            console.log('🛰️ Descenso: VIGOR ECOSISTÉMICO');
            animateRasterDescent('ev-layer', 0.70);
          }, 1000);

          setTimeout(() => {
            hideLayer('ev-layer');
            console.log('🛰️ Descenso: PENDIENTES');
            animateRasterDescent('slope-layer', 0.65);
          }, 3800);

          setTimeout(() => {
            hideLayer('slope-layer');
            console.log('🛰️ Descenso: AGUA');
            animateVectorDescent(['water-class-1', 'water-class-2', 'water-class-3'], [0.50, 0.65, 0.80]);
          }, 6600);

          setTimeout(() => {
            hideLayer('water-class-1', true);
            hideLayer('water-class-2', true);
            hideLayer('water-class-3', true);
            console.log('🛰️ Descenso: RIESGO');
            animateRasterDescent('lsi-layer', 0.60);
          }, 9400);

          console.log('🛰️ Secuencia satelital iniciada');
          
        } catch (error) {
          console.warn('⚠️ Error en efecto de capas satelitales:', error);
        }
      }, 500); // Delay inicial de 500ms
    }

    if (index === 10) {
      console.log('🎬 WP10 (WELCOME): Preparando alejamiento final (se ejecutará después del audio)');
      
      setTimeout(() => {
        if (!mapRef.current) return;
        
        try {
          // NO OCULTAR lsi-layer - debe seguir visible desde WP9
          const layersToHide = ['ev-layer', 'slope-layer', 'water-class-1', 'water-class-2', 'water-class-3'];
          layersToHide.forEach(layerId => {
            const layer = mapRef.current?.getLayer(layerId);
            if (layer) {
              const isVector = layerId.includes('water');
              const prop = isVector ? 'fill-opacity' : 'raster-opacity';
              mapRef.current.setPaintProperty(layerId, prop, 0);
            }
          });
          
          console.log('✅ Capas limpias (riesgo permanece visible)');
          console.log('⏳ Alejamiento final se ejecutará cuando termine el audio...');
          
        } catch (error) {
          console.warn('⚠️ Error WP10:', error);
        }
      }, 200);
    }
  };



  // Detectar cambio de waypoint
  useEffect(() => {
    // 🚫 YA NO NECESITAMOS ESTE EFECTO - El flujo ahora es:
    // executeWaypoint() → audio termina → startCameraTransition() → executeWaypoint(nextIndex)
    // Solo se usa para el INICIO del tour
    if (!isPlaying || !mapRef.current) return;
    
    // Solo ejecutar en el INICIO (cuando se presiona Play por primera vez)
    if (currentTime === 0 && currentWaypointIndex === -1) {
      console.log('🚀 INICIO DEL TOUR: Ejecutando waypoint 0');
      setCurrentWaypointIndex(0);
      executeWaypoint(0); // 🚀 INICIO INMEDIATO: Sin delay para reducir latencia de audio
    }
  }, [isPlaying]); // 🔧 Dependencia reducida - solo isPlaying

  // Loop de tiempo
  useEffect(() => {
    if (!isPlaying) {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
        animationRef.current = null;
      }
      startTimeRef.current = null;
      window.speechSynthesis?.pause();
      if (typewriterRef.current) {
        clearInterval(typewriterRef.current);
        typewriterRef.current = null;
      }
      return;
    }

    // INICIO INMEDIATO: Si es la primera vez que se reproduce
    if (currentTime === 0 && currentWaypointIndex === -1) {
      console.log('🚀 INICIO: Ejecutando waypoint 0 inmediatamente');
      setCurrentWaypointIndex(0);
      executeWaypoint(0); // 🚀 INICIO INMEDIATO: Sin delay para reducir latencia de audio
    }

    window.speechSynthesis?.resume();

    const animate = (timestamp: number) => {
      if (!startTimeRef.current) {
        startTimeRef.current = timestamp - currentTime * 1000;
      }

      const elapsed = (timestamp - startTimeRef.current) / 1000;

      if (elapsed >= TOTAL_DURATION) {
        setCurrentTime(TOTAL_DURATION);
        setIsPlaying(false);
        return;
      }

      setCurrentTime(elapsed);
      animationRef.current = requestAnimationFrame(animate);
    };

    animationRef.current = requestAnimationFrame(animate);

    return () => {
      if (animationRef.current) cancelAnimationFrame(animationRef.current);
    };
  }, [isPlaying, currentTime, currentWaypointIndex]);

  const handleReset = () => {
    setCurrentTime(0);
    setIsPlaying(false);
    setCurrentWaypointIndex(-1);
    setDisplayText('');
    startTimeRef.current = null;
    cleanupAudio();
    if (typewriterRef.current) {
      clearInterval(typewriterRef.current);
      typewriterRef.current = null;
    }

    // 🔄 RESETEAR CAPAS DE AGUA A INVISIBLE
    if (mapRef.current && mapRef.current.getStyle()) {
      try {
        const c1 = mapRef.current.getLayer('water-class-1');
        const c2 = mapRef.current.getLayer('water-class-2');
        const c3 = mapRef.current.getLayer('water-class-3');
        const lsi = mapRef.current.getLayer('lsi-layer');
        const slope = mapRef.current.getLayer('slope-layer');
        const ev = mapRef.current.getLayer('ev-layer');
        
        if (c1 && c2 && c3) {
          mapRef.current.setPaintProperty('water-class-1', 'fill-opacity', 0);
          mapRef.current.setPaintProperty('water-class-2', 'fill-opacity', 0);
          mapRef.current.setPaintProperty('water-class-3', 'fill-opacity', 0);
          console.log('🔄 Capas de agua reseteadas (opacidad 0)');
        }

        if (lsi) {
          mapRef.current.setPaintProperty('lsi-layer', 'raster-opacity', 0);
          console.log('🔄 Capa LSI reseteada (opacidad 0)');
        }

        if (slope) {
          mapRef.current.setPaintProperty('slope-layer', 'raster-opacity', 0);
          console.log('🔄 Capa SLOPE reseteada (opacidad 0)');
        }

        if (ev) {
          mapRef.current.setPaintProperty('ev-layer', 'raster-opacity', 0);
          console.log('🔄 Capa EV reseteada (opacidad 0)');
        }

        // Volver a la cámara inicial
        mapRef.current.jumpTo({
          center: WAYPOINTS[0].camera.center,
          bearing: WAYPOINTS[0].camera.bearing,
          pitch: WAYPOINTS[0].camera.pitch,
          zoom: WAYPOINTS[0].camera.zoom,
        });
        console.log('🔄 Cámara reseteada a waypoint 0');
      } catch (error) {
        console.log('⚠️ Mapa ya destruido, omitiendo reset visual');
      }
    }
  };

  const handleClose = () => {
    handleReset();
    onClose();
  };

  const handleLanguageToggle = () => {
    const newLang = currentLanguage === 'es' ? 'en' : 'es';
    console.log(`🌐 Cambiando idioma: ${currentLanguage} → ${newLang}`);
    setCurrentLanguage(newLang);
    
    // Si está reproduciendo y hay un waypoint activo, re-ejecutarlo con el nuevo idioma
    if (currentWaypointIndex !== -1) {
      console.log(`🔄 Re-ejecutando waypoint ${currentWaypointIndex} con idioma ${newLang}`);
      
      // Detener audio y typewriter actuales
      cleanupAudio();
      if (typewriterRef.current) {
        clearInterval(typewriterRef.current);
        typewriterRef.current = null;
      }
      
      // Pequeño delay para asegurar que el estado se actualice
      setTimeout(() => {
        // Forzar re-ejecución del waypoint actual
        const wp = WAYPOINTS[currentWaypointIndex];
        const text = wp.text[newLang];
        const audioText = wp.audioText ? wp.audioText[newLang] : text; // 🎤 USAR AUDIO FONÉTICO SI EXISTE
        
        setDisplayText('');
        
        // 🎯 CALCULAR DURACIÓN ESTIMADA DEL AUDIO (mismo cálculo que executeWaypoint)
        const charsPerSecond = newLang === 'es' ? 12 : 14;
        const estimatedAudioDuration = (audioText.length / charsPerSecond) * 1000;
        
        console.log(`⏱️ Duración estimada (cambio idioma): ${(estimatedAudioDuration / 1000).toFixed(1)}s`);
        
        // Audio con nuevo idioma
        if (!isMuted) {
          const utterance = new SpeechSynthesisUtterance(audioText); // 🎤 USAR AUDIO FONÉTICO
          utterance.lang = newLang === 'es' ? 'es-ES' : 'en-US';
          utterance.rate = 0.9;
          utterance.pitch = 1.0;
          utterance.volume = 1.0;

          if (availableVoices.length > 0) {
            let selectedVoice: SpeechSynthesisVoice | undefined;
            
            if (newLang === 'es') {
              selectedVoice = availableVoices.find(v => v.name.includes('Sabina')) ||
                             availableVoices.find(v => v.name.includes('Google español') && v.lang === 'es-ES') ||
                             availableVoices.find(v => v.lang.startsWith('es'));
              console.log('🔊 Voz cambiada a ES:', selectedVoice?.name || 'predeterminada');
            } else {
              selectedVoice = availableVoices.find(v => v.name.includes('Google UK English Female')) ||
                             availableVoices.find(v => v.name.includes('Female') && v.lang.startsWith('en')) ||
                             availableVoices.find(v => v.name.includes('Google US English')) ||
                             availableVoices.find(v => v.lang.startsWith('en'));
              console.log('🔊 Voz cambiada a EN:', selectedVoice?.name || 'predeterminada');
            }
            
            if (selectedVoice) {
              utterance.voice = selectedVoice;
            }
          }

          // 🎯 SINCRONIZACIÓN: typewriter empieza cuando empieza el audio
          utterance.onstart = () => {
            console.log('🎤 Audio iniciado (cambio idioma), comenzando typewriter...');
            
            const chars = text.split('');
            const delay = estimatedAudioDuration / chars.length;
            let i = 0;

            typewriterRef.current = window.setInterval(() => {
              if (i < chars.length) {
                setDisplayText(chars.slice(0, i + 1).join(''));
                i++;
              } else {
                if (typewriterRef.current) {
                  clearInterval(typewriterRef.current);
                  typewriterRef.current = null;
                }
              }
            }, delay);
          };

          utterance.onend = () => {
            console.log('🎤 Audio terminado (cambio idioma)');
            setDisplayText(text);
            if (typewriterRef.current) {
              clearInterval(typewriterRef.current);
              typewriterRef.current = null;
            }
          };

          utterance.onerror = (event) => {
            console.error('❌ Error en audio (cambio idioma):', event);
            setDisplayText(text);
            if (typewriterRef.current) {
              clearInterval(typewriterRef.current);
              typewriterRef.current = null;
            }
          };

          // 🚀 OPTIMIZACIÓN: Asegurar que el motor esté limpio antes de hablar
          window.speechSynthesis.cancel();
          
          window.speechSynthesis.speak(utterance);
          currentUtteranceRef.current = utterance; // 🎤 GUARDAR REFERENCIA AL UTTERANCE ACTUAL
        } else {
          // 🔇 Modo mudo: usar duración estimada
          const chars = text.split('');
          const delay = estimatedAudioDuration / chars.length;
          let i = 0;

          typewriterRef.current = window.setInterval(() => {
            if (i < chars.length) {
              setDisplayText(chars.slice(0, i + 1).join(''));
              i++;
            } else {
              if (typewriterRef.current) {
                clearInterval(typewriterRef.current);
                typewriterRef.current = null;
              }
            }
          }, delay);
        }
      }, 50);
    }
  };

  if (!isOpen) return null;

  return (
    <div style={{ position: 'fixed', inset: 0, backgroundColor: '#000', zIndex: 10000, display: 'flex', flexDirection: 'column' }}>
      {/* Header */}
      <div style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: '16px 24px',
        background: 'linear-gradient(to bottom, rgba(15, 23, 41, 0.9), transparent)',
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        zIndex: 10,
      }}>
        {/* Logo Lydaris Data Intelligence - Fijo */}
        <div style={{
          display: 'flex',
          alignItems: 'center',
          gap: '14px',
          background: 'rgba(15, 23, 41, 0.98)',
          backdropFilter: 'blur(16px)',
          padding: '12px 20px',
          borderRadius: '8px',
          border: '1px solid rgba(255, 255, 255, 0.2)',
          userSelect: 'none',
          boxShadow: '0 6px 20px rgba(0, 0, 0, 0.7), 0 0 0 1px rgba(255, 255, 255, 0.08)',
        }}>
          <div style={{
            display: 'flex',
            alignItems: 'center',
            gap: '3px',
            fontSize: '1.2rem',
            fontWeight: '700',
            color: '#fff',
            letterSpacing: '-0.5px',
            textShadow: '0 2px 4px rgba(0, 0, 0, 0.7)',
          }}>
            <span>L</span>
            <span style={{ fontSize: '1.5rem', lineHeight: '1' }}>.</span>
            <span>D</span>
            <span style={{ 
              marginLeft: '4px',
              fontSize: '1.4rem',
              fontWeight: '300',
              opacity: 0.6,
            }}>|</span>
          </div>
          <span style={{
            fontSize: '0.8rem',
            color: '#c0d0f0',
            letterSpacing: '0.4px',
            fontWeight: 400,
            textShadow: '0 2px 3px rgba(0, 0, 0, 0.7)',
          }}>
            Powered by{' '}
            <span style={{ color: '#06b6d4', fontWeight: 600 }}>
              Lydaris Data Intelligence
            </span>
          </span>
        </div>
        <div style={{ display: 'flex', gap: '8px' }}>
          <button onClick={() => setIsMuted(!isMuted)} style={{
            background: 'rgba(255, 255, 255, 0.1)',
            border: '1px solid rgba(255, 255, 255, 0.15)',
            color: 'white',
            padding: '8px',
            borderRadius: '6px',
            cursor: 'pointer',
            display: 'flex',
          }}>
            {isMuted ? <VolumeX size={18} /> : <Volume2 size={18} />}
          </button>
          <button onClick={handleLanguageToggle} style={{
            background: 'rgba(255, 255, 255, 0.1)',
            border: '1px solid rgba(255, 255, 255, 0.15)',
            color: 'white',
            padding: '8px 12px',
            borderRadius: '6px',
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            gap: '4px',
            fontSize: '13px',
            fontWeight: 600,
          }}>
            <span style={{ opacity: currentLanguage === 'en' ? 1 : 0.5 }}>EN</span>
            <span style={{ opacity: 0.5 }}>|</span>
            <span style={{ opacity: currentLanguage === 'es' ? 1 : 0.5 }}>ES</span>
          </button>
          <button onClick={handleClose} style={{
            background: 'rgba(255, 255, 255, 0.1)',
            border: '1px solid rgba(255, 255, 255, 0.15)',
            color: 'white',
            padding: '8px',
            borderRadius: '6px',
            cursor: 'pointer',
            display: 'flex',
          }}>
            <X size={20} />
          </button>
        </div>
      </div>

      {/* Mapa */}
      <div 
        ref={mapContainerRef} 
        style={{ 
          flex: 1,
          position: 'relative',
          zIndex: 2,
        }} 
      />



      {/* Texto */}
      {displayText && (
        <p style={{
          position: 'absolute',
          bottom: 120,
          left: '50%',
          transform: 'translateX(-50%)',
          width: '85%',
          maxWidth: '1100px',
          color: '#fff',
          fontSize: '19px',
          margin: 0,
          lineHeight: 1.75,
          letterSpacing: '0.4px',
          textShadow: '0 2px 16px rgba(0,0,0,1), 0 4px 32px rgba(0,0,0,0.9), 0 1px 3px rgba(0,0,0,1)',
          pointerEvents: 'none',
          textAlign: 'center',
          zIndex: 9999,
        }}>
          {displayText}
        </p>
      )}

      {/* Controles */}
      <div style={{
        position: 'absolute',
        bottom: 0,
        left: 0,
        right: 0,
        background: 'linear-gradient(to top, rgba(15, 23, 41, 0.9), transparent)',
        padding: '24px',
        pointerEvents: 'none',
        zIndex: 10000,
      }}>
        <div style={{
          width: '100%',
          height: '4px',
          background: 'rgba(255,255,255,0.15)',
          borderRadius: '2px',
          marginBottom: '16px',
          overflow: 'hidden',
          pointerEvents: 'none',
        }}
        >
          <div style={{
            height: '100%',
            background: 'linear-gradient(90deg, #06b6d4, #3b82f6)',
            width: `${(currentTime / TOTAL_DURATION) * 100}%`,
            transition: 'width 0.1s linear',
          }} />
        </div>

        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '12px', pointerEvents: 'auto' }}>
          <button onClick={() => setIsPlaying(!isPlaying)} style={{
            background: 'linear-gradient(135deg, #06b6d4, #3b82f6)',
            border: 'none',
            color: 'white',
            padding: '10px 24px',
            borderRadius: '8px',
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            gap: '8px',
            fontSize: '14px',
            fontWeight: 600,
          }}>
            {isPlaying ? <Pause size={16} /> : <Play size={16} />}
            {isPlaying ? (currentLanguage === 'es' ? 'Pausar' : 'Pause') : (currentLanguage === 'es' ? 'Reproducir' : 'Play')}
          </button>

          <button onClick={handleReset} style={{
            background: 'rgba(255,255,255,0.1)',
            border: '1px solid rgba(255,255,255,0.15)',
            color: 'white',
            padding: '10px 20px',
            borderRadius: '8px',
            cursor: 'pointer',
            fontSize: '14px',
            fontWeight: 600,
          }}>
            {currentLanguage === 'es' ? 'Reiniciar' : 'Reset'}
          </button>

          <div style={{
            color: 'rgba(255,255,255,0.8)',
            fontSize: '14px',
            fontFamily: 'monospace',
            background: 'rgba(255,255,255,0.05)',
            padding: '10px 16px',
            borderRadius: '8px',
            border: '1px solid rgba(255,255,255,0.1)',
          }}>
            {Math.floor(currentTime)}s / {TOTAL_DURATION}s
          </div>
        </div>
      </div>

      {/* Logo de Mapbox clickeable - Tour 360° */}
      <a
        href="https://www.mapbox.com/"
        target="_blank"
        rel="noopener noreferrer"
        style={{
          position: 'fixed',
          bottom: '10px',
          left: '10px',
          zIndex: 10005,
          background: 'rgba(255, 255, 255, 0.9)',
          padding: '3px 8px',
          borderRadius: '3px',
          fontSize: '11px',
          fontWeight: 600,
          color: '#000',
          textDecoration: 'none',
          boxShadow: '0 1px 4px rgba(0,0,0,0.3)',
          fontFamily: 'Arial, sans-serif',
        }}
      >
        © Mapbox
      </a>
    </div>
  );
}