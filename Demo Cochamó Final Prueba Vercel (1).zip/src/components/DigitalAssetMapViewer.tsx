import React, { useRef, useEffect, useState } from 'react';
import mapboxgl from 'mapbox-gl';
import 'mapbox-gl/dist/mapbox-gl.css';
import { MAPBOX_CONFIG, VECTOR_SOURCES, TILE_SOURCES, DEFAULT_LOCATION } from '../config/data-sources';
import { reservaCochamoCoordinates } from '../data/aoi_cochamo';
import { waterClassificationGeoJSON } from '../data/water-classification';

type LayerType = 'water' | 'vegetation' | 'slopes' | 'risk';

interface DigitalAssetMapViewerProps {
  isOpen: boolean;
  activeLayer: LayerType | null;
  layerOpacity: { [key in LayerType]?: number };
  enabledLayers: { [key in LayerType]?: boolean };
}

const MAPBOX_TOKEN = MAPBOX_CONFIG.token;

export function DigitalAssetMapViewer({
  isOpen,
  activeLayer,
  layerOpacity,
  enabledLayers,
}: DigitalAssetMapViewerProps) {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<mapboxgl.Map | null>(null);
  const [mapReady, setMapReady] = useState(false);

  // Inicializar mapa independiente
  useEffect(() => {
    if (!isOpen || !mapContainerRef.current || mapRef.current) return;

    mapboxgl.accessToken = MAPBOX_TOKEN;

    const map = new mapboxgl.Map({
      container: mapContainerRef.current,
      style: MAPBOX_CONFIG.styles.satellite,
      center: DEFAULT_LOCATION.center,
      zoom: DEFAULT_LOCATION.zoom,
      pitch: DEFAULT_LOCATION.pitch3D,
      bearing: DEFAULT_LOCATION.bearing3D,
      antialias: true,
      logoPosition: 'bottom-left',
    });

    // Controles de navegación (sin fullscreen)
    map.addControl(new mapboxgl.NavigationControl(), 'top-right');

    map.on('load', () => {
      console.log('🗺️ Digital Asset Map - Loaded independently');

      // Añadir terreno 3D
      map.addSource('mapbox-dem-terrain', {
        type: 'raster-dem',
        url: MAPBOX_CONFIG.dem.url,
        tileSize: MAPBOX_CONFIG.dem.tileSize,
        maxzoom: MAPBOX_CONFIG.dem.maxzoom,
      });

      map.setTerrain({ source: 'mapbox-dem-terrain', exaggeration: 1.5 });

      // Ocultar el logo nativo de Mapbox (usamos nuestro logo personalizado)
      setTimeout(() => {
        const mapContainer = mapContainerRef.current;
        if (mapContainer) {
          const logo = mapContainer.querySelector('.mapboxgl-ctrl-logo') as HTMLElement;
          if (logo) {
            logo.style.display = 'none';
          }
        }
      }, 500);

      // Añadir AOI (polígono de Reserva Cochamó)
      map.addSource('aoi-cochamo', {
        type: 'geojson',
        data: {
          type: 'Feature',
          properties: {},
          geometry: {
            type: 'Polygon',
            coordinates: [reservaCochamoCoordinates],
          },
        },
      });

      map.addLayer({
        id: 'aoi-fill',
        type: 'fill',
        source: 'aoi-cochamo',
        paint: {
          'fill-color': '#10b981',
          'fill-opacity': 0.15,
        },
      });

      map.addLayer({
        id: 'aoi-outline',
        type: 'line',
        source: 'aoi-cochamo',
        paint: {
          'line-color': '#10b981',
          'line-width': 3,
          'line-opacity': 0.8,
        },
      });

      // ============================================
      // CARGAR TODAS LAS FUENTES DE CAPAS (ocultas inicialmente)
      // ============================================

      // Fuente de AGUA - Cargar con fallback
      fetch(VECTOR_SOURCES.waterClassification)
        .then(res => res.json())
        .then(data => {
          map.addSource('water-classification', {
            type: 'geojson',
            data: data,
          });

          map.addLayer({
            id: 'water-layer',
            type: 'fill',
            source: 'water-classification',
            layout: { visibility: 'none' },
            paint: {
              'fill-color': [
                'match',
                ['get', 'class'],
                1, '#1e3a8a',
                2, '#06b6d4',
                3, '#10b981',
                '#334155'
              ],
              'fill-opacity': 0.8,
            },
          });
        })
        .catch(err => {
          console.error('[Digital Asset Map] ❌ Error cargando agua:', err);
          console.log('[Digital Asset Map] 🔄 Usando fallback local...');
          
          map.addSource('water-classification', {
            type: 'geojson',
            data: waterClassificationGeoJSON,
          });

          map.addLayer({
            id: 'water-layer',
            type: 'fill',
            source: 'water-classification',
            layout: { visibility: 'none' },
            paint: {
              'fill-color': [
                'match',
                ['get', 'class'],
                1, '#1e3a8a',
                2, '#06b6d4',
                3, '#10b981',
                '#334155'
              ],
              'fill-opacity': 0.8,
            },
          });
        });

      // Fuente de VIGOR ECOSISTÉMICO (EV) - IGUAL QUE EN DASHBOARD
      map.addSource('ev-tiles', {
        type: 'raster',
        tiles: [TILE_SOURCES.ev2025],
        tileSize: 256,
        scheme: 'tms', // ⚠️ TMS es crítico para EV
      });

      map.addLayer({
        id: 'ev-layer',
        type: 'raster',
        source: 'ev-tiles',
        layout: { visibility: 'none' },
        paint: {
          'raster-opacity': 0.7,
        },
      });

      // Fuente de RIESGO (LSI)
      map.addSource('lsi-tiles', {
        type: 'raster',
        tiles: [TILE_SOURCES.lsi2025],
        tileSize: 256,
        scheme: 'tms',
      });

      map.addLayer({
        id: 'lsi-layer',
        type: 'raster',
        source: 'lsi-tiles',
        layout: { visibility: 'none' },
        paint: {
          'raster-opacity': 0.75,
        },
      });

      // ⛰️ PENDIENTES (SLOPE) - TILES RASTER CON ESQUEMA TMS (IGUAL QUE TOUR360)
      console.log('[Digital Asset Map] 🔄 Agregando capa SLOPE (Pendiente - TMS)...');
      map.addSource('slope-tiles', {
        type: 'raster',
        tiles: ['https://data.lydarisdata.eu/tiles/tiles_SLOPE_5clases_visRGBA/{z}/{x}/{y}.png'],
        tileSize: 256,
        scheme: 'tms', // ⚡ ESQUEMA TMS
        minzoom: 10,
        maxzoom: 14,
      });

      map.addLayer({
        id: 'slope-layer',
        type: 'raster',
        source: 'slope-tiles',
        layout: { visibility: 'none' },
        paint: {
          'raster-opacity': 0.65,
        },
      });

      console.log('[Digital Asset Map] ✅ Capa SLOPE agregada (invisible al inicio, esquema TMS)');

      console.log('✅ Todas las capas cargadas y ocultas');
      setMapReady(true);
    });

    mapRef.current = map;

    return () => {
      if (mapRef.current) {
        mapRef.current.remove();
        mapRef.current = null;
        setMapReady(false);
      }
    };
  }, [isOpen]);

  // ============================================
  // CONTROLAR VISIBILIDAD DE CAPAS (solo una a la vez)
  // ============================================
  useEffect(() => {
    if (!mapReady || !mapRef.current) return;

    const map = mapRef.current;

    console.log('🎛️ Control de capas:', enabledLayers);

    // Ocultar TODAS las capas primero
    try {
      if (map.getLayer('water-layer')) {
        map.setLayoutProperty('water-layer', 'visibility', 'none');
      }
      if (map.getLayer('ev-layer')) {
        map.setLayoutProperty('ev-layer', 'visibility', 'none');
      }
      if (map.getLayer('lsi-layer')) {
        map.setLayoutProperty('lsi-layer', 'visibility', 'none');
      }
      if (map.getLayer('slope-layer')) {
        map.setLayoutProperty('slope-layer', 'visibility', 'none');
      }
    } catch (e) {
      console.error('Error ocultando capas:', e);
    }

    // Activar SOLO la capa habilitada
    try {
      if (enabledLayers.water) {
        console.log('💧 Activando AGUA');
        map.setLayoutProperty('water-layer', 'visibility', 'visible');
        map.setPaintProperty('water-layer', 'fill-opacity', layerOpacity.water || 0.8);
      }

      if (enabledLayers.vegetation) {
        console.log('🌲 Activando VIGOR ECOSISTÉMICO (EV)');
        map.setLayoutProperty('ev-layer', 'visibility', 'visible');
        map.setPaintProperty('ev-layer', 'raster-opacity', layerOpacity.vegetation || 0.7);
      }

      if (enabledLayers.slopes) {
        console.log('⛰️ Activando PENDIENTES (SLOPE)');
        map.setLayoutProperty('slope-layer', 'visibility', 'visible');
        map.setPaintProperty('slope-layer', 'raster-opacity', layerOpacity.slopes || 0.65);
      }

      if (enabledLayers.risk) {
        console.log('⚠️ Activando RIESGO (LSI)');
        map.setLayoutProperty('lsi-layer', 'visibility', 'visible');
        map.setPaintProperty('lsi-layer', 'raster-opacity', layerOpacity.risk || 0.75);
      }
    } catch (e) {
      console.error('Error activando capas:', e);
    }
  }, [mapReady, enabledLayers, layerOpacity]);

  if (!isOpen) return null;

  return (
    <>
      <div
        ref={mapContainerRef}
        style={{
          position: 'fixed',
          top: 0,
          left: 0,
          width: '100vw',
          height: '100vh',
          zIndex: 10001,
        }}
      />

      {/* Logo de Mapbox clickeable - Mapa Tarjeta Digital */}
      <a
        href="https://www.mapbox.com/"
        target="_blank"
        rel="noopener noreferrer"
        style={{
          position: 'fixed',
          bottom: '10px',
          left: '10px',
          zIndex: 10005,
          background: 'rgba(255, 255, 255, 0.9)',
          padding: '3px 8px',
          borderRadius: '3px',
          fontSize: '11px',
          fontWeight: 600,
          color: '#000',
          textDecoration: 'none',
          boxShadow: '0 1px 4px rgba(0,0,0,0.3)',
          fontFamily: 'Arial, sans-serif',
        }}
      >
        © Mapbox
      </a>
    </>
  );
}