import { useState } from 'react';
import { ArrowLeft, Layers } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import SystemArchitectureDiagram from './SystemArchitectureDiagram';

interface DigitalAssetsProps {
  onNavigate: (view: string) => void;
}

export default function DigitalAssets({ onNavigate }: DigitalAssetsProps) {
  const { language, setLanguage } = useLanguage();

  const content = {
    es: {
      title: 'Activos Ambientales Digitales',
      backButton: 'Volver',
      
      intro: {
        title: 'Sistema de Inteligencia Ambiental Satelital',
        paragraphs: [
          'Lydaris Data Intelligence es una infraestructura de inteligencia ambiental satelital diseñada para convertir territorios en <strong>Activos Ambientales Digitales</strong>, estructurados como bloques de datos geoambientales con métricas propietarias, series temporales e historial trazable y auditable, que documentan su comportamiento ecosistémico en el tiempo.',
          'Este enfoque representa una innovación de arquitectura en analítica territorial: territorios a escala de conservación son caracterizados, monitoreados y comparables bajo una misma infraestructura de inteligencia ambiental.',
          'Lydaris Data Intelligence integra caracterización ecosistémica multicapas, índices propietarios correlacionados, monitoreo satelital y visualización interactiva avanzada dentro de un sistema unificado de operación.',
          'El sistema incorpora tecnologías de visualización de última generación que habilitan exploración analítica en entornos 2D, 3D y multivista, con modelos territoriales navegables, rotación espacial, observación multiangular, superposición dinámica de capas geosatelitales y recorridos analíticos interactivos, permitiendo comprender la complejidad territorial desde múltiples escalas y perspectivas.',
          'Bajo esta arquitectura, los territorios dejan de ser objetos cartográficos estáticos y pasan a operar como unidades ambientales digitalmente evaluadas, con identidad propia, métricas trazables y capacidad de comparación transversal, constituyendo activos ambientales digitales aptos para sustentar procesos de inversión, conservación e investigación de largo plazo.',
          'Los indicadores propietarios del sistema como Hydro Index®, Eco-Structural Index®, Risk Index®, Carbon Index™, entre muchos otros posibles de construir y desarrollar bajo demanda, de acuerdo a las necesidades de distintos planes y proyectos de inversión, operan como capas territoriales analíticas dinámicas, complementarias, comparables, trazables y auditables.'
        ]
      },

      methodology: {
        title: 'Base Metodológica del Sistema',
        paragraphs: [
          'El sistema se basa en la integración de múltiples fuentes satelitales ópticas, climáticas, hidrológicas y de clasificación del territorio, procesadas bajo ventanas multianuales y agregadas a nivel píxel mediante métricas espaciales avanzadas.',
          'La metodología privilegia señales estructurales y funcionales relativamente estables, reduciendo la dependencia de estados puntuales o eventos transitorios, y permitiendo una caracterización objetiva, reproducible y no invasiva de los sistemas analizados.',
          'Este enfoque habilita la generación de métricas comparables entre territorios, consistentes en el tiempo y científicamente verificables, adecuadas tanto para evaluación aplicada como para investigación y validación independiente.'
        ]
      },

      capabilities: {
        title: 'Capacidades del Sistema',
        intro: 'La estructura y metodología permite:',
        items: [
          {
            title: '1. Monitoreo no invasivo automatizado',
            points: [
              'Actualización periódica de índices mediante procesamiento satelital multifuente.',
              'Detección temprana de alteraciones estructurales, hídricas o de riesgo.',
              'Sistema de alertas asociado a umbrales configurables.'
            ]
          },
          {
            title: '2. Trazabilidad y verificabilidad digital',
            points: [
              'Cada métrica es rastreable a su fuente satelital original.',
              'Transparencia metodológica para auditorías técnicas independientes.',
              'Capacidad de certificación digital del estado ecosistémico del activo.'
            ]
          },
          {
            title: '3. Benchmarking regional',
            points: [
              'Comparación contra otros activos de características similares dentro de la ecorregión.',
              'Posicionamiento relativo en métricas de integridad ecosistémica, funcionalidad hídrica y riesgo.',
              'Identificación de patrones regionales y territorios de referencia.'
            ]
          },
          {
            title: '4. Capacidad predictiva y escenarios',
            points: [
              'Proyección de tendencias basada en series temporales multianuales.',
              'Simulación de escenarios de cambio climático, hidrológico o de riesgo.',
              'Evaluación del comportamiento del sistema frente a perturbaciones futuras.'
            ]
          },
          {
            title: '5. Dashboard de gestión decisional de nivel interactivo avanzado',
            points: [
              'Visualización dinámica de métricas clave.',
              'Reportes ejecutivos periódicos.',
              'Integración con sistemas de gestión ambiental existentes.'
            ]
          },
          {
            title: '6. Soporte para investigación y desarrollo científico',
            points: [
              'Estructura de datos apta para análisis comparativos y multiescala.',
              'Posibilidad de generación de capas especializadas, métricas y series temporales para investigación.',
              'Plataforma base para validación, publicación científica y desarrollo de nuevos indicadores.'
            ]
          }
        ]
      }
    },
    en: {
      title: 'Digital Environmental Assets',
      backButton: 'Back',
      
      intro: {
        title: 'Satellite Environmental Intelligence System',
        paragraphs: [
          'Lydaris Data Intelligence is an environmental intelligence infrastructure designed to convert territories into <strong>Digital Environmental Assets</strong>, structured as blocks of geo-environmental data with proprietary metrics, time series, and traceable and auditable history that document their ecosystem behavior over time.',
          'This approach represents an architectural innovation in territorial analytics: conservation-scale territories are systematically characterized, monitored, and comparable under the same continuous environmental intelligence infrastructure.',
          'Lydaris Data Intelligence integrates multilayer ecosystem characterization, correlated proprietary indices, continuous satellite monitoring, and advanced interactive visualization within a unified operating system.',
          'The system incorporates cutting-edge visualization technologies that enable analytical exploration in 2D, 3D, and multiview environments, with navigable territorial models, spatial rotation, multi-angle observation, dynamic overlay of geosatellite layers, and interactive analytical tours, allowing the understanding of territorial complexity from multiple scales and perspectives.',
          'Under this architecture, territories cease to be static cartographic objects and begin to operate as digitally evaluated environmental entities, with their own identity, traceable metrics, systematic updates, and transversal comparison capacity, constituting digital environmental assets capable of supporting long-term investment, conservation, and research processes.',
          'The proprietary indicators of the system such as Hydro Index®, Eco-Structural Index®, Risk Index®, Carbon Index™, among many others possible to build and develop on demand, according to the needs of different investment plans and projects, operate as dynamic, complementary, comparable, traceable, and auditable territorial analytical layers.'
        ]
      },

      methodology: {
        title: 'System Methodological Base',
        paragraphs: [
          'The system is based on the integration of multiple optical, climatic, hydrological, and territorial classification satellite sources, processed under multi-year windows and aggregated at the pixel level through advanced spatial metrics.',
          'The methodology prioritizes relatively stable structural and functional signals, reducing dependence on specific states or transitory events, and allowing objective, reproducible, and non-invasive characterization of the analyzed systems.',
          'This approach enables the generation of metrics that are comparable between territories, consistent over time, and scientifically verifiable, suitable for both applied assessment and research and independent validation.'
        ]
      },

      capabilities: {
        title: 'System Capabilities',
        intro: 'The structure and methodology allows:',
        items: [
          {
            title: '1. Automated non-invasive monitoring',
            points: [
              'Periodic update of indices through multi-source satellite processing.',
              'Early detection of structural, water, or risk alterations.',
              'Alert system associated with configurable thresholds.'
            ]
          },
          {
            title: '2. Traceability and digital verifiability',
            points: [
              'Each metric is traceable to its original satellite source.',
              'Methodological transparency for independent technical audits.',
              'Digital certification capacity of the ecosystem state of the asset.'
            ]
          },
          {
            title: '3. Regional benchmarking',
            points: [
              'Comparison against other assets with similar characteristics within the ecoregion.',
              'Relative positioning in ecosystem integrity, water functionality, and risk metrics.',
              'Identification of regional patterns and reference territories.'
            ]
          },
          {
            title: '4. Predictive capacity and scenarios',
            points: [
              'Trend projection based on multi-year time series.',
              'Simulation of climate, hydrological, or risk change scenarios.',
              'Evaluation of system behavior in the face of future disturbances.'
            ]
          },
          {
            title: '5. Advanced interactive decision management dashboard',
            points: [
              'Dynamic visualization of key metrics.',
              'Periodic executive reports.',
              'Integration with existing environmental management systems.'
            ]
          },
          {
            title: '6. Support for research and scientific development',
            points: [
              'Data structure suitable for comparative and multi-scale analysis.',
              'Possibility of generating specialized layers, metrics, and time series for research.',
              'Base platform for validation, scientific publication, and development of new indicators.'
            ]
          }
        ]
      }
    }
  };

  const t = content[language];

  return (
    <div className="w-full h-screen bg-[#0f1220] text-white overflow-y-auto" style={{ scrollBehavior: 'smooth' }}>
      {/* Action Bar - Fixed */}
      <div className="fixed top-0 left-0 right-0 bg-[#0f1220]/95 backdrop-blur-sm border-b border-[#1a2540] z-50">
        <div className="max-w-5xl mx-auto px-6 py-3 flex items-center justify-between">
          <button
            onClick={() => onNavigate('hydro-mapbox-test')}
            className="flex items-center gap-2 px-3 py-2 bg-[#171f33] border border-[#243253] rounded-lg hover:bg-[#1a2540] transition-all"
          >
            <ArrowLeft className="w-4 h-4 text-[#a8b0c6]" />
            <span className="text-sm text-[#a8b0c6]">{t.backButton}</span>
          </button>

          {/* Language Selector */}
          <div className="flex items-center gap-2 bg-[#171f33] border border-[#243253] rounded-lg p-1">
            <button
              onClick={() => setLanguage('es')}
              className={`px-3 py-1.5 text-sm rounded transition-all ${
                language === 'es'
                  ? 'bg-[#06b6d4] text-white font-medium'
                  : 'text-[#a8b0c6] hover:text-white'
              }`}
            >
              ES
            </button>
            <button
              onClick={() => setLanguage('en')}
              className={`px-3 py-1.5 text-sm rounded transition-all ${
                language === 'en'
                  ? 'bg-[#06b6d4] text-white font-medium'
                  : 'text-[#a8b0c6] hover:text-white'
              }`}
            >
              EN
            </button>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-5xl mx-auto px-6 pt-24 pb-16">
        {/* Header - Más compacto y sobrio */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-lg bg-[#171f33] border border-[#243253] flex items-center justify-center">
              <Layers size={20} className="text-[#a8b0c6]" />
            </div>
            <div>
              <h1 className="text-2xl font-semibold text-[#e9eef9]">{t.title}</h1>
            </div>
          </div>
          <div className="border-t border-[#1a2540]" />
        </div>

        {/* Introduction Section */}
        <section className="mb-8">
          <h2 className="text-xl font-medium text-[#e9eef9] mb-4 pb-2 border-b border-[#1a2540]">{t.intro.title}</h2>
          <div className="space-y-4">
            {t.intro.paragraphs.map((paragraph, idx) => (
              <p key={idx} className="text-[#c4cfe0] leading-relaxed text-base text-justify" dangerouslySetInnerHTML={{ __html: paragraph }} />
            ))}
          </div>
        </section>

        {/* System Architecture Diagram */}
        <section className="mb-8">
          <SystemArchitectureDiagram />
        </section>

        {/* Methodology Section */}
        <section className="mb-8">
          <h2 className="text-xl font-medium text-[#e9eef9] mb-4 pb-2 border-b border-[#1a2540]">{t.methodology.title}</h2>
          <div className="space-y-4">
            {t.methodology.paragraphs.map((paragraph, idx) => (
              <p key={idx} className="text-[#c4cfe0] leading-relaxed text-base text-justify">
                {paragraph}
              </p>
            ))}
          </div>
        </section>

        {/* Capabilities Section */}
        <section className="mb-8">
          <h2 className="text-xl font-medium text-[#e9eef9] mb-4 pb-2 border-b border-[#1a2540]">{t.capabilities.title}</h2>
          <p className="text-[#c4cfe0] mb-6">{t.capabilities.intro}</p>
          
          <div className="space-y-4">
            {t.capabilities.items.map((item, idx) => (
              <div key={idx} className="bg-[#171f33] border border-[#243253] rounded-lg p-5">
                <h3 className="text-base font-medium text-[#e9eef9] mb-3">{item.title}</h3>
                <ul className="space-y-2">
                  {item.points.map((point, pIdx) => (
                    <li key={pIdx} className="text-[#c4cfe0] text-sm pl-4">
                      • {point}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </section>

        {/* Footer */}
        <div className="mt-12 pt-6 border-t border-[#1a2540] text-center text-[#8a94a8]">
          <p translate="no" className="text-sm mb-2">Lydaris Data Intelligence © {new Date().getFullYear()}</p>
          <a 
            href="https://www.lydarisdata.eu" 
            target="_blank" 
            rel="noopener noreferrer"
            className="text-sm text-[#06b6d4] hover:text-[#0ea5e9] transition-colors inline-block"
            translate="no"
          >
            www.lydarisdata.eu
          </a>
        </div>
      </div>
    </div>
  );
}