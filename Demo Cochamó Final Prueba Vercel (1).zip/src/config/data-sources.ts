/**
 * ============================================
 * LYDARIS DATA - CONFIGURACIÓN CENTRALIZADA
 * ============================================
 * 
 * Todas las URLs de fuentes de datos en un solo lugar.
 * Para cambiar el servidor, solo edita BASE_URL.
 * 
 * VENTAJAS:
 * ✅ Cambio de servidor en 1 solo lugar
 * ✅ Fácil migración entre entornos (dev/staging/prod)
 * ✅ Control de versiones de tiles/datos
 * ✅ Mantenimiento simplificado
 */

// ============================================
// URL BASE DEL SERVIDOR DE DATOS
// ============================================
// Para cambiar de servidor, solo modifica esta línea:
const BASE_URL = 'https://data.lydarisdata.eu';

// Alternativamente, puedes tener múltiples entornos:
// const BASE_URL = import.meta.env.PROD 
//   ? 'https://data.lydarisdata.eu'      // Producción
//   : 'https://dev.lydarisdata.eu';      // Desarrollo

// ============================================
// VECTORIALES (GeoJSON)
// ============================================
export const VECTOR_SOURCES = {
  // Clasificación hidrológica (3 clases)
  waterClassification: `${BASE_URL}/vector/water-classification.geojson`,
  
  // Río Cochamó (línea vectorial)
  riverCochamo: `${BASE_URL}/vector/river-cochamo.geojson`,
  
  // AOI Reserva Cochamó (polígono)
  aoiCochamo: `${BASE_URL}/vector/aoi-cochamo.geojson`,
  
  // Agregar más capas vectoriales aquí...
} as const;

// ============================================
// TILES RASTER
// ============================================
export const TILE_SOURCES = {
  // Estructura Vertical (EV) - ESI
  // Formato: {z}/{x}/{y}.png
  ev2025: `${BASE_URL}/tiles/tiles_EV_RGBA_2025/{z}/{x}/{y}.png`,
  
  // Diversidad de Coberturas (DC) - ESI
  dc2025: `${BASE_URL}/tiles/tiles_DC_RGBA_2025/{z}/{x}/{y}.png`,
  
  // Integridad Bosque+Agua (FC) - ESI
  fc2025: `${BASE_URL}/tiles/tiles_FC_RGBA_2025/{z}/{x}/{y}.png`,
  
  // Presión Antrópica Inversa (PA⁻) - ESI
  paInv2025: `${BASE_URL}/tiles/tiles_PA_INV_RGBA_2025/{z}/{x}/{y}.png`,
  
  // Conectividad Ecológica (CE) - ESI
  ce2025: `${BASE_URL}/tiles/tiles_CE_RGBA_2025/{z}/{x}/{y}.png`,
  
  // Conectividad Hídrica (CH) - Hydro Index
  ch2025: `${BASE_URL}/tiles/tiles_CH_RGBA_2025/{z}/{x}/{y}.png`,
  
  // Regulación/Retención (RA) - Hydro Index
  ra2025: `${BASE_URL}/tiles/tiles_RA_RGBA_2025/{z}/{x}/{y}.png`,
  
  // Presencia y Accesibilidad (PA) - Hydro Index
  pa2025: `${BASE_URL}/tiles/tiles_PA_RGBA_2025/{z}/{x}/{y}.png`,
  
  // Capacidad de Amortiguación Climática (CBC) - Hydro Index
  cbc2025: `${BASE_URL}/tiles/tiles_CBC_RGBA_2025/{z}/{x}/{y}.png`,
  
  // Removal Risk (LSI) - Risk Index
  lsi2025: `${BASE_URL}/tiles/tiles_lsi_tms/{z}/{x}/{y}.png`,
  
  // Agregar más capas raster aquí...
} as const;

// ============================================
// APIs EXTERNAS
// ============================================
export const EXTERNAL_APIS = {
  openWeatherMap: 'https://api.openweathermap.org/data/2.5/weather',
  // Agregar más APIs aquí...
} as const;

// ============================================
// MAPBOX
// ============================================
export const MAPBOX_CONFIG = {
  token: 'pk.eyJ1IjoieGltZW5hc2Nob3R0IiwiYSI6ImNtaHUxOHhueDIwemcya3BxbTg4Z2w2eGEifQ.BT3DBpi2IYw6oEMluGeT4g',
  
  styles: {
    satellite: 'mapbox://styles/mapbox/satellite-streets-v12', // ⭐ CON etiquetas de lugares
    outdoors: 'mapbox://styles/mapbox/outdoors-v12',
  },
  
  dem: {
    url: 'mapbox://mapbox.mapbox-terrain-dem-v1',
    tileSize: 512,
    maxzoom: 14,
  },
} as const;

// ============================================
// COORDENADAS PREDETERMINADAS
// ============================================
export const DEFAULT_LOCATION = {
  // Centro del mapa (Reserva Cochamó)
  center: [-72.217, -41.415] as [number, number],
  zoom: 12.5,
  
  // Vista 3D predeterminada
  pitch3D: 60,
  bearing3D: -17.6,
} as const;

// ============================================
// HELPER: Obtener URL de tile con parámetros
// ============================================
export function getTileUrl(
  tileKey: keyof typeof TILE_SOURCES,
  z: number,
  x: number,
  y: number
): string {
  return TILE_SOURCES[tileKey]
    .replace('{z}', z.toString())
    .replace('{x}', x.toString())
    .replace('{y}', y.toString());
}

// ============================================
// HELPER: Validar disponibilidad de tiles
// ============================================
export async function checkTileAvailability(
  tileKey: keyof typeof TILE_SOURCES,
  z: number = 14,
  x: number = 4905,
  y: number = 6119
): Promise<boolean> {
  try {
    const url = getTileUrl(tileKey, z, x, y);
    const response = await fetch(url, { method: 'HEAD' });
    return response.ok;
  } catch {
    return false;
  }
}