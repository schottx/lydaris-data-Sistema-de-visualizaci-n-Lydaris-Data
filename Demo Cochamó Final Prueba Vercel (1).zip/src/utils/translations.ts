// Sistema de traducciones bilingüe inglés-español
// IMPORTANTE: Los nombres propietarios "Lydaris Data" y "Carbon Index" NO se traducen
// Los símbolos son ™ en inglés y ® en español

export type Language = 'en' | 'es';

export const translations = {
  en: {
    indices: {
      ESI: { name: 'Eco-Structural Index', symbol: '™' },
      HSI: { name: 'Hydro Index', symbol: '™' },
      CI: { name: 'Carbon Index', symbol: '™' },
      RI: { name: 'Risk Index', symbol: '™' },
      REI: { name: 'Resilience Index', symbol: '™' }
    },
    subLayers: {
      ESI_base: { name: 'Vegetation Integrity', desc: 'Natural forest cover integrity' },
      ESI_frag: { name: 'Fragmentation', desc: 'Patch density and edge effects' },
      ESI_conn: { name: 'Patch Connectivity', desc: 'Ecological corridors and core areas' },
      HSI_wet: { name: 'Wetness Probability', desc: 'Water retention zones' },
      HSI_dry: { name: 'Drying Risk', desc: 'Drought vulnerability areas' },
      HSI_hand: { name: 'HAND Analysis', desc: 'Height Above Nearest Drainage' },
      CI_bio: { name: 'Biomass Stocks', desc: 'Above+belowground carbon' },
      CI_soil: { name: 'Soil Carbon', desc: 'Soil organic carbon pools' },
      CI_dist: { name: 'Disturbance Sensitivity', desc: 'Vulnerability to carbon loss' },
      RI_ero: { name: 'Erosion Susceptibility', desc: 'Soil loss potential' },
      RI_lsi: { name: 'Landslide Susceptibility', desc: 'Mass movement risk zones' },
      RI_exp: { name: 'Exposure Hotspots', desc: 'Critical vulnerable areas' },
      REI_struct: { name: 'Structural Resilience', desc: 'Ecosystem structure stability' },
      REI_hydro: { name: 'Hydrological Buffer', desc: 'Water-based resilience' },
      REI_recovery: { name: 'Recovery Potential', desc: 'Post-disturbance recovery capacity' }
    },
    kpis: {
      ESI_base: { title: 'Vegetation Integrity', confidence: 'High' },
      ESI_frag: { title: 'Fragmentation Level', value: 'Low', confidence: 'High' },
      ESI_conn: { title: 'Connectivity Score', confidence: 'Med' },
      HSI_wet: { title: 'Wetness Area', confidence: 'High' },
      HSI_dry: { title: 'Drying Risk Area', confidence: 'Med' },
      HSI_hand: { title: 'Lowlands (≤2m)', confidence: 'High' },
      CI_bio: { title: 'Biomass Mean', confidence: 'High' },
      CI_soil: { title: 'Soil Carbon Mean', confidence: 'Med' },
      CI_dist: { title: 'Disturbance Sens.', value: 'Medium', confidence: 'Med' },
      RI_ero: { title: 'Erosion Mean', confidence: 'Med' },
      RI_lsi: { title: 'Landslide Mean', confidence: 'Med' },
      RI_exp: { title: 'Critical Hotspots', confidence: 'High' },
      REI_struct: { title: 'Structural Resil.', confidence: 'High' },
      REI_hydro: { title: 'Hydro Buffer', confidence: 'Med' },
      REI_recovery: { title: 'Recovery Potential', value: 'High', confidence: 'High' }
    },
    summaries: {
      ESI_base: ['High structural integrity detected', 'Mature forest dominates landscape', 'Favorable for conservation baseline'],
      ESI_frag: ['Low fragmentation with continuity', 'Few isolated patches observed', 'Ecological connectivity preserved'],
      ESI_conn: ['Core areas well-connected', 'Corridor functionality high', 'Stable ecosystem architecture'],
      HSI_wet: ['High water retention in lowlands', 'Wetland zones well-defined', 'Favorable hydrological capacity'],
      HSI_dry: ['Moderate drying risk detected', 'Upper slopes vulnerable', 'Seasonality impacts evident'],
      HSI_hand: ['Lowland areas buffered by elevation', 'Drainage network well-structured', 'Flood resilience moderate'],
      CI_bio: ['Carbon stock above regional benchmark', 'Biomass concentrated in mature stands', 'High sequestration potential'],
      CI_soil: ['Soil carbon pools moderate to high', 'Organic layer well-developed', 'Critical for long-term storage'],
      CI_dist: ['Medium sensitivity to disturbances', 'Degradation risk localized', 'Protection measures advised'],
      RI_ero: ['Erosion threat on steeper slopes', 'Soil loss risk moderate', 'Vegetative cover mitigates impact'],
      RI_lsi: ['Mass movement risk in specific zones', 'Landslide hotspots identified', 'Monitoring recommended'],
      RI_exp: ['Critical areas localized to 6.8%', 'Infrastructure exposure low', 'Risk management feasible'],
      REI_struct: ['High resilience from structure', 'Mature forest buffers disturbances', 'Recovery capacity strong'],
      REI_hydro: ['Hydrological buffer moderate', 'Water regulation capacity present', 'Climate adaptation viable'],
      REI_recovery: ['Excellent recovery potential', 'Natural regeneration favorable', 'Post-event restoration likely']
    },
    legends: {
      ESI_base: ['Very High', 'High', 'Moderate', 'Low', 'Very Low'],
      ESI_frag: ['High Frag.', 'Moderate', 'Low', 'Very Low', 'Minimal'],
      ESI_conn: ['High Connect.', 'Moderate', 'Low', 'Very Low', 'Isolated'],
      HSI_wet: ['Permanent', 'Frequent', 'Seasonal', 'Occasional', 'Rare'],
      HSI_dry: ['Very High', 'High', 'Moderate', 'Low', 'Very Low'],
      HSI_hand: ['0-2m', '2-5m', '5-10m', '10-20m', '>20m'],
      CI_bio: ['Very High', 'High', 'Moderate', 'Low', 'Very Low'],
      CI_soil: ['Very High', 'High', 'Moderate', 'Low', 'Very Low'],
      CI_dist: ['Very High', 'High', 'Moderate', 'Low', 'Very Low'],
      RI_ero: ['Very High', 'High', 'Moderate', 'Low', 'Very Low'],
      RI_lsi: ['Very High', 'High', 'Moderate', 'Low', 'Very Low'],
      RI_exp: ['Critical', 'High', 'Moderate', 'Low', 'Minimal'],
      REI_struct: ['Very High', 'High', 'Moderate', 'Low', 'Very Low'],
      REI_hydro: ['Very High', 'High', 'Moderate', 'Low', 'Very Low'],
      REI_recovery: ['Very High', 'High', 'Moderate', 'Low', 'Very Low']
    },
    ui: {
      selectIndex: 'Select an index to begin',
      viewMode: 'View',
      satellite: 'Satellite',
      topographic: 'Topographic',
      images: 'Images',
      terrain: 'Terrain',
      precisionGeospatial: 'Advanced Satellite Environmental Intelligence',
      headerTitle: 'Lydaris Data Intelligence',
      videoGallery: 'Reserve Video Overview',
      closeVideo: 'Close Video',
      playAudio: 'Play Audio Narration',
      stopAudio: 'Stop Audio'
    }
  },
  es: {
    indices: {
      ESI: { name: 'Índice Eco-Estructural', symbol: '®' },
      HSI: { name: 'Índice Hídrico', symbol: '®' },
      CI: { name: 'Carbon Index', symbol: '®' },  // Mantener nombre propietario
      RI: { name: 'Índice de Riesgo', symbol: '®' },
      REI: { name: 'Índice de Resiliencia', symbol: '®' }
    },
    subLayers: {
      ESI_base: { name: 'Integridad Vegetacional', desc: 'Integridad de cobertura forestal natural' },
      ESI_frag: { name: 'Fragmentación', desc: 'Densidad de parches y efectos de borde' },
      ESI_conn: { name: 'Conectividad de Parches', desc: 'Corredores ecológicos y áreas núcleo' },
      HSI_wet: { name: 'Probabilidad de Humedad', desc: 'Zonas de retención de agua' },
      HSI_dry: { name: 'Riesgo de Sequía', desc: 'Áreas vulnerables a sequía' },
      HSI_hand: { name: 'Análisis HAND', desc: 'Altura sobre drenaje más cercano' },
      CI_bio: { name: 'Reservas de Biomasa', desc: 'Carbono aéreo y subterráneo' },
      CI_soil: { name: 'Carbono del Suelo', desc: 'Pools de carbono orgánico del suelo' },
      CI_dist: { name: 'Sensibilidad a Perturbaciones', desc: 'Vulnerabilidad a pérdida de carbono' },
      RI_ero: { name: 'Susceptibilidad a Erosión', desc: 'Potencial de pérdida de suelo' },
      RI_lsi: { name: 'Susceptibilidad a Deslizamientos', desc: 'Zonas de riesgo de remoción en masa' },
      RI_exp: { name: 'Puntos Críticos de Exposición', desc: 'Áreas críticas vulnerables' },
      REI_struct: { name: 'Resiliencia Estructural', desc: 'Estabilidad de estructura ecosistémica' },
      REI_hydro: { name: 'Amortiguación Hidrológica', desc: 'Resiliencia basada en agua' },
      REI_recovery: { name: 'Potencial de Recuperación', desc: 'Capacidad de recuperación post-perturbación' }
    },
    kpis: {
      ESI_base: { title: 'Integridad Vegetacional', confidence: 'Alta' },
      ESI_frag: { title: 'Nivel de Fragmentación', value: 'Bajo', confidence: 'Alta' },
      ESI_conn: { title: 'Puntaje de Conectividad', confidence: 'Media' },
      HSI_wet: { title: 'Área de Humedad', confidence: 'Alta' },
      HSI_dry: { title: 'Área de Riesgo de Sequía', confidence: 'Media' },
      HSI_hand: { title: 'Tierras Bajas (≤2m)', confidence: 'Alta' },
      CI_bio: { title: 'Biomasa Promedio', confidence: 'Alta' },
      CI_soil: { title: 'Carbono del Suelo Promedio', confidence: 'Media' },
      CI_dist: { title: 'Sens. a Perturbaciones', value: 'Media', confidence: 'Media' },
      RI_ero: { title: 'Erosión Promedio', confidence: 'Media' },
      RI_lsi: { title: 'Deslizamiento Promedio', confidence: 'Media' },
      RI_exp: { title: 'Puntos Críticos', confidence: 'Alta' },
      REI_struct: { title: 'Resil. Estructural', confidence: 'Alta' },
      REI_hydro: { title: 'Amortiguación Hídrica', confidence: 'Media' },
      REI_recovery: { title: 'Potencial de Recuperación', value: 'Alto', confidence: 'Alta' }
    },
    summaries: {
      ESI_base: ['Alta integridad estructural detectada', 'Bosque maduro domina el paisaje', 'Favorable para línea base de conservación'],
      ESI_frag: ['Baja fragmentación con continuidad', 'Pocos parches aislados observados', 'Conectividad ecológica preservada'],
      ESI_conn: ['Áreas núcleo bien conectadas', 'Funcionalidad de corredores alta', 'Arquitectura ecosistémica estable'],
      HSI_wet: ['Alta retención de agua en tierras bajas', 'Zonas de humedales bien definidas', 'Capacidad hidrológica favorable'],
      HSI_dry: ['Riesgo moderado de sequía detectado', 'Pendientes superiores vulnerables', 'Impactos de estacionalidad evidentes'],
      HSI_hand: ['Áreas bajas amortiguadas por elevación', 'Red de drenaje bien estructurada', 'Resiliencia a inundaciones moderada'],
      CI_bio: ['Reserva de carbono sobre referencia regional', 'Biomasa concentrada en rodales maduros', 'Alto potencial de secuestro'],
      CI_soil: ['Pools de carbono del suelo moderados a altos', 'Capa orgánica bien desarrollada', 'Crítico para almacenamiento de largo plazo'],
      CI_dist: ['Sensibilidad media a perturbaciones', 'Riesgo de degradación localizado', 'Medidas de protección aconsejadas'],
      RI_ero: ['Amenaza de erosión en pendientes más pronunciadas', 'Riesgo de pérdida de suelo moderado', 'Cobertura vegetativa mitiga impacto'],
      RI_lsi: ['Riesgo de remoción en masa en zonas específicas', 'Puntos calientes de deslizamientos identificados', 'Monitoreo recomendado'],
      RI_exp: ['Áreas críticas localizadas en 6.8%', 'Exposición de infraestructura baja', 'Gestión de riesgo factible'],
      REI_struct: ['Alta resiliencia por estructura', 'Bosque maduro amortigua perturbaciones', 'Capacidad de recuperación fuerte'],
      REI_hydro: ['Amortiguación hidrológica moderada', 'Capacidad de regulación de agua presente', 'Adaptación climática viable'],
      REI_recovery: ['Excelente potencial de recuperación', 'Regeneración natural favorable', 'Restauración post-evento probable']
    },
    legends: {
      ESI_base: ['Muy Alto', 'Alto', 'Moderado', 'Bajo', 'Muy Bajo'],
      ESI_frag: ['Frag. Alta', 'Moderada', 'Baja', 'Muy Baja', 'Mínima'],
      ESI_conn: ['Conect. Alta', 'Moderada', 'Baja', 'Muy Baja', 'Aislado'],
      HSI_wet: ['Permanente', 'Frecuente', 'Estacional', 'Ocasional', 'Raro'],
      HSI_dry: ['Muy Alto', 'Alto', 'Moderado', 'Bajo', 'Muy Bajo'],
      HSI_hand: ['0-2m', '2-5m', '5-10m', '10-20m', '>20m'],
      CI_bio: ['Muy Alto', 'Alto', 'Moderado', 'Bajo', 'Muy Bajo'],
      CI_soil: ['Muy Alto', 'Alto', 'Moderado', 'Bajo', 'Muy Bajo'],
      CI_dist: ['Muy Alto', 'Alto', 'Moderado', 'Bajo', 'Muy Bajo'],
      RI_ero: ['Muy Alto', 'Alto', 'Moderado', 'Bajo', 'Muy Bajo'],
      RI_lsi: ['Muy Alto', 'Alto', 'Moderado', 'Bajo', 'Muy Bajo'],
      RI_exp: ['Crítico', 'Alto', 'Moderado', 'Bajo', 'Mínimo'],
      REI_struct: ['Muy Alto', 'Alto', 'Moderado', 'Bajo', 'Muy Bajo'],
      REI_hydro: ['Muy Alto', 'Alto', 'Moderado', 'Bajo', 'Muy Bajo'],
      REI_recovery: ['Muy Alto', 'Alto', 'Moderado', 'Bajo', 'Muy Bajo']
    },
    ui: {
      selectIndex: 'Seleccione un índice para comenzar',
      viewMode: 'Vista',
      satellite: 'Satélite',
      topographic: 'Topográfica',
      images: 'Imágenes',
      terrain: 'Terreno',
      precisionGeospatial: 'Inteligencia Ambiental Satelital Avanzada',
      headerTitle: 'Lydaris Data Intelligence',
      videoGallery: 'Video General de la Reserva',
      closeVideo: 'Cerrar Video',
      playAudio: 'Reproducir Narración',
      stopAudio: 'Detener Audio'
    }
  }
};