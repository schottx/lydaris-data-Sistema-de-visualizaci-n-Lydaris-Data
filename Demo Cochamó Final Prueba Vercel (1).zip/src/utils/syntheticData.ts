// Generar grid sintético sobre AOI con PATRONES GEOGRÁFICOS realistas

export type LayerType = 'integrity' | 'fragmentation' | 'connectivity';

export function createSyntheticGrid(layerType: LayerType) {
  const features = [];
  const gridSize = 0.002; // ~200m cells
  const bounds = {
    minLng: -71.9173,
    maxLng: -71.9007,
    minLat: -43.2925,
    maxLat: -43.2782
  };
  
  // Centro del AOI
  const centerLng = (bounds.minLng + bounds.maxLng) / 2;
  const centerLat = (bounds.minLat + bounds.maxLat) / 2;
  
  // Radio máximo desde el centro
  const maxDist = Math.sqrt(
    Math.pow(bounds.maxLng - centerLng, 2) + 
    Math.pow(bounds.maxLat - centerLat, 2)
  );
  
  for (let lng = bounds.minLng; lng < bounds.maxLng; lng += gridSize) {
    for (let lat = bounds.minLat; lat < bounds.maxLat; lat += gridSize) {
      const cellCenterLng = lng + gridSize / 2;
      const cellCenterLat = lat + gridSize / 2;
      
      // Distancia desde el centro del AOI (normalizada 0-1)
      const distFromCenter = Math.sqrt(
        Math.pow(cellCenterLng - centerLng, 2) + 
        Math.pow(cellCenterLat - centerLat, 2)
      ) / maxDist;
      
      // Distancia desde el borde (0 en borde, 1 en centro)
      const distFromEdge = 1 - distFromCenter;
      
      // Gradiente norte-sur (normalizado 0-1)
      const northSouth = (cellCenterLat - bounds.minLat) / (bounds.maxLat - bounds.minLat);
      
      // Gradiente este-oeste (normalizado 0-1)
      const eastWest = (cellCenterLng - bounds.minLng) / (bounds.maxLng - bounds.minLng);
      
      let value;
      
      if (layerType === 'integrity') {
        // Vegetation Integrity: ALTO en áreas centrales y bajas (valle)
        // Valores altos (80-100) en zonas protegidas del centro
        // Valores bajos (0-40) en bordes y zonas altas
        const baseValue = distFromEdge * 60 + (1 - northSouth) * 30 + eastWest * 10;
        const noise = (Math.sin(cellCenterLng * 500) + Math.cos(cellCenterLat * 500)) * 5;
        value = Math.max(0, Math.min(100, baseValue + noise));
        
      } else if (layerType === 'fragmentation') {
        // Fragmentation: BAJA (valores bajos) en centro, ALTA en bordes
        // Invertido respecto a integrity
        const baseValue = distFromCenter * 50 + northSouth * 30 + (1 - eastWest) * 15;
        const noise = (Math.sin(cellCenterLng * 600) + Math.cos(cellCenterLat * 400)) * 5;
        value = Math.max(0, Math.min(100, baseValue + noise));
        
      } else {
        // Connectivity: ALTA en áreas centrales, BAJA en bordes y corredores
        // Similar a integrity pero con corredores este-oeste
        const corridorBonus = Math.abs(northSouth - 0.5) < 0.3 ? 20 : 0;
        const baseValue = distFromEdge * 55 + corridorBonus + eastWest * 15;
        const noise = (Math.sin(cellCenterLng * 450) + Math.cos(cellCenterLat * 550)) * 5;
        value = Math.max(0, Math.min(100, baseValue + noise));
      }
      
      features.push({
        type: 'Feature',
        properties: { value: Math.round(value) },
        geometry: {
          type: 'Polygon',
          coordinates: [[
            [lng, lat],
            [lng + gridSize, lat],
            [lng + gridSize, lat + gridSize],
            [lng, lat + gridSize],
            [lng, lat]
          ]]
        }
      });
    }
  }
  
  return {
    type: 'FeatureCollection',
    features
  };
}