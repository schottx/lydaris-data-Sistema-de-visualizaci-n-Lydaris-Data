// Traducciones en Español (Original)
export const es = {
  // Navegación y menú
  nav: {
    dataPanel: 'Data Panel',
    menuDashboard: 'Menú del dashboard',
    consolidadoReserva: 'Consolidado Reserva Z',
    carbonIndex: 'Carbon Index®',
    hydroIndex: 'Hydro Index®',
    ecoStructuralIndex: 'Eco-Structural Index®',
    riskIndex: 'Risk Index®',
    consolidado: 'Consolidado',
    interpretacionEcologica: 'Interpretación Ecológica',
    visualizacionInteractiva: 'Visualización Interactiva',
    volverPortada: 'Volver a portada',
  },

  // Portada
  portada: {
    titulo: 'Reserva Z — Diagnóstico Geomático Lydaris Data®',
    subtitulo: 'Sistema de evaluación de capital natural, resiliencia y riesgo ecológico.',
    location: 'Reserva Z - Patagonia Chilena',
    ecorregion: 'Ecorregión Bosque Templado Valdiviano',
    areaTotal: 'Área total',
    resolucion: 'Resolucion',
    fuentes: 'Fuentes',
    verInterpretacion: 'Ver Interpretación Ecológica',
    ocultarInterpretacion: 'Ocultar',
    verEnGoogleEarth: 'Ver en Google Earth',
    superficieBosque: 'Superficie Bosque',
    interpretacion: 'Interpretación',
    aoi: 'AOI',
  },

  // Índices
  indices: {
    carbon: {
      label: 'Carbon Index®',
      description: 'Stock Score',
    },
    hydro: {
      label: 'Hydro Index®',
      description: 'Condición hídrica media',
    },
    ecoStructural: {
      label: 'Eco-Structural Index®',
      description: 'Integridad estructural',
    },
    risk: {
      label: 'Risk Index®',
      description: 'Riesgo bajo',
    },
  },

  // Carbon Interpretation
  carbonInterpretation: {
    titulo: 'Análisis Carbon Index®',
    parrafo1: 'La <strong>Reserva Z</strong> presenta un <strong>balance ecológico robusto</strong>, con un <strong>Carbon Stock Score de 56,3</strong>, situado en la franja media-alta de su ecorregión. El <strong>stock total de 193 tC/ha</strong> —compuesto por <strong>68 tC/ha en biomasa aérea</strong> y <strong>125 tC/ha en carbono edáfico</strong>— evidencia un territorio <strong>ecológicamente maduro y estructuralmente estable</strong>. La predominancia del carbono del suelo refleja <strong>procesos avanzados de resiliencia y regulación ecosistémica</strong>, claves para la estabilidad del paisaje.',
    parrafo2: 'Su <strong>captura media de 5,4 tCO₂e/ha/año</strong> señala una <strong>actividad biológica sostenida</strong>, coherente con ambientes templados húmedos en regeneración natural. Los niveles de <strong>precisión del modelo (R² = 0,87; error < 3,5%)</strong> otorgan <strong>alta confiabilidad científica</strong> a la caracterización del predio.',
    blockquote: 'Territorio con alta coherencia ecológica, estabilidad estructural y valor patrimonial ambiental. Representa un núcleo de conservación y manejo sustentable dentro del corredor valdiviano.',
    footer: 'Natural Capital Reveal® — Análisis Ecosistémico Integral',
    metricLabels: {
      carbonStockScore: 'Carbon Stock Score',
      tChaTotal: 'tC/ha Total',
      tCO2eHaYear: 'tCO₂e/ha/año',
      r2Precision: 'R² Precisión',
    },
  },

  // Forest Slider (Carbon Consolidado)
  forestSlider: {
    titulo: 'Capital Index (CBI-100)',
    subtitulo: 'Índice consolidado de capital natural',
    metricas: 'Métricas de Carbono',
    interpretacion: 'Interpretación',
    interpretacionTexto: 'Stock alto - Capacidad media-alta',
    equivalencias: 'Equivalencias CO₂',
    
    // Tabla de métricas
    metricsTable: {
      parametro: 'Parámetro',
      valor: 'Valor',
      unidad: 'Unidad',
      precision: 'Precisión',
      
      stockBiomasaAerea: 'Stock Biomasa Aérea',
      stockCarbonoSuelo: 'Stock Carbono Suelo',
      stockTotal: 'Stock Total',
      captura: 'Captura',
      co2Total: 'CO₂e Total',
      
      r2Modelo: 'R² Modelo',
      errorRelativo: 'Error Relativo',
      bandaConfianza: 'Banda de Confianza',
    },

    // Subíndices
    subindices: {
      titulo: 'Subíndices Consolidados',
      stockAereo: 'Stock Aéreo',
      stockSuelo: 'Stock Suelo',
      captura: 'Captura',
      score: 'Score',
    },

    // CO2 Equivalencias
    co2Equiv: {
      titulo: 'Equivalencias CO₂',
      subtitulo: 'Conversión del carbono capturado',
      autoAnual: 'Auto promedio/año',
      vuelosSCL: 'Vuelos SCL-Buenos Aires',
      hogares: 'Hogares/año (energía)',
      arbolesEquiv: 'Árboles equivalentes',
      anos: 'años',
    },
  },

  // Ecosystem Slider (IEE)
  ecosystemSlider: {
    titulo: 'Eco-Structural Index® (IEE)',
    subtitulo: 'Evaluación de integridad estructural',
    scoreGeneral: 'IEE Score General',
    subindices: 'Subíndices Estructurales',
    interpretacion: 'Interpretación Ecológica',
    
    // Subíndices
    ev: 'EV — Estratificación Vertical',
    dc: 'DC — Densidad Copa',
    fc: 'FC — Fragmentación Copa',
    paInv: 'PA⁻¹ — Inv. Perímetro/Área',
    ce: 'CE — Conectividad Estructural',
    bonoRibereno: 'Bono Ribereño',
    
    // Categorías
    categorias: {
      excelente: 'Excelente',
      alto: 'Alto',
      medio: 'Medio',
      bajo: 'Bajo',
      muyBajo: 'Muy bajo',
    },

    // Interpretación
    interpretacionTexto: 'La Reserva Z presenta una <strong>estructura ecosistémica heterogénea</strong> con <strong>estratificación vertical excelente (EV=91,0)</strong> y <strong>conectividad estructural perfecta (CE=100,0)</strong>. La baja densidad de copa (DC=16,1) y fragmentación moderada (FC=40,0) sugieren un <strong>bosque maduro con dosel abierto</strong>, común en transiciones ecotono-ribereñas. El <strong>bono ribereño de +15 puntos</strong> reconoce servicios ecosistémicos críticos. El <strong>IEE consolidado de 62,2</strong> refleja un ecosistema <strong>resiliente y funcionalmente valioso</strong>.',
  },

  // Hydro Consolidado
  hydroConsolidado: {
    titulo: 'Hydro Index® (LD-HYDRO)',
    subtitulo: 'Evaluación de condición hídrica',
    scoreGeneral: 'Score General Hydro Index®',
    metricas: 'Métricas Hídricas',
    interpretacion: 'Interpretación Hídrica',
    
    // Métricas
    ndwiMedio: 'NDWI Medio',
    ndwiMax: 'NDWI Máximo',
    ndwiMin: 'NDWI Mínimo',
    variabilidad: 'Variabilidad',
    estabilidad: 'Estabilidad',
    
    interpretacionTexto: 'La Reserva Z presenta <strong>condición hídrica media (63,2)</strong>, con valores NDWI que indican <strong>disponibilidad constante de agua</strong> en el sistema. La <strong>baja variabilidad estacional</strong> refleja estabilidad en los flujos hidrológicos, característica de ecosistemas templados húmedos con influencia ribereña.',
  },

  // Environmental Risk
  environmentalRisk: {
    titulo: 'Risk Index® (LD-RISK)',
    subtitulo: 'Evaluación de riesgo ecológico',
    scoreGeneral: 'Score Riesgo Ecológico',
    factores: 'Factores de Riesgo',
    interpretacion: 'Interpretación de Riesgo',
    
    // Factores
    riesgoIncendio: 'Riesgo de Incendio',
    riesgoPlagas: 'Riesgo de Plagas',
    riesgoErosion: 'Riesgo de Erosión',
    riesgoFragmentacion: 'Riesgo de Fragmentación',
    
    // Categorías
    muyBajo: 'Muy Bajo',
    bajo: 'Bajo',
    medio: 'Medio',
    alto: 'Alto',
    
    interpretacionTexto: 'La Reserva Z presenta <strong>bajo riesgo ecológico general (23,8)</strong>, con factores de amenaza controlados. El clima templado húmedo y la baja presión antrópica mantienen el <strong>riesgo de incendio muy bajo</strong>. La <strong>conectividad estructural alta</strong> minimiza riesgos de fragmentación.',
  },

  // Metadata
  metadata: {
    version: 'Versión',
    archivo: 'Archivo',
    copyright: 'Lydaris Data® — Sustainable Planetary Cartography (SPC)',
  },

  // Botones y acciones
  actions: {
    expandir: 'Expandir',
    contraer: 'Contraer',
    descargar: 'Descargar',
    verMas: 'Ver más',
    verMenos: 'Ver menos',
    cerrar: 'Cerrar',
  },

  // Tooltips
  tooltips: {
    verInterpretacionCarbono: 'Ver Interpretación Ecológica del Carbono',
    clickAbrir: 'Click para abrir en Google Earth',
  },
};

export type Translation = typeof es;