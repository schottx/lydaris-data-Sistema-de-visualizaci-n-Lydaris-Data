// English Translations
import { Translation } from './es';

export const en: Translation = {
  // Navigation and menu
  nav: {
    dataPanel: 'Data Panel',
    menuDashboard: 'Dashboard menu',
    consolidadoReserva: 'Reserve Z Consolidated',
    carbonIndex: 'Carbon Index™',
    hydroIndex: 'Hydro Index™',
    ecoStructuralIndex: 'Eco-Structural Index™',
    riskIndex: 'Risk Index™',
    consolidado: 'Consolidated',
    interpretacionEcologica: 'Ecological Interpretation',
    visualizacionInteractiva: 'Interactive Visualization',
    volverPortada: 'Back to home',
  },

  // Home page
  portada: {
    titulo: 'Reserve Z — Lydaris Data™ Geomatic Assessment',
    subtitulo: 'Natural capital, resilience and ecological risk assessment system.',
    location: 'Reserve Z - Chilean Patagonia',
    ecorregion: 'Valdivian Temperate Forest Ecoregion',
    areaTotal: 'Total area',
    resolucion: 'Resolution',
    fuentes: 'Sources',
    verInterpretacion: 'View Ecological Interpretation',
    ocultarInterpretacion: 'Hide',
    verEnGoogleEarth: 'View on Google Earth',
    superficieBosque: 'Forest Area',
    interpretacion: 'Interpretation',
    aoi: 'AOI',
  },

  // Indices
  indices: {
    carbon: {
      label: 'Carbon Index™',
      description: 'Stock Score',
    },
    hydro: {
      label: 'Hydro Index™',
      description: 'Average water condition',
    },
    ecoStructural: {
      label: 'Eco-Structural Index™',
      description: 'Structural integrity',
    },
    risk: {
      label: 'Risk Index™',
      description: 'Low risk',
    },
  },

  // Carbon Interpretation
  carbonInterpretation: {
    titulo: 'Carbon Index™ Analysis',
    parrafo1: '<strong>Reserve Z</strong> presents a <strong>robust ecological balance</strong>, with a <strong>Carbon Stock Score of 56.3</strong>, positioned in the medium-high range of its ecoregion. The <strong>total stock of 193 tC/ha</strong> —composed of <strong>68 tC/ha in aboveground biomass</strong> and <strong>125 tC/ha in soil carbon</strong>— evidences an <strong>ecologically mature and structurally stable</strong> territory. The predominance of soil carbon reflects <strong>advanced processes of resilience and ecosystem regulation</strong>, key to landscape stability.',
    parrafo2: 'Its <strong>average sequestration of 5.4 tCO₂e/ha/year</strong> indicates <strong>sustained biological activity</strong>, consistent with humid temperate environments in natural regeneration. The <strong>model precision levels (R² = 0.87; error < 3.5%)</strong> provide <strong>high scientific reliability</strong> to the site characterization.',
    blockquote: 'Territory with high ecological coherence, structural stability and environmental heritage value. Represents a conservation and sustainable management core within the Valdivian corridor.',
    footer: 'Natural Capital Reveal® — Comprehensive Ecosystem Analysis',
    metricLabels: {
      carbonStockScore: 'Carbon Stock Score',
      tChaTotal: 'tC/ha Total',
      tCO2eHaYear: 'tCO₂e/ha/year',
      r2Precision: 'R² Precision',
    },
  },

  // Forest Slider (Carbon Overview)
  forestSlider: {
    titulo: 'Capital Index (CBI-100)',
    subtitulo: 'Consolidated natural capital index',
    metricas: 'Carbon Metrics',
    interpretacion: 'Interpretation',
    interpretacionTexto: 'High stock - Medium-high capacity',
    equivalencias: 'CO₂ Equivalents',
    
    // Metrics table
    metricsTable: {
      parametro: 'Parameter',
      valor: 'Value',
      unidad: 'Unit',
      precision: 'Precision',
      
      stockBiomasaAerea: 'Aboveground Biomass Stock',
      stockCarbonoSuelo: 'Soil Carbon Stock',
      stockTotal: 'Total Stock',
      captura: 'Sequestration',
      co2Total: 'Total CO₂e',
      
      r2Modelo: 'Model R²',
      errorRelativo: 'Relative Error',
      bandaConfianza: 'Confidence Band',
    },

    // Sub-indices
    subindices: {
      titulo: 'Consolidated Sub-indices',
      stockAereo: 'Aerial Stock',
      stockSuelo: 'Soil Stock',
      captura: 'Sequestration',
      score: 'Score',
    },

    // CO2 Equivalents
    co2Equiv: {
      titulo: 'CO₂ Equivalents',
      subtitulo: 'Captured carbon conversion',
      autoAnual: 'Average car/year',
      vuelosSCL: 'SCL-Buenos Aires flights',
      hogares: 'Homes/year (energy)',
      arbolesEquiv: 'Equivalent trees',
      anos: 'years',
    },
  },

  // Ecosystem Slider (ESI)
  ecosystemSlider: {
    titulo: 'Eco-Structural Index™ (ESI)',
    subtitulo: 'Structural integrity assessment',
    scoreGeneral: 'ESI Overall Score',
    subindices: 'Structural Sub-indices',
    interpretacion: 'Ecological Interpretation',
    
    // Sub-indices
    ev: 'VS — Vertical Stratification',
    dc: 'CD — Canopy Density',
    fc: 'CF — Canopy Fragmentation',
    paInv: 'PA⁻¹ — Perimeter/Area Inv.',
    ce: 'SC — Structural Connectivity',
    bonoRibereno: 'Riparian Bonus',
    
    // Categories
    categorias: {
      excelente: 'Excellent',
      alto: 'High',
      medio: 'Medium',
      bajo: 'Low',
      muyBajo: 'Very low',
    },

    // Interpretation
    interpretacionTexto: 'Reserve Z presents a <strong>heterogeneous ecosystem structure</strong> with <strong>excellent vertical stratification (VS=91.0)</strong> and <strong>perfect structural connectivity (SC=100.0)</strong>. Low canopy density (CD=16.1) and moderate fragmentation (CF=40.0) suggest a <strong>mature forest with open canopy</strong>, common in riparian-ecotone transitions. The <strong>+15 point riparian bonus</strong> recognizes critical ecosystem services. The <strong>consolidated ESI of 62.2</strong> reflects a <strong>resilient and functionally valuable</strong> ecosystem.',
  },

  // Hydro Overview
  hydroConsolidado: {
    titulo: 'Hydro Index™ (LD-HYDRO)',
    subtitulo: 'Water condition assessment',
    scoreGeneral: 'Overall Hydro Index™ Score',
    metricas: 'Water Metrics',
    interpretacion: 'Water Interpretation',
    
    // Metrics
    ndwiMedio: 'Average NDWI',
    ndwiMax: 'Maximum NDWI',
    ndwiMin: 'Minimum NDWI',
    variabilidad: 'Variability',
    estabilidad: 'Stability',
    
    interpretacionTexto: 'Reserve Z presents <strong>medium water condition (63.2)</strong>, with NDWI values indicating <strong>constant water availability</strong> in the system. The <strong>low seasonal variability</strong> reflects stability in hydrological flows, characteristic of humid temperate ecosystems with riparian influence.',
  },

  // Environmental Risk
  environmentalRisk: {
    titulo: 'Risk Index™ (LD-RISK)',
    subtitulo: 'Ecological risk assessment',
    scoreGeneral: 'Ecological Risk Score',
    factores: 'Risk Factors',
    interpretacion: 'Risk Interpretation',
    
    // Factors
    riesgoIncendio: 'Fire Risk',
    riesgoPlagas: 'Pest Risk',
    riesgoErosion: 'Erosion Risk',
    riesgoFragmentacion: 'Fragmentation Risk',
    
    // Categories
    muyBajo: 'Very Low',
    bajo: 'Low',
    medio: 'Medium',
    alto: 'High',
    
    interpretacionTexto: 'Reserve Z presents <strong>low overall ecological risk (23.8)</strong>, with controlled threat factors. The humid temperate climate and low anthropogenic pressure maintain <strong>very low fire risk</strong>. The <strong>high structural connectivity</strong> minimizes fragmentation risks.',
  },

  // Metadata
  metadata: {
    version: 'Version',
    archivo: 'File',
    copyright: 'Lydaris Data™ — Sustainable Planetary Cartography (SPC)',
  },

  // Buttons and actions
  actions: {
    expandir: 'Expand',
    contraer: 'Collapse',
    descargar: 'Download',
    verMas: 'View more',
    verMenos: 'View less',
    cerrar: 'Close',
  },

  // Tooltips
  tooltips: {
    verInterpretacionCarbono: 'View Carbon Ecological Interpretation',
    clickAbrir: 'Click to open on Google Earth',
  },
};