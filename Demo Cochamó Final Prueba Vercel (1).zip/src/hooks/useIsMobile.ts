import { useState, useEffect } from 'react';

/**
 * Hook personalizado para detectar si la pantalla es móvil
 * Breakpoint: 1024px (lg en Tailwind)
 * 
 * - Desktop: >= 1024px → false
 * - Mobile/Tablet: < 1024px → true
 * 
 * @returns boolean - true si es móvil, false si es desktop
 */
export function useIsMobile(breakpoint: number = 1024): boolean {
  // Inicializar correctamente detectando desde el inicio
  const [isMobile, setIsMobile] = useState<boolean>(() => {
    // Solo ejecutar en el cliente (no SSR)
    if (typeof window !== 'undefined') {
      return window.innerWidth < breakpoint;
    }
    return false;
  });

  useEffect(() => {
    // Función para actualizar el estado
    const checkIsMobile = () => {
      setIsMobile(window.innerWidth < breakpoint);
    };

    // Verificar inmediatamente por si cambió
    checkIsMobile();

    // Escuchar cambios de tamaño de ventana
    window.addEventListener('resize', checkIsMobile);

    // Cleanup
    return () => window.removeEventListener('resize', checkIsMobile);
  }, [breakpoint]);

  return isMobile;
}
