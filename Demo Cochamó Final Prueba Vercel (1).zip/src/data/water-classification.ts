/**
 * ============================================
 * LYDARIS DATA - CLASIFICACIÓN HIDROLÓGICA
 * ============================================
 * 
 * GeoJSON local temporal de clasificación de agua
 * (Mientras el servidor externo esté disponible)
 */

export const waterClassificationGeoJSON = {
  "type": "FeatureCollection",
  "features": [
    // Por ahora vacío - se poblará cuando el servidor esté disponible
    // o se pueden agregar features manualmente aquí
  ]
};
