// ============================================
// FUENTE ÚNICA DE DATOS PARA TODOS LOS ÍNDICES
// Lydaris Data - Reserva Cochamó
// ============================================

export const INDICES_VALUES = {
  hydro: {
    valor: 55.8,
    categoria: {
      es: 'Sistema hídrico funcional medio–alto',
      en: 'Medium-high functional water system'
    },
    categoriaCorta: {
      es: 'Medio - Alto',
      en: 'Medium - High'
    },
    confianza: 0.64,
    confianzaTexto: {
      es: 'Media (64%)',
      en: 'Medium (64%)'
    }
  },
  esi: {
    valor: 81.8,
    categoria: {
      es: 'Estructura ecosistémica funcional Alta',
      en: 'High functional ecosystem structure'
    },
    categoriaCorta: {
      es: 'Alto',
      en: 'High'
    },
    confianza: 0.83,
    confianzaTexto: {
      es: 'Alta (83%)',
      en: 'High (83%)'
    }
  },
  carbon: {
    valor: 68.3,
    categoria: {
      es: 'Potencial de secuestro alto',
      en: 'High sequestration potential'
    },
    categoriaCorta: {
      es: 'Alto',
      en: 'High'
    },
    confianza: 0.89,
    confianzaTexto: {
      es: 'Alta (89%)',
      en: 'High (89%)'
    }
  },
  risk: {
    valor: 39.03,
    categoria: {
      es: 'Riesgo medio',
      en: 'Medium risk'
    },
    categoriaCorta: {
      es: 'Medio',
      en: 'Medium'
    },
    confianza: 0.78,
    confianzaTexto: {
      es: 'Alta (78%)',
      en: 'High (78%)'
    }
  }
} as const;